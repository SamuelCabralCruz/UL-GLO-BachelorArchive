function x = remontee(a, n, b, m)
%% REMONTEE
% Solve for x into the system ax=b (ascent)

%% Input:
%   a - upper triangular matrix
%   n - number of lines of the matrix a
%   b - vector of solution into the system ax=b
%   m - bandwidth of the matrix a

%% Output:
%   x - vector to be applied to a to solve for b

%% Body:
x=zeros(n, 1);
x(n)=b(end)/a(n,n);
for i=n-1:-1:1
    temp=0;
    for k=i+1:min(i+m-1,n)
        temp=a(i,k)*x(k)+temp;
    end
    x(i)=(b(i)-temp)/a(i,i);
end
end

