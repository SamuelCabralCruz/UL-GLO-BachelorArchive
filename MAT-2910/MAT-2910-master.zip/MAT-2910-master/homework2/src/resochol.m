function x = resochol(a, n, b, m)
%% RESOCHOL
% Resolve the system ax=b using cholesky

%% Input:
%   a - symmetric positive matrix
%   n - number of lines of the matrix a
%   b - vector of solution into the system ax=b
%   m - bandwidth of the matrix a

%% Output:
%   x - vector to be applied to a to solve for b

%% Body:
l=choleski(a, n, m);
u=l';
y=descente(l, n, b, m);
x=remontee(u, n, y, m);
end

