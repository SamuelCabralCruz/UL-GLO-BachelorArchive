close all; clear; clc;

y=@(x) -2.*(x-0.5).^2+0.5;
df2y=@(x) -4;
r=@(x) -1*df2y(x);

%% Figure 1
n1=2;
n2=4;
h1=1/n1;
h2=1/n2;
y_approx_1=resolution(r, n1);
y_approx_2=resolution(r, n2);

figure(1);
fplot(y, [0,1]);
hold on;
x1=0:h1:1;
plot(x1, y_approx_1);
x2=0:h2:1;
plot(x2, y_approx_2);
hold off;
grid on; 
axis([0 1 0 0.6]);
txt={'As we can see, by increasing the value of $n$,',;
    'the value of $h$ will decrease and the approximation',;
    'will be better because we will interpolate the',;
    'variation of $y(x)$ over smaller ranges.'};
text(0.15, 0.1, txt,'Interpreter', 'latex','FontSize', 14);
legend('theoritical', ['approx. (h=', num2str(h1), ')'], ['approx. (h=', num2str(h2), ')'],'FontSize', 14);
title({'Graph of $y$ in Relationship to $x$','$y(x)=-2(x-0.5)^2+0.5$'}, 'Interpreter', 'latex', 'FontSize', 17);
xlabel('$x$', 'Interpreter', 'latex','FontSize', 20);
ylabel('$y(x)$', 'Interpreter', 'latex','FontSize', 20);

%% Figure 2
h=10.^(-1:-1:-4);
n=round(1./h);
f=@(n) arrayfun(y, 0:1/n:1);
e=@(x) max(abs(resolution(r, x)'-f(x)));
abs_error=arrayfun(e, n);
reg_params=polyfit(log(h), log(abs_error), 1);
reg_param2=polyfit(h, abs_error, 1);
p=reg_params(1);
b=reg_params(2);
c=exp(reg_params(2)/p);
reg=@(x) exp(p*log(x)+b);

figure(2);
loglog(h, abs_error);
hold on;
loglog(h, arrayfun(reg, h));
hold off;
grid on;
legend({'interpolation error', 'linear regression'},'Interpreter', 'latex', 'FontSize', 14);
txt={'$E(h)\approx Ch^p$',;
    ['where $C=', num2str(c,'%10.4e'), '$ and $p=', num2str(p),'$'],;
    'By dividing $h$ by 2',;
    'we reduce the error by a factor of $2^p$.'};
text(15^(-3), 10^(-15), txt, 'Interpreter', 'latex','FontSize', 14);
xlabel('$h$', 'Interpreter', 'latex','FontSize', 20);
ylabel('$E(h)$', 'Interpreter', 'latex','FontSize', 20);
title({'Maximum Absolute Interpolation Error of $y(x)$', 'in Relationship to $h$'}, 'Interpreter', 'latex','FontSize', 17);
