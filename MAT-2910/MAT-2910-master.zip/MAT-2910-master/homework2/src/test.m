%% General
close all; clear; clc;

%% Question 1
%a)
a=[4 6 2;
   6 10 5;
   2 5 14];
n=3;
m=3;
lower_matrix = choleski(a, n, m);         
assert(isequal(lower_matrix * lower_matrix', a), "test choleski 1 - invalid")

a=[18  22   54   42;
   22  70   86   62;
   54  86  174  134; 
   42  62  134  106];
n=4;
m=4;
lower_matrix=choleski(a, n, m);
expected_result=lower_matrix * lower_matrix';
iswithintol=ismembertol(expected_result, a, 0.05, 'ByRows', true);
assert(isequal(iswithintol, ones(n, 1)), "test choleski 2 - invalid")

a=[1 2  0  0;
   2 5  -3  0;
   0 -3 10 2; 
   0  0 2  5];
n=4;
m=2;
lower_matrix=choleski(a, n, m);
expected_result=lower_matrix * lower_matrix';
iswithintol=ismembertol(expected_result, a, 0.05, 'ByRows', true);
assert(isequal(iswithintol, ones(n, 1)), "test choleski 3 - invalid")


%b)
a=[4 6 0 0; 
   0 4 6 0; 
   0 0 4 6; 
   0 0 0 4];
n=size(a,1);
b=[1;
   2;
   3;
   4];
m=2;
x=remontee(a, n, b, m);
assert(isequal(a\b, x), "test ascent 1 - invalid");

a=[4 6 5 0; 
   0 4 6 5; 
   0 0 4 6; 
   0 0 0 4];
n=size(a,1);
b=[1;
   2;
   3;
   4];
m=3;
x=remontee(a, n, b, m);
assert(isequal(a\b, x), "test ascent 2 - invalid");

%c)
a=[4 0 0 0; 
   6 4 0 0; 
   5 6 4 0; 
   0 5 6 4];
n=size(a,1);
b=[1;2;3;4];
m=3;
x=descente(a, n, b, m);
assert(isequal(a\b, x), "test descent 1 - invalid");

%d)
a=[1 1  1  1; 
   1 5  5  5; 
   1 5 14 14; 
   1 5 14 15];
n=size(a,1);
b=[1;2;3;4];
m=4;
x=resochol(a, n, b, m);
assert(isequal(a\b, x), "test resochol 1 - invalid");
