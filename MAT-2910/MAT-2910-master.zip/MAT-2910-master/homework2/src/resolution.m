function y = resolution(r, n)
%% RESOLUTION
% Numeric resolution of boundary problems in one dimension

%% Input:
%   r - function r(x) representing the inverse of the second derivative of y over an interval 
%   n - number of equal-length intervals

%% Output:
%   y - vector of numerical approximation of the second derivative of y

%% Body:
h=1/n;
i=1:n-1;
xi=i*h;

ri=arrayfun(r,xi);
b=ri*h.^2;

diag1=diag(ones(1, n-1)*2);
diag2=diag(ones(1, n-2)*-1, 1);
diag3=diag(ones(1, n-2)*-1, -1);
a=zeros(n-1)+diag1+diag2+diag3;

y=resochol(a, n-1, b, 2);

y=vertcat(zeros(1,1), y);
y=vertcat(y, zeros(1,1));
end

