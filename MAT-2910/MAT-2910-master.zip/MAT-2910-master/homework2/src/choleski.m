function l = choleski(a, n, m)
    %% CHOLESKI
    % Inspire by https://rosettacode.org/wiki/Cholesky_decomposition#Java
    % Factorize a symetrical matrix into a lower triangular matrix and it's conjugate transpose
    
    %% Input:
    %   a - a positive and symetrical matrix
    %   n - number of lines of the matrix a
    %   m - bandwidth of  the matrix a
 
    %% Output:
    %   l - lower triangular matrix
    
    %% Body:
    l = zeros(n, n);
    for i = 1:n
        for k = max(i-m ,1):i
            sum = 0;
            for j = 1:k
                sum = sum + (l(i, j) * l(k, j));
            end
            if (i == k)
                l(i, k) = sqrt(a(i, i) - sum); 
            else
                l(i, k) = (1 / l(k, k) * (a(i, k) - sum));
            end
        end
    end
        
