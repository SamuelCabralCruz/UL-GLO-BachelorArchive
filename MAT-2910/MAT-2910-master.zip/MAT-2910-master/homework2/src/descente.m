function x = descente(a, n, b, m)
%% DESCENTE
% Solve for x into the system ax=b (descent)

%% Input:
%   a - lower triangular matrix
%   n - number of lines of the matrix a
%   b - vector of solution into the system ax=b
%   m - bandwidth of the matrix a

%% Output:
%   x - vector to be applied to a to solve for b

%% Body:
x=zeros(n, 1);
x(1)=b(1)/a(1,1);
for i=2:n
    temp=0;
    for k=max((i-m)+1,1):i-1
        temp=a(i,k)*x(k)+temp;
    end
    x(i)=(b(i)-temp)/a(i,i);
end
end

