import math
import matplotlib.pyplot as plt

import bissection
import pointfixe
import newton
import newton2

if __name__ == "__main__":
    # Question 1
    f = lambda x: math.exp(x-3)-x
    delta_r = 0.5*(10**-10)
    n_max = math.ceil(math.log(1/delta_r)/math.log(2))
    epsilon = 2.6*(10**-16)
    x_1 = 0
    x_2 = 1
    output = bissection.bissection(f, x_1, x_2, n_max, epsilon)
    r = output[-1]
    x = range(1, len(output)+1)
    q1 = [abs(x_m - r) for x_m in output]
    plt.plot(x, q1)
    plt.show()
    # Question 2
    g = lambda x: math.exp(x-3)
    x_0 = 1
    output = pointfixe.pointfixe(g, x_0, 9, epsilon)
    q2 = [abs(x_m - r) for x_m in output]
    plt.plot(range(len(q1)), q1)
    plt.plot(range(len(q2)), q2)
    plt.show()
    g_prime_r = []
    for x, y in zip(q2[1:], q2[:-1]):
        g_prime_r.append(x/y)
    print(g_prime_r)
    plt.plot(range(len(g_prime_r)), g_prime_r)
    plt.show()
    # Question 3
    f = lambda x: math.exp(x-3)-x
    df = lambda x: math.exp(x-3)-1
    x_0 = 0.5
    output = newton.newton(f, df, x_0, n_max, epsilon)
    x = range(1, len(output)+1)
    q3 = [abs(x_m - r) for x_m in output]
    plt.plot(range(len(q1)), q1)
    plt.plot(range(len(q2)), q2)
    plt.plot(range(len(q3)), q3)
    plt.show()
    g_prime_r = []
    for x, y in zip(q3[1:], q3[:-1]):
        g_prime_r.append(x/(y**2))
    plt.plot(range(len(g_prime_r)), g_prime_r)
    plt.show()
    f = lambda x: x**3 - 5*x**2 + 7*x - 3
    df = lambda x: 3*x**2 - 10*x + 7
    x_0 = 0
    output = newton.newton(f, df, x_0, n_max, epsilon)
    r = 1
    x = range(1, len(output)+1)
    q3c = [abs(x_m - r) for x_m in output]
    plt.plot(range(len(q1)), q1)
    plt.plot(range(len(q2)), q2)
    plt.plot(range(len(q3)), q3)
    plt.plot(range(len(q3c)), q3c)
    plt.show()
    g_prime_r = []
    for x, y in zip(q3[1:], q3[:-1]):
        g_prime_r.append(x/y)
    plt.plot(range(len(g_prime_r)), g_prime_r)
    plt.show()
    # Question 4
    output = newton2.newton2(f, df, x_0, n_max, epsilon, 2)
    x = range(1, len(output)+1)
    q4 = [abs(x_m - r) for x_m in output]
    plt.plot(x, q4)
    g_prime_r = []
    for x, y in zip(q4[1:], q4[:-1]):
        g_prime_r.append(x/(y**2))
    plt.plot(range(len(g_prime_r)), g_prime_r)
    plt.show()
