def bissection(f, x_1, x_2, n_max, epsilon):
    assert f(x_1)*f(x_2) < 0, "Aucun changement de signe détecté entre les bornes fournies"
    nb_iter = 0
    output = []
    while True:
        x_m = (x_1 + x_2)/2
        output.append(x_m)
        nb_iter += 1
        err_abs = (x_2 - x_1)/2
        err_rel = err_abs/x_m
        if  nb_iter == n_max or err_rel < epsilon:
            break
        if f(x_1)*f(x_m) < 0:
            x_2 = x_m
        if f(x_2)*f(x_m) < 0:
            x_1 = x_m
    return output
