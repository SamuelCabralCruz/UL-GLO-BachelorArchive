def newton(f, df, x_0, n_max, epsilon):
    nb_iter = 0
    output = []
    x_prev = x_0
    while True:
        x_current = x_prev - f(x_prev)/df(x_prev)
        output.append(x_current)
        nb_iter += 1
        err_abs = abs(x_current - x_prev)
        err_rel = err_abs/x_current
        if  nb_iter == n_max or err_rel < epsilon:
            break
        x_prev = x_current
    return output
