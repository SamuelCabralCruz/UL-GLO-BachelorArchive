function x = bissection(f, x1, x2, nmax, epsilon)
%% BISSECTION 
% Find the root of a function f using the bissection method

%% Input:
%   f - the function f(x) for which we want to find the root over [x1, x2]
%   x1 - lower bound of the inspection range
%   x2 - upper bound of the inspection range
%   nmax - maximum number of iterations to be performed
%   epsilon - maximum tolerance on the relative error

%% Output:
%   x - array of iterative root estimations

%% Precondition:
%   There must be a sign change over the inspection range
%       f(x1)*f(x2) < 0

%% Body:
fprintf('Root Approximation Using Bissection Method\n');

assert(f(x1)*f(x2) < 0, "There must a sign change over the inspection range");

nbiterations=0;
x=[];

while true
    xm=(x1+x2)/2;
    x=[x, xm];
    erabs=abs(x1-x2)/2;
    errel=erabs/abs(xm);
    nbiterations=nbiterations+1;
    fprintf('iteration %2d , xm= %1.6f , erabs= %1.2e , errel= %1.2e \n', nbiterations, xm, erabs, errel);
    if (nbiterations == nmax) || (errel < epsilon)
        break;
    end
    if f(x1)*f(xm) < 0
        x2=xm;
    end
    if f(x2)*f(xm) < 0
        x1=xm;
    end
end

fprintf('\n');
end

