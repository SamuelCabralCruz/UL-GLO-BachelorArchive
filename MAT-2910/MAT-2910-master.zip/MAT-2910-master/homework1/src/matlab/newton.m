function x = newton(f, df, x0, nmax, epsilon)
%% NEWTON
% Find the root of a function f using the newton method

%% Input:
%   f - the function f(x) for which we want to find the root starting with
%   initial guess x0
%   df - the first derivative of the function f(x) 
%   x0 - initial guess for the root
%   nmax - maximum number of iterations to be performed
%   epsilon - maximum tolerance on the relative error

%% Output:
%   x - array of iterative root estimations

%% Body:
fprintf('Root Approximation Using Newton Method\n');

nbiterations=0;
x=[x0];
xm_prev=x0;

while true
    xm=xm_prev-f(xm_prev)/df(xm_prev);
    x=[x, xm];
    erabs=abs(xm-xm_prev);
    errel=erabs/abs(xm);
    nbiterations=nbiterations+1;
    fprintf('iteration %2d , xm= %1.6f , erabs= %1.2e , errel= %1.2e \n', nbiterations, xm, erabs, errel);
    if (nbiterations == nmax) || (errel < epsilon)
        break;
    end
    xm_prev=xm;
end

fprintf('\n');
end
