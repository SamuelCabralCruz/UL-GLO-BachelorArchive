%% General
close all; clear; clc;

%% Question 1
f=@(x) exp(x-3)-x;
x1=0;
x2=1;
nb_significant_digits=10;
delta_r=0.5*(10^-nb_significant_digits);
nmax=ceil(log(1/delta_r)/log(2));
epsilon=eps(1); 
bissection_approx=bissection(f, x1, x2, nmax, epsilon);
r=bissection_approx(end);

nb_iterations_bissection=1:1:length(bissection_approx);
abs_error_bissection=abs(bissection_approx-r);

%% Question 2
g=@(x) exp(x-3);
x0=1;
nmax=20;
epsilon=eps(1);
pointfixe_approx=pointfixe(g, x0, nmax, epsilon);

nb_iterations_pointfixe=1:1:length(pointfixe_approx);
abs_error_pointfixe=abs(pointfixe_approx-r);

figure(1);
semilogy(nb_iterations_bissection, abs_error_bissection);
hold on;
semilogy(nb_iterations_pointfixe, abs_error_pointfixe);
hold off;
grid on; 
legend('Bissection', 'Fixed Points')
title('Absolute Error Against The Number of Iterations', 'Interpreter', 'latex');
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error $\mid x_i - r \mid$', 'Interpreter', 'latex');

figure(2);
iteration_limit_pointfixe=10;
ratio_indexes_pointfixe=2:min(length(abs_error_pointfixe), iteration_limit_pointfixe);
abs_error_ratios_pointfixe=abs_error_pointfixe(ratio_indexes_pointfixe)./abs_error_pointfixe(ratio_indexes_pointfixe-1);
plot(ratio_indexes_pointfixe, abs_error_ratios_pointfixe);
axis([1 11 0.04 0.1]);
grid on; 
title('Convergence Analysis - Fixed Points Method', 'Interpreter', 'latex');
txt={'As we can see, \mid g''(r) \mid \approx 0.05 and \mid g''(r) \mid < 1.', 
    'We can then conclude that the convergence is linear.',
    'Please note that some data points have been filtered out', 
    'since they were too importantly affected by machine error.'};
text(3, 0.09, txt);
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error Ratios $\frac{\mid x_{i+1} - r \mid}{\mid x_i -r \mid}$', 'Interpreter', 'latex');

%% Question 3
f=@(x) exp(x-3)-x;
df=@(x) exp(x-3)-1;
x0=1;
nmax=20;
epsilon=eps(1);
newton_approx=newton(f, df, x0, nmax, epsilon);

nb_iterations_newton=1:1:length(newton_approx);
abs_error_newton=abs(newton_approx-r);

figure(3);
semilogy(nb_iterations_bissection, abs_error_bissection);
hold on;
semilogy(nb_iterations_pointfixe, abs_error_pointfixe);
hold on;
semilogy(nb_iterations_newton, abs_error_newton);
hold off;
grid on; 
legend('Bissection', 'Points fixes', 'Newton')
title('Absolute Error Against The Number of Iterations', 'Interpreter', 'latex');
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error $\mid x_i - r \mid$', 'Interpreter', 'latex');

figure(4);
iteration_limit_newton=4;
ratio_indexes_newton=2:min(length(abs_error_newton), iteration_limit_newton);
abs_error_ratios_newton=abs_error_newton(ratio_indexes_newton)./abs_error_newton(ratio_indexes_newton-1).^2;
plot(ratio_indexes_newton, abs_error_ratios_newton);
axis([1 5 0 0.1]);
grid on; 
title('Convergence Analysis - Newton Method', 'Interpreter', 'latex');
txt={'It is possible to verify that \mid g''(r) \mid \approx 0.', 
    'We can also deduce from the current figure that \mid g''''(r) \mid \approx 0.03.',
    'We can then conclude that the convergence is quadratic.',
    'Please note that some data points have been filtered out', 
    'since they were too importantly affected by machine error.'};
text(1.5, 0.08, txt);
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error Ratios $\frac{\mid x_{i+1} - r \mid}{\mid x_i -r \mid^2}$', 'Interpreter', 'latex');

f=@(x) x^3-5*x^2+7*x-3;
df=@(x) 3*x^2-10*x+7;
x0=0;
nmax=20;
epsilon=eps(1);
r=1;
newton_multi1_approx=newton(f, df, x0, nmax, epsilon);

nb_iterations_newton_multi1=1:1:length(newton_multi1_approx);
abs_error_newton_multi1=abs(newton_multi1_approx-r);

figure(5)
iteration_limit_newton_multi1=20;
ratio_indexes_newton_multi1=2:min(length(abs_error_newton_multi1), iteration_limit_newton_multi1);
abs_error_ratios_newton_multi1=abs_error_newton_multi1(ratio_indexes_newton_multi1)./abs_error_newton_multi1(ratio_indexes_newton_multi1-1);
plot(ratio_indexes_newton_multi1, abs_error_ratios_newton_multi1);
axis([1 21 0.45 0.6]);
grid on;
title({'Convergence Analysis - Newton Method', 'Root Multiplicity: 2', '$f(x)=x^3-5x^2+7x-3$', '$r=1$'}, 'Interpreter', 'latex');
txt={'As we can see, \mid g''(r) \mid \approx 0.5 and \mid g''(r) \mid < 1.', 
    'We can then conclude that the convergence is linear.'};
text(5, 0.55, txt);
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error Ratios $\frac{\mid x_{i+1} - r \mid}{\mid x_i -r \mid}$', 'Interpreter', 'latex');

%% Question 4
m=2;
newton_multi2_approx=newton2(f, df, x0, nmax, epsilon, m);

nb_iterations_newton_multi2=1:1:length(newton_multi2_approx);
abs_error_newton_multi2=abs(newton_multi2_approx-r);

figure(6)
semilogy(nb_iterations_newton_multi1, abs_error_newton_multi1);
hold on;
semilogy(nb_iterations_newton_multi2, abs_error_newton_multi2);
hold off;
grid on; 
legend('Newton', 'Newton Multiplicity Adjustment')
title('Absolute Error Against The Number of Iterations', 'Interpreter', 'latex');
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error $\mid x_i - r \mid$', 'Interpreter', 'latex');

figure(7)
iteration_limit_newton_multi2=5;
ratio_indexes_newton_multi2=2:min(length(abs_error_newton_multi2), iteration_limit_newton_multi2);
abs_error_ratios_newton_multi2=abs_error_newton_multi2(ratio_indexes_newton_multi2)./abs_error_newton_multi2(ratio_indexes_newton_multi2-1).^2;
plot(ratio_indexes_newton_multi2, abs_error_ratios_newton_multi2);
axis([1 6 0 0.4]);
grid on; 
title({'Convergence Analysis - Newton Method with Multiplicity Adjustment', 'Root Multiplicity: 2', '$f(x)=x^3-5x^2+7x-3$', '$r=1$'}, 'Interpreter', 'latex');
txt={'It is possible to verify that \mid g''(r) \mid \approx 0.', 
    'We can also deduce from the current figure that \mid g''''(r) \mid \approx 0.25.',
    'We can then conclude that the convergence is quadratic.'};
text(1.5, 0.075, txt);
xlabel('Number of Iterations ($i$)', 'Interpreter', 'latex');
ylabel('Absolute Error Ratios $\frac{\mid x_{i+1} - r \mid}{\mid x_i -r \mid^2}$', 'Interpreter', 'latex');
