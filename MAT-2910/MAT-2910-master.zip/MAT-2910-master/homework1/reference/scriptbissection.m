% Programme bissection.m
% Exemple simple de programme 
% pour la m�thode de bissection
% f(x)= exp(x-3)-x,
%                       x1=0, x2=1.
%---------------------------------------------------------

% Initialisation et graphe de f
x1=0;x2=1;
f=@(x) exp(x-3)-x;
fplot(f,[0 1])
grid on; title('Graphe de la fonction f(x)=e^(x-3)-x');
xlabel('x');
ylabel('f(x)');
epsilon=2.6e-13; N=50;


% 1�re it�ration 
xm=(x1+x2)/2;
erabs=abs(x1-x2)/2;
errel=erabs/abs(xm);
nbiterations=1;

while (errel>epsilon) &(nbiterations <N)
          if f(x1)*f(xm)<0
              x2=xm;
          else
              if f(x2)*f(xm)<0
                 x1=xm;
              else
                  x1=xm;
                  x2=xm;
              end
          end
          xm=(x1+x2)/2;
          erabs=abs(x1-x2)/2;
          errel=erabs/abs(xm);
          nbiterations=nbiterations+1;
          fprintf('iteration %2d , xm= %1.6f , erabs= %1.2e , errel= %1.2e \n', nbiterations, xm, erabs, errel)
end
