precision = 1e-6;
k=[0.1 1.1 2.1 3.1 4.1 5.1];
tc=[0.2 0.4 0.6 0.8 1. 1.2 1.4 1.6 1.8 2];

nbk=size(k,2);
nbtc=size(tc,2);
tablo1=zeros(nbk,nbtc);
tablo2=zeros(nbk,nbtc);
tablo3=zeros(nbk,nbtc);
tablo4=zeros(nbk,nbtc);
tablo5=zeros(nbk,nbtc);
tablo7=zeros(nbk,nbtc);

%
% Pour II a) tableaux 1,2 3
%
for i=1:nbk
    % on parcourt toutes les valeurs de k demandées
    for j=1:nbtc
        % 
        % Point fixe (IIa)
        %
        % Partant de t=0
        [icompteur, taux] = pointFixe(0,tc(j),k(i),precision); 
        tablo1(i,j)=icompteur;
        tablo3(i,j)= taux; 
        % Partant de 3/k
        [icompteur] = pointFixe(3/k(i),tc(j),k(i),precision); 
        tablo2(i,j)=icompteur;
        % 
        % Fausse position (IIb)
        %
        % Partant de t=0
        [icompteur, taux] = fausse_position(0,tc(j),k(i),precision); 
        tablo4(i,j)=icompteur;
        tablo5(i,j)= taux; 
        % 
        % Newton (IIIa)
        %
        % Partant de t=3/k
        [icompteur,topt] = newton(3/k(i),tc(j),k(i),precision); 
        tablo7(i,j)=icompteur;
    end
end
