function [ ] = Question3(tc, k, precision)

% nombre de valeur de tc
nbtc = size(tc,2);

% on permet a l'usager de donner des valeurs de k specifiques
% sinon on en prend des valeurs sur [0.1,6] par pas de 0.1
if nargin < 2
    k=0.1:0.1:6;
end
nbk=size(k,2);

% on parcourt toute les valeurs de tc
for i=1:nbtc
    resultatj=zeros(nbk);
    % on parcourt toutes les valeurs de k demandées
    for j=1:nbk
        [nbiter,tn]=newton(3/k(j),tc(i),k(j),precision,1);
        % on dit quelque chose:
        fprintf('Pour tc=%d et k=%d, valeur de t_opt = %d\n',tc(i),k(j),tn); 
        % on stocke pour faire le graphe
        resultatj(j)=tn;
    end
    % on dessine
    plot(k,resultatj);
    grid on;
    xlabel('k');
    ylabel('t optimal');
    title('graphe de t optimal vs k');
    % On identifie chacune des courbes avec la valeur de tc
    etiket = sprintf('tc = %f',tc(i));
    i_pos = floor(0.1*nbk*(1+(mod(i,2))));  
    text(k(i_pos),resultatj(i_pos),etiket,'HorizontalAlignment','left')
    % pour que tous les graphes soit sur la même figure
    hold on;
end
% on remet le mode graphique ordinaire
hold off;
end

