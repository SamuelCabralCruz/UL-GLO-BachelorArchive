Il faut créer un projet exemple avec attolic true studio pour avoir le tool chain pour compiler ce code.

Il suffit ensuite de remplacer le dossier src/ par celui-ci.
