/*
 * timer.h
 *
 *  Created on: Nov 17, 2018
 *      Author: voidbuntu
 */

#ifndef TIMER_H_
#define TIMER_H_


void SYSTICK_init( void );
void TimingDelay_Decrement(void);
void Delay(volatile unsigned int nCount);
int getTime(void);
void timeIncrement();

#endif /* TIMER_H_ */
