/*
 * lcd.c
 *
 *  Created on: Nov 17, 2018
 *      Author: voidbuntu
 */
#include "stm32f4_discovery.h"
#include "lcd.h"
#include "timer.h"

#define EN 2
#define RS 1
#define RW 0
#define LCD GPIOE
#define LCD_RCC_GPIO RCC_AHB1Periph_GPIOE

// LCD D0 to D7
static uint16_t bus[8] = {GPIO_Pin_0, GPIO_Pin_1, GPIO_Pin_2, GPIO_Pin_3, GPIO_Pin_4, GPIO_Pin_5, GPIO_Pin_6, GPIO_Pin_7};

// LCD R/W, RS, EN
static uint16_t control[3] = {GPIO_Pin_8, GPIO_Pin_9, GPIO_Pin_10};

void LCD_clear(){
	uint16_t portValue = 0;
	portValue |= control[EN] | bus[0];
	GPIO_Write(LCD, portValue);
	LCD_apply(2);
	LCD_pinClear();
}
void LCD_home(){
	uint16_t portValue = 0;
	portValue |= control[EN] | bus[1];
	GPIO_Write(LCD, portValue);
	LCD_apply(2);
	LCD_pinClear();
}
void LCD_setCursor(uint8_t address){
	uint16_t portValue = 0;
	portValue |= bus[7];

	for(int i = 0; i < 7; i++){
			if((address & (1<<i)) != 0){
				portValue |= bus[i];
			}
	}

	GPIO_Write(LCD, portValue);
	LCD_apply(1);
	LCD_pinClear();
}

void LCD_put(char value){


	uint16_t portValue = 0;
	portValue |= control[RS];

	for(int i = 0; i < 8; i++){
		if((value & (1<<i)) != 0){
			portValue |= bus[i];
		}
	}

	GPIO_Write(LCD, portValue);
	LCD_apply(2);
	LCD_pinClear();
}

void LCD_write(char text[]){

	int i = 0;
	while(text[i] != '\0') LCD_put(text[i++]);
}

void LCD_initialise(){
	GPIO_InitTypeDef  GPIO_InitStructure;

	   //Initialise LCD GPIO
	  		RCC_AHB1PeriphClockCmd(LCD_RCC_GPIO, ENABLE);

	  				  GPIO_InitStructure.GPIO_Pin = bus[0] | bus[1] | bus[2] | bus[3]
	  						  	  	  	  	  	  | bus[4] | bus[5] | bus[6]| bus[7]
												  | control[0] | control[1] | control[2];
	  				  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	  				  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  				  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  				  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	  				  GPIO_Init(LCD, &GPIO_InitStructure);

	Delay(17);
	LCD_pinClear();

	//function mode
	GPIO_Write(LCD,  bus[5] | bus[4] | bus[3]); //0x38
	LCD_apply(7);
	LCD_pinClear();

	GPIO_Write(LCD,  bus[5] | bus[4] | bus[3]);
	LCD_apply(1);
	LCD_pinClear();

	GPIO_Write(LCD,  bus[5] | bus[4] | bus[3]);
	LCD_apply(1);
	LCD_pinClear();

	GPIO_Write(LCD,  bus[5] | bus[4] | bus[3]);
	LCD_apply(1);
	LCD_pinClear();

	//initialise display
	GPIO_Write(LCD,  bus[3] | bus[2] | bus[1]);
	LCD_apply(1);
	LCD_pinClear();

	//clear char memory
	LCD_clear();

	//initialise entry mode
	GPIO_Write(LCD,  bus[2] | bus[1]);
	LCD_apply(1);
	LCD_pinClear();



}

void LCD_pinClear(){
	GPIO_ResetBits(LCD, (uint16_t)(-1)); // reset tout
}

void LCD_apply(uint32_t delay){
	GPIO_SetBits(LCD, control[EN]);
	Delay(delay);
	GPIO_ResetBits(LCD, control[EN]);
	Delay(delay);

}

void LCD_firstLine(){
	LCD_home();
}

void LCD_secondLine(){
	LCD_setCursor(0b11000000);
}

void LCD_start(){
	LCD_home();
	LCD_clear();
	LCD_put('S');
	LCD_put('M');
	LCD_put('I');
	LCD_put('_');
	LCD_put('A');
	LCD_put('B');
	LCD_setCursor(0b11000000);
}
