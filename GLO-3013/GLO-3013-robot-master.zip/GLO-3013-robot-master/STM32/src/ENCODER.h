/*
 * ENCODER.h
 *
 *  Created on: Dec 4, 2018
 *      Author: voidbuntu
 */

#ifndef ENCODER_H_
#define ENCODER_H_

#define PERIOD_COUNT  1//16

void ENCODER0_init(void);
void ENCODER1_init(void);
void ENCODER2_init(void);
void ENCODER3_init(void);

int ENCODER_revolution_count(int encoder);
void ENCODER_revolution_inc(int encoder);
void ENCODER_revolution_reset(int encoder);

static int ENCODER_rpm(int time_ms, int revolutionNumber);

#endif /* ENCODER_H_ */
