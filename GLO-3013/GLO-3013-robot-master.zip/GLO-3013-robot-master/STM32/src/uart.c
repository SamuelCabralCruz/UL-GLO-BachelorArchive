/*
 * uart.c
 *
 *  Created on: Nov 23, 2018
 *      Author: voidbuntu
 */
#include "uart.h"
#include "stm32f4_discovery.h"
#include "main.h"






#define HEAD 0
#define TAIL 1
#define baud(x)

char *sendPointer;
char *receivePointer;
char bufferOverflowProtection[50];
char canary = 0xAA;
char bufferOverflowProtection[50];
// étant dans une intéruption, il est préférable de ne pas le vérifier ici

transmitAcquisition = 0;

void UART_startSending(void){
	dataToSend.payloadSize = sizeof(struct DataFrame)-1;
	sendPointer = (char*) &dataToSend;
	USART_SendData( USART1, *sendPointer);
	sendPointer++;
	USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
}

void UART_sending(void){

	if(sendPointer - (char *) &dataToSend == dataToSend.payloadSize){ // if end of struct
		USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
	}
	USART_SendData( USART1, *sendPointer);
	sendPointer++;

}

void UART_sendingAcquisition(void){
	if(acquisitionPointer < (((char *)acquisitionBuffer)+sizeof(struct AcquisitionFrame)*ACQUISITION_SAMPLE_SIZE)){
		USART_ITConfig(USART1, USART_IT_TXE, ENABLE);
		USART_SendData( USART1, *(acquisitionPointer-1));
		acquisitionPointer++;
	} else {
		USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
		transmitAcquisition = 0;
	}
}

void UART_receiving(void){
	newCommand = 0;
	char buff = (char) (USART_ReceiveData( USART1 ) & 0xFF);
	if(receivedCommand.payloadSize == 0){
		receivePointer = (char *) &receivedCommand;
	}
	if(receivePointer >= (char*) &receivedCommand + sizeof(struct CommandFrame) || receivePointer < &receivedCommand)
		receivePointer = (char *) &receivedCommand;
	*receivePointer = buff;
	receivePointer++;
	if(receivePointer == (char*) ((char *) &receivedCommand + sizeof(struct CommandFrame))){
		for(int i = 0; i < sizeof(struct CommandFrame); i++){
			((char*) &receivedCommandCopy)[i] = ((char*) &receivedCommand)[i];
		}
		newCommand = 1;
	}
}

void UART_panick(void){ // Dans le cas d'un buffer overflow.
	USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
	USART_ITConfig(USART1, USART_IT_RXNE, DISABLE);
}

void UART_sync(void){
	receivePointer = (char *) &receivedCommand;
}

void UART_init(void)
{


	GPIO_InitTypeDef 	GPIO_InitStruct;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);


	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);

	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);


	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);


	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStruct.USART_Parity = USART_Parity_Even; //USART_Parity_Even
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_9b;
	USART_Init(USART1, &USART_InitStruct);
	USART_OneBitMethodCmd(USART1, ENABLE);
	USART_Cmd(USART1, ENABLE);
	USART1->BRR = 0x5c << 4 ; // baudrate(9600/520) << 4 //0x2080 pour 9600

	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);



	NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStruct);
}
