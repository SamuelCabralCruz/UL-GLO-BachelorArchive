/*
 * CommunicationFrame.h
 *
 *  Created on: Feb 17, 2019
 *      Author: voidbuntu
 */

#ifndef COMMUNICATIONFRAME_H_
#define COMMUNICATIONFRAME_H_

struct __attribute__((__packed__)) DataFrame {		// double buffering
   char	  payloadSize;
   int	  adc;
   float  time;
};


struct __attribute__((__packed__)) CommandFrame {
	char	  payloadSize;
	int 	  command;
	int		  payload[4];
};

struct __attribute__((__packed__)) MoveFrame {
	char	  payloadSize;
	int 	  command;
	float	  position[2];
	float	  speed[2];
};

struct __attribute__((__packed__)) RotateFrame {
	char	  payloadSize;
	int 	  command;
	float	  speed;
	float	  cap;
	int	  	  pad[2];
};

struct __attribute__((__packed__)) AcquisitionFrame {
	float time;
	float speedX;
	float speedY;
	int encoder0;
	int encoder1;
	int encoder2;
	int encoder3;
};

#define COMMAND_READ 0
#define COMMAND_MOVE 1
#define COMMAND_ROTATE 2
#define COMMAND_WHEEL_ACQUISITION 3
#define COMMAND_WHEEL_READ_ACQUISITION 4

#endif /* COMMUNICATIONFRAME_H_ */
