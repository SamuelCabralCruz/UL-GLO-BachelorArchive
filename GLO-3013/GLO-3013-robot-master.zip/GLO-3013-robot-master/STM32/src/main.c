/**
  ******************************************************************************
  * @file    SysTick/main.c 
  * @author  MCD Application Team
  * @version V1.0.1
  * @date    15-May-2012
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************  
  */ 

/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include "ENCODER.h"
#include "timer.h"
#include "lcd.h"
#include "ADC.h"
#include "GPIO.h"
#include "PWM.h"
#include "CommunicationFrame.h"
#include "uart.h"
#include "Wheel.h"

/** @addtogroup STM32F4_Discovery_Peripheral_Examples
  * @{
  */

/** @addtogroup SysTick_Example
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
#define True 1
#define False 0

#define ABS(x) (x) < 0 ? -(x):(x)

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
struct DataFrame data;
struct MoveFrame target;

// None=0, continuous=1, discrete=2
#define PID_TYPE 1

#if PID_TYPE == 1
	struct PID {
		float speedError;
		float integratedError;
		float derivativeError;
		float p;
		float i;
		float d;
		float pid;
	} pid[4];
#endif




int isAcquisitionActivated = 0;



#define TIME_FRAME 25 //in ms was 50
//#define PWM_FREQ 65535
#define PWM_FREQ 18000 //990

#define X 0
#define Y 1


/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
int main(void)
{
	// init
	SYSTICK_init();
	Delay(100);
	ENCODER0_init();
	ENCODER1_init();
	ENCODER2_init();
	ENCODER3_init();
	ADC_init();
	GPIO_init();
	PWM0_init(PWM_FREQ, PWM_FREQ / 2);
	PWM1_init(PWM_FREQ, PWM_FREQ / 2);
	PWM2_init(PWM_FREQ, PWM_FREQ / 2);
	PWM3_init(PWM_FREQ, PWM_FREQ / 2);
	UART_init();
	WHEEL_init();

	acquisitionIndex = 0;

	float direction[2] = {1.0, 1.0};


	//const float wheelDiameter = 0.07;
	//const float wheelDivision = 6400;
	//const float wheelFactor = 3.14159*wheelDiameter/(wheelDivision/(float) PERIOD_COUNT); // Convert count to distance

	// mesurements variables from current iteration
	int revolutionCountBuffer[4] = {0, 0, 0, 0};
	//float relativePosition[4] = {0.0, 0.0, 0.0, 0.0};
	float relativeSpeed[4] = {0.0, 0.0, 0.0, 0.0};
	float timeInterval[4] = {0.0, 0.0, 0.0, 0.0};

	// PID variables

	#if PID_TYPE == 1

	// configs
		pid[0].p = 0.94053;//0.99998;
		pid[0].i = 0.5;//0.26681;//18.726;
		pid[0].d = 0;

		pid[1].p = 0.94053;//0.99998;
		pid[1].i = 0.5;//0.26681;//18.726;
		pid[1].d = 0;

		pid[2].p = 0.94053;//0.99998;
		pid[2].i = 0.5;//0.26681;//18.726;
		pid[2].d = 0;

		pid[3].p = 0.94053;//0.99998;
		pid[3].i = 0.5;//0.26681;//18.726;
		pid[3].d = 0;



		// curent error
		pid[0].speedError = relativeSpeed[0]-target.speed[Y];
		pid[1].speedError = relativeSpeed[1]-target.speed[X];
		pid[2].speedError = relativeSpeed[2]-target.speed[X];
		pid[3].speedError = relativeSpeed[3]-target.speed[Y];

		pid[0].integratedError = 0;
		pid[1].integratedError = 0;
		pid[2].integratedError = 0;
		pid[3].integratedError = 0;

		pid[0].derivativeError = 0;
		pid[1].derivativeError = 0;
		pid[2].derivativeError = 0;
		pid[3].derivativeError = 0;

		#endif


	while(1){

		if(newCommand == True){
			struct MoveFrame *command = (struct MoveFrame*) &receivedCommand;
			struct RotateFrame *commandr = (struct RotateFrame*) &receivedCommand;
			switch(receivedCommand.command){
			case COMMAND_READ:
				dataToSend.adc = data.adc;
				UART_startSending();
				break;
			case COMMAND_MOVE:

				target.position[X] = command->position[X];
				target.position[Y] = command->position[Y];
				target.speed[X] = command->speed[X];
				target.speed[Y] = command->speed[Y];

				if(target.speed[X] < 0){
					direction[X] = -1.0;
					target.speed[X] *= -1;
				} else if (target.speed[X] > 0){
					direction[X] = 1.0;
				} else{
					direction[X] = 0.0;
				}

				if(target.speed[Y] < 0){
					direction[Y] = -1.0;
					target.speed[Y] *= -1;
				} else if (target.speed[Y] > 0){
					direction[Y] = 1.0;
				} else{
					direction[Y] = 0.0;
				}


				WHEEL_direction(direction);

				break;

			case COMMAND_ROTATE:
				// à faire
				target.position[X] = 0;
				target.position[Y] = 0;

				int rotateDirection = commandr->speed > 0;
				if(!rotateDirection){
					commandr->speed *= -1.0;
				}

				target.speed[X] = commandr->speed;
				target.speed[Y] = commandr->speed;


				if(rotateDirection){
					WHEEL_rotate(1);
				} else {
					WHEEL_rotate(-1);
				}
				break;
			case COMMAND_WHEEL_ACQUISITION:
				isAcquisitionActivated = 1;
				acquisitionIndex = 0;
				acquisitionPointer = (char*) &acquisitionBuffer;
				break;
			case COMMAND_WHEEL_READ_ACQUISITION:
				isAcquisitionActivated = 0;
				acquisitionBuffer[acquisitionIndex+1].time = 0.0f;
				acquisitionPointer = (char*) &acquisitionBuffer;
				transmitAcquisition = 1;
				UART_sendingAcquisition();
				break;
			default:
				break;
			}

			newCommand = 0;
		}

		ENCODER_revolution_reset(0);
		ENCODER_revolution_reset(1);
		ENCODER_revolution_reset(2);
		ENCODER_revolution_reset(3);

		#if PID_TYPE == 0
			PWM_dutyCycle(TIM9, target.speed[Y]);
			PWM_dutyCycle(TIM13, target.speed[X]);
			PWM_dutyCycle(TIM5, target.speed[X]);
			PWM_dutyCycle(TIM14, target.speed[Y]);
		#elif PID_TYPE == 1
			PWM_dutyCycle(TIM9, pid[0].pid);
			PWM_dutyCycle(TIM13, pid[1].pid);
			PWM_dutyCycle(TIM5, pid[2].pid);
			PWM_dutyCycle(TIM14, pid[3].pid);
		#endif


		int timeStamp = getTime();
		Delay(TIME_FRAME);

		timeInterval[0] = ((float) getTime() - (float) timeStamp) * 0.001f; // in seconds
		revolutionCountBuffer[0] = ENCODER_revolution_count(0);

		timeInterval[1] = ((float) getTime() - (float) timeStamp) * 0.001f; // in seconds
		revolutionCountBuffer[1] = ENCODER_revolution_count(1); //APBH2 demande un ajustement

		timeInterval[2] = ((float) getTime() - (float) timeStamp) * 0.001f; // in seconds
		revolutionCountBuffer[2] = ENCODER_revolution_count(2);

		timeInterval[3] = ((float) getTime() - (float) timeStamp) * 0.001f; // in seconds
		revolutionCountBuffer[3] = ENCODER_revolution_count(3);


		relativeSpeed[0] = revolutionCountBuffer[0] / 30.0;
		relativeSpeed[1] = revolutionCountBuffer[1] / 30.0;
		relativeSpeed[2] = revolutionCountBuffer[2] / 30.0;
		relativeSpeed[3] = revolutionCountBuffer[3] / 30.0;


		// Only valid if there is a pid
		#if PID_TYPE > 0


			#if PID_TYPE == 1
				// error calculation
				pid[0].speedError = relativeSpeed[0]-target.speed[Y];
				pid[1].speedError = relativeSpeed[1]-target.speed[X];
				pid[2].speedError = relativeSpeed[2]-target.speed[X];
				pid[3].speedError = relativeSpeed[3]-target.speed[Y];



				// PID implementation
				for(int j = 0; j < 4; j++){
					pid[j].integratedError += (pid[j].speedError * TIME_FRAME / 1000.0);
					pid[j].pid = ABS(pid[j].p * pid[j].speedError +  pid[j].i * pid[j].integratedError + pid[j].d * pid[j].derivativeError);
				}

			#endif

		#endif

		dataToSend.time += timeInterval[0];

		if(isAcquisitionActivated && acquisitionIndex < ACQUISITION_SAMPLE_SIZE){
			acquisitionBuffer[acquisitionIndex].time = getTime()/1000.0f;
			acquisitionBuffer[acquisitionIndex].speedX = direction[X] * target.speed[X];
			acquisitionBuffer[acquisitionIndex].speedY = direction[Y] *  target.speed[Y];
			acquisitionBuffer[acquisitionIndex].encoder0 = revolutionCountBuffer[0];
			acquisitionBuffer[acquisitionIndex].encoder1 = revolutionCountBuffer[1];
			acquisitionBuffer[acquisitionIndex].encoder2 = revolutionCountBuffer[2];
			acquisitionBuffer[acquisitionIndex].encoder3 = revolutionCountBuffer[3];
			acquisitionIndex++;
		} else {
			isAcquisitionActivated = 0;
		}

		if(target.speed[X] != 0)
			target.speed[X] = target.speed[X];

		// update ADC
		data.adc = getADC();
		//UART_startSending();

	}
}

void forgetTarget(void){
	target.speed[0] = 0.0f;
	target.speed[1] = 0.0f;

	#if PID_TYPE == 1
	for(int j = 0; j < 4; j++){
		pid[j].speedError = 0.0;
		pid[j].integratedError = 0.0;
	}
	#endif
}


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
