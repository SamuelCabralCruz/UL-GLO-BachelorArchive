/*
 * Wheel.c
 *
 *  Created on: Feb 12, 2019
 *      Author: voidbuntu
 */

#include "Wheel.h"
#include "ENCODER.h"
#include "PWM.h"
#include "stm32f4_discovery.h"

#define X 0
#define Y 1

void WHEEL_init(void){
	GPIO_InitTypeDef  GPIO_InitStructure;

	/* GPIOD Periph clock enable */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

	  /* Configure PD12, PD13, PD14 and PD15 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10| GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	  GPIO_Init(GPIOE, &GPIO_InitStructure);

}

void WHEEL_rotate(int direction){

	if(direction >= 0){
		GPIO_ResetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
		GPIO_SetBits(GPIOE, GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_13 | GPIO_Pin_14);
	} else {
		GPIO_SetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
		GPIO_ResetBits(GPIOE, GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_13 | GPIO_Pin_14);
	}

}

void WHEEL_direction(float direction[2]){
	if(direction[X] > 0){
		GPIO_ResetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_10);
		GPIO_SetBits(GPIOE, GPIO_Pin_9 | GPIO_Pin_11);
	} else if(direction[X] < 0) {
		GPIO_SetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_10);
		GPIO_ResetBits(GPIOE, GPIO_Pin_9 | GPIO_Pin_11);
	} else {
		GPIO_ResetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_9 | GPIO_Pin_10);
	}

	if(direction[Y] < 0){
		GPIO_ResetBits(GPIOE, GPIO_Pin_12 | GPIO_Pin_14); // temporaire puisque mauvais câblage
		GPIO_SetBits(GPIOE, GPIO_Pin_13 | GPIO_Pin_15);
	} else if(direction[Y] > 0) {
		GPIO_SetBits(GPIOE, GPIO_Pin_12 | GPIO_Pin_14);
		GPIO_ResetBits(GPIOE, GPIO_Pin_13 | GPIO_Pin_15);
	} else {
		GPIO_ResetBits(GPIOE, GPIO_Pin_12 | GPIO_Pin_15 | GPIO_Pin_13 | GPIO_Pin_14);
	}


}

void WHEEL_stop(void){
	GPIO_ResetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10| GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15);
}
