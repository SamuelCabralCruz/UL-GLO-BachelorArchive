/*
 * PWM.h
 *
 *  Created on: Dec 8, 2018
 *      Author: voidbuntu
 */

#ifndef PWM_H_
#define PWM_H_

#include "stm32f4_discovery.h"

void PWM0_init(int cap, int level);
void PWM1_init(int cap, int level);
void PWM2_init(int cap, int level);
void PWM3_init(int cap, int level);
TIM_TypeDef* PWM0(void);
TIM_TypeDef* PWM1(void);
TIM_TypeDef* PWM2(void);
TIM_TypeDef* PWM3(void);
void PWM_dutyCycle(TIM_TypeDef*, float duty);

#endif /* PWM_H_ */
