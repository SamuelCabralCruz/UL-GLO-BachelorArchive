/*
 * ENCODER.c
 *
 *  Created on: Dec 4, 2018
 *      Author: voidbuntu
 */
#include "stm32f4_discovery.h"
#include "ENCODER.h"


volatile int revolutionCount[4] = {0, 0, 0, 0};


void ENCODER0_init(void){

      GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = 0;
	  TIM_TimeBaseStructure.TIM_Period = PERIOD_COUNT; 		//Overflow à 32 ou 31?
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

	  /* TIM2 options config */
	  TIM_SelectSlaveMode(TIM2, TIM_SlaveMode_External1);
	  TIM2->SMCR = TIM2->SMCR | 0b100000001110000;
	  TIM2->CR1 |= 0b100;

	  /* TIM2 alternative GPIO */
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_TIM2);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);


	  TIM_Cmd(TIM2, ENABLE);
	  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);


	  //flags set
	  ENCODER_revolution_reset(0);
}

void ENCODER1_init(void){
      GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = 0;
	  TIM_TimeBaseStructure.TIM_Period = PERIOD_COUNT; 		//Overflow à 32 ou 31?
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	  TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

	  /* TIM2 options config */
	  TIM_SelectSlaveMode(TIM1, TIM_SlaveMode_External1);
	  TIM1->SMCR = TIM1->SMCR | 0b100000001110000;
	  TIM1->CR1 |= 0b100;

	  /* TIM2 alternative GPIO */
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
		GPIO_PinAFConfig(GPIOE, GPIO_PinSource7, GPIO_AF_TIM1);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_Init(GPIOE, &GPIO_InitStructure);


	  TIM_Cmd(TIM1, ENABLE);
	  TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);


	  //flags set
	  ENCODER_revolution_reset(1);
}


void ENCODER2_init(void){
      GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = 0;
	  TIM_TimeBaseStructure.TIM_Period = PERIOD_COUNT; 		//Overflow à 32 ou 31?
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

	  /* TIM2 options config */
	  TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_External1);
	  TIM3->SMCR = TIM3->SMCR | 0b100000001110000;
	  TIM3->CR1 |= 0b100;

	  /* TIM2 alternative GPIO */
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
		GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_TIM3);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_Init(GPIOD, &GPIO_InitStructure);


	  TIM_Cmd(TIM3, ENABLE);
	  TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);


	  //flags set
	  ENCODER_revolution_reset(2);
}

void ENCODER3_init(void){
      GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = 0;
	  TIM_TimeBaseStructure.TIM_Period = PERIOD_COUNT; 		//Overflow à 32 ou 31?
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
	  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	  /* TIM2 options config */
	  TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_External1);
	  TIM4->SMCR = TIM4->SMCR | 0b100000001110000;
	  TIM4->CR1 |= 0b100;

	  /* TIM2 alternative GPIO */
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
		GPIO_PinAFConfig(GPIOE, GPIO_PinSource0, GPIO_AF_TIM4);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		GPIO_Init(GPIOE, &GPIO_InitStructure);


	  TIM_Cmd(TIM4, ENABLE);
	  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);


	  //flags set
	  ENCODER_revolution_reset(3);
}


int ENCODER_revolution_count(int encoder){
	return revolutionCount[encoder];
}

void ENCODER_revolution_inc(int encoder){
	revolutionCount[encoder]++;
}

void ENCODER_revolution_reset(int encoder){
	revolutionCount[encoder] = 0;
}


static int ENCODER_rpm(int time_ms, int revolutionNumber){
	float rev_cnt_save = revolutionNumber;
	float rpm = (rev_cnt_save/(float) time_ms)*60000;
	return (int) rpm;
}
