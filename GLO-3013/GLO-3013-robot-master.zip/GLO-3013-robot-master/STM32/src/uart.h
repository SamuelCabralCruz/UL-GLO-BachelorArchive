/*
 * uart.h
 *
 *  Created on: Nov 23, 2018
 *      Author: voidbuntu
 */

#ifndef UART_H_
#define UART_H_

#include "CommunicationFrame.h"

struct DataFrame dataToSend;
struct CommandFrame receivedCommand;
struct CommandFrame receivedCommandCopy;
int newCommand;
int transmitAcquisition;
char *acquisitionPointer;

void UART_init(void);
void UART_startSending(void);
void UART_sending(void);
void UART_receiving(void);
void UART_panick(void);
void UART_sync(void);
void UART_sendingAcquisition(void);



#endif /* UART_H_ */
