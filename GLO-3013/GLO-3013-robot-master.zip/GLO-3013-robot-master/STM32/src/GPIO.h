/*
 * GPIO.h
 *
 *  Created on: Nov 29, 2018
 *      Author: voidbuntu
 */

#ifndef GPIO_H_
#define GPIO_H_

void GPIO_init(void);

void GPIO_toggle(int id );
void GPIO_reset(int id );
void GPIO_set(int id );

#endif /* GPIO_H_ */
