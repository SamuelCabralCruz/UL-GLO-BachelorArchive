/*
 * timer.c
 *
 *  Created on: Nov 17, 2018
 *      Author: voidbuntu
 */

#include "timer.h"
#include "stm32f4_discovery.h"

static int time;
volatile unsigned int TimingDelay;

void SYSTICK_init( void ){
	if (SysTick_Config(SystemCoreClock / 1000))
	    {
	      /* Capture error */
	      while (1);
	    }

	time = 0;
}


void Delay(volatile unsigned int nCount)
{
	TimingDelay = nCount;

	  while(TimingDelay != 0);
}

int getTime(void){
	return time;
}

// would inline be appropriate?
void timeIncrement(){
	time++;
}

void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  {
    TimingDelay--;
  }
}
