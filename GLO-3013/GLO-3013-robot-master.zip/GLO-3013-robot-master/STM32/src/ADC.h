/*
 * ADC.h
 *
 *  Created on: Dec 8, 2018
 *      Author: voidbuntu
 */

#ifndef ADC_H_
#define ADC_H_

void ADC_init(void);

unsigned short getADC(void);



#endif /* ADC_H_ */
