/*
 * lcd.h
 *
 *  Created on: Nov 17, 2018
 *      Author: voidbuntu
 */

#ifndef LCD_H_
#define LCD_H_

#include "stm32f4_discovery.h"



void LCD_clear();
void LCD_home();
void LCD_setCursor(uint8_t address);
void LCD_put(char value);
void LCD_initialise();
void LCD_pinClear();
void LCD_apply(uint32_t delay);
void LCD_start();

void LCD_write(char text[]);

void LCD_firstLine();
void LCD_secondLine();

#endif /* LCD_H_ */
