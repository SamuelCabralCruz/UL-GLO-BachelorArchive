/*
 * PWM.c
 *
 *  Created on: Dec 8, 2018
 *      Author: voidbuntu
 */
#include "PWM.h"
#include "stm32f4_discovery.h"

void PWM0_init(int cap, int level){
		  int prescaler = 17;

		  GPIO_InitTypeDef  GPIO_InitStructure;

		  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		  TIM_OCInitTypeDef TIM_OCInitStructure;

		  NVIC_InitTypeDef NVIC_InitStructure;

		  /* TIM2 clock enable */
		  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE);

		  /* Enable the TIM2 gloabal Interrupt */
		  NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_TIM9_IRQn;
		  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
		  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
		  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		  NVIC_Init(&NVIC_InitStructure);

		  /* TIM2 time config */
		  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
		  TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
		  TIM_TimeBaseStructure.TIM_Period = cap;
		  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
		  TIM_TimeBaseInit(TIM9, &TIM_TimeBaseStructure);

		  TIM_PrescalerConfig(TIM9, prescaler, TIM_PSCReloadMode_Immediate);

		  /* Output Compare Timing Mode configuration: Channel1 */
		  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
		  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
		  TIM_OCInitStructure.TIM_Pulse = level;
		  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

		  TIM_OC1Init(TIM9, &TIM_OCInitStructure);

		  TIM_OC1PreloadConfig(TIM9, TIM_OCPreload_Disable);


		  /* TIM2 alternative GPIO */
		  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		  GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_TIM9);

		  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
		  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
		  GPIO_Init(GPIOA, &GPIO_InitStructure);


		  //TIM_ITConfig(TIM9, TIM_IT_Update | TIM_IT_CC1, ENABLE);
		  TIM_Cmd(TIM9, ENABLE);

}

void PWM1_init(int cap, int level){
	  int prescaler = 8;

	  GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	  TIM_OCInitTypeDef TIM_OCInitStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM8_UP_TIM13_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	  TIM_TimeBaseStructure.TIM_Period = cap;
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	  TIM_TimeBaseInit(TIM13, &TIM_TimeBaseStructure);

	  TIM_PrescalerConfig(TIM13, prescaler, TIM_PSCReloadMode_Immediate);

	  /* Output Compare Timing Mode configuration: Channel1 */
	  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	  TIM_OCInitStructure.TIM_Pulse = level;
	  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

	  TIM_OC1Init(TIM13, &TIM_OCInitStructure);

	  TIM_OC1PreloadConfig(TIM13, TIM_OCPreload_Disable);


	  /* TIM2 alternative GPIO */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	  GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_TIM13);

	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);


	  //TIM_ITConfig(TIM13, TIM_IT_Update | TIM_IT_CC1, ENABLE);
	  TIM_Cmd(TIM13, ENABLE);
}

void PWM2_init(int cap, int level){
	  int prescaler = 8;

	  GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	  TIM_OCInitTypeDef TIM_OCInitStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	  TIM_TimeBaseStructure.TIM_Period = cap;
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	  TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

	  TIM_PrescalerConfig(TIM5, prescaler, TIM_PSCReloadMode_Immediate);

	  /* Output Compare Timing Mode configuration: Channel1 */
	  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	  TIM_OCInitStructure.TIM_Pulse = level;
	  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

	  TIM_OC1Init(TIM5, &TIM_OCInitStructure);

	  TIM_OC1PreloadConfig(TIM5, TIM_OCPreload_Disable);

	  /* TIM2 alternative GPIO */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	  GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_TIM5);

	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);

	  //TIM_ITConfig(TIM5, TIM_IT_Update | TIM_IT_CC1, ENABLE);
	  TIM_Cmd(TIM5, ENABLE);

}

void PWM3_init(int cap, int level){
	  int prescaler = 8;

	  GPIO_InitTypeDef  GPIO_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	  TIM_OCInitTypeDef TIM_OCInitStructure;

	  NVIC_InitTypeDef NVIC_InitStructure;

	  /* TIM2 clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);


	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM8_UP_TIM13_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* Enable the TIM2 gloabal Interrupt */
	  NVIC_InitStructure.NVIC_IRQChannel = TIM8_CC_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* TIM2 time config */
	  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
	  TIM_TimeBaseStructure.TIM_Period = cap;
	  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	  TIM_TimeBaseInit(TIM14, &TIM_TimeBaseStructure);

	  TIM_PrescalerConfig(TIM14, prescaler, TIM_PSCReloadMode_Immediate);

	  /* Output Compare Timing Mode configuration: Channel1 */
	  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	  TIM_OCInitStructure.TIM_Pulse = level;
	  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

	  TIM_OC1Init(TIM14, &TIM_OCInitStructure);

	  TIM_OC1PreloadConfig(TIM14, TIM_OCPreload_Disable);

	  /* TIM2 alternative GPIO */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	  GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_TIM14);

	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_Init(GPIOA, &GPIO_InitStructure);

	  //TIM_ITConfig(TIM8, TIM_IT_Update | TIM_IT_CC1, ENABLE);
	  TIM_Cmd(TIM14, ENABLE);

}


void PWM_dutyCycle(TIM_TypeDef* tim, float duty){
	// in bounds?
	duty = duty < 0.0 ? 0.0 : duty;
	duty = duty > 1.0 ? 1.0 : duty;

	// Set duty
	tim->CCR1 = (uint32_t) (duty* (float) ((uint32_t) tim->ARR ));
}
