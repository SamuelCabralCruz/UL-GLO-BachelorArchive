/*
 * Wheel.h
 *
 *  Created on: Feb 12, 2019
 *      Author: voidbuntu
 */

#ifndef WHEEL_H_
#define WHEEL_H_

void WHEEL_init(void);
void WHEEL_rotate(int direction);

void WHEEL_direction(float direction[2]);

void WHEEL_stop(void);

#endif /* WHEEL_H_ */
