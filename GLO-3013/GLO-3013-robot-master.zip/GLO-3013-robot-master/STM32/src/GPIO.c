/*
 * GPIO.c
 *
 *  Created on: Nov 29, 2018
 *      Author: voidbuntu
 */

#include "GPIO.h"
#include "stm32f4_discovery.h"
#include "stm32f4xx_syscfg.h"

void GPIO_init(void){
	GPIO_InitTypeDef  GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* GPIOD Periph clock enable */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

	  /* Configure PD12, PD13, PD14 and PD15 in output pushpull mode */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	  GPIO_Init(GPIOD, &GPIO_InitStructure);

	  /* GPIOD Periph clock enable */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

	  /* Configure PB11, PB13, PB15 input pushpull mode */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_13| GPIO_Pin_15;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	  GPIO_Init(GPIOB, &GPIO_InitStructure);

	  // setup GPIOB pin 15 as external interupt
	  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource15);

	    /* PB15 is connected to EXTI_Line15 */
	    EXTI_InitStruct.EXTI_Line = EXTI_Line15;
	    /* Enable interrupt */
	    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	    /* Interrupt mode */
	    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	    /* Triggers on rising and falling edge */
	    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
	    /* Add to EXTI */
	    EXTI_Init(&EXTI_InitStruct);

		  // setup GPIOB pin 13 as external interupt
		  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource13);

		    /* PB15 is connected to EXTI_Line15 */
		    EXTI_InitStruct.EXTI_Line = EXTI_Line13;
		    /* Enable interrupt */
		    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
		    /* Interrupt mode */
		    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
		    /* Triggers on rising and falling edge */
		    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
		    /* Add to EXTI */
		    EXTI_Init(&EXTI_InitStruct);

	  /* configure 15 as interupt */
	  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);


}

void GPIO_toggle(int id ){
	switch(id){
	case 0:
			GPIO_ToggleBits(GPIOD, GPIO_Pin_13);
			break;
	case 1:
			GPIO_ToggleBits(GPIOD, GPIO_Pin_14);
			break;
	case 2:
			GPIO_ToggleBits(GPIOD, GPIO_Pin_15);
			break;
	case 3:
			GPIO_ToggleBits(GPIOD, GPIO_Pin_12);
			break;
	}
}

void GPIO_reset(int id ){
	switch(id){
	case 0:
			GPIO_ResetBits(GPIOD, GPIO_Pin_13);
			break;
	case 1:
			GPIO_ResetBits(GPIOD, GPIO_Pin_14);
			break;
	case 2:
			GPIO_ResetBits(GPIOD, GPIO_Pin_15);
			break;
	case 3:
			GPIO_ResetBits(GPIOD, GPIO_Pin_12);
			break;
	}
}

void GPIO_set(int id ){
	switch(id){
	case 0:
			GPIO_SetBits(GPIOD, GPIO_Pin_13);
			break;
	case 1:
			GPIO_SetBits(GPIOD, GPIO_Pin_14);
			break;
	case 2:
			GPIO_SetBits(GPIOD, GPIO_Pin_15);
			break;
	case 3:
			GPIO_SetBits(GPIOD, GPIO_Pin_12);
			break;
	}
}

