import socket

from time import sleep
from socket_client import SocketClient

test=0

client = SocketClient(host="192.168.1.33", port=8888)

def on_answer(event):
    if (event["result"] == "Connected"):
        print("Server :",event["result"])
    else:
        print('got answer result', event["result"])

client.connect("answer", on_answer)
sleep(2)
client.send({"event":"connected"})

while True:
    #client.send({"event":"move"})
    sleep(1)
