import json
import socket

from time import sleep
from threading import Thread

from socket_communication import SocketClient, InvalidTransferData


class Communication():

    def __init__(self, host="192.168.1.33", port=8888, connections=1):
        self.buf = []
        self.socket = socket.socket()
        self.socket.bind((host, port))
        self.socket.listen(connections)
        self.connections = []
        self.accept()
        self.conn.connect(self._load)

    def accept(self):
        connection, adress = self.socket.accept()
        client = SocketClient(connection=connection)
        self.connections.append(client)
        self.conn = client

    def send(self,data):
        self.conn.send(data)
        
    def recv(self):
        if (len(self.buf)!=0):
            return self.buf.pop(0)

    def _load(self,event):
        self.buf.append(event)


#server = Communication()

#while True:
 #   data = server.recv()
  #  if (data != None):
   #     if (data["event"] == "connected"):
    #        server.send({"event" : "answer", "result" : "Connected"})
     #       print("Client Connected")
      #  elif (data["event"] == "move"):
       #     server.send({"event" : "answer", "result" : "move ok"})
        #else:
         #   print("event = ",data["event"])
   # sleep(1)
