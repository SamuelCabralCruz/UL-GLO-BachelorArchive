import json
import socket

from time import sleep
from threading import Thread

from socket_client import SocketClient, InvalidTransferData


class SocketServer():

    def __init__(self, host, port, connections=1):
        self.socket = socket.socket()
        self.socket.bind((host, port))
        self.socket.listen(connections)
        self.connections = []

    def accept(self):
        connection, adress = server.socket.accept()
        client = SocketClient(connection=connection)
        self.connections.append(client)
        return client

    def send_all(self, data):
        if len(self.connections) == 0:
            return

        self.connections[0]._validate_data(data)

        for connection in self.connections:
            connection.data_queue.append(data)


server = SocketServer("192.168.1.33", 8888)

connection = server.accept()

def on_hi(event):
    print("event :",event["event"])
    connection.send({
        "event": "answer",
        "result": 1
    })
def on_connect(event):
    print("Client :",event["event"])
    connection.send({
        "event": "answer",
        "result": "Connected"
    })

connection.connect("hi", on_hi)
connection.connect("connected", on_connect)

connection.send({
    "event": "greet",
    "message": "hello!",
})

##sleep(4)
##print('global server call')
##server.send_all({
##    "event": "greet",
##    "message": "hello!",
##})

while True:
    sleep(1)
