
import RPi.GPIO as GPIO

class PWM:

	def __init__(self, pinID, frequency, dutyCycle):
		#assert dutyCycle >= 0 and dutyCycle <= 1
		GPIO.setmode(GPIO.BCM)
		GPIO.setup(pinID, GPIO.OUT)

		self.pwm = GPIO.PWM(pinID, frequency)
		self.dutyCycle = dutyCycle
		self.pwm.start(dutyCycle)

	def setDutyCycle(self, dutyCycle):
		#assert dutyCycle >= 0 and dutyCycle <= 1
		self.dutyCycle = dutyCycle
		self.pwm.ChangeDutyCycle(dutyCycle)
