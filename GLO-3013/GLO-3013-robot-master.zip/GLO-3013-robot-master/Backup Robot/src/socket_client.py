import json
import socket

from time import sleep
from threading import Thread


class SocketClient():

    def __init__(self, host=None, port=None, connection=None, frequency=60):
        self.length_info_size = 4
        self.data_queue = []
        self.event_callbacks = {}
        self.sleep_time = 1 / frequency
        self.on_close_callbacks = []
        self.unexpected_callbacks = []

        if connection is None:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
        else:
            self.socket = connection

        self.closed = False
        self.receive_thread = Thread(target=self._loop)
        self.receive_thread.daemon = True
        self.receive_thread.start()

    def send(self, event_name, data={}):
        self.data_queue.append(self._build_message(event_name, data))

    def connect(self, event_name, callback):
        if self.event_callbacks.get(event_name) is None:
            self.event_callbacks[event_name] = [callback]
        else:
            self.event_callbacks[event_name].append(callback)

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True
        self.socket.close()
        for callback in self.on_close_callbacks:
            self._async_execution(callback)

    def bind_to_close(self, callback):
        self.on_close_callbacks.append(callback)

    def bind_to_unexpected_events(self, callback):
        self.unexpected_callbacks.append(callback)

    def _loop(self):
        while not self.closed:
            sleep(self.sleep_time)
            data = self.data_queue if len(self.data_queue) > 0 else None
            self.data_queue = []

            try:
                self._send(data)
            except ConnectionResetError:
                break

            try:
                data_received = self._receive()
            except (ConnectionAbortedError, ConnectionResetError):
                break
            else:
                if data_received is not None:
                    self._process_received_data(data_received)

        if not self.closed:
            self.close()

    def _build_message(self, event_name, data):
        return {
            "event": event_name,
            "data": data,
        }

    def _process_received_data(self, messages):
        for message in messages:
            event_name = message.get("event")
            data = message.get("data")
            callbacks = self.event_callbacks.get(event_name)

            if callbacks is not None:
                for callback in callbacks:
                    self._async_execution(callback, data)
            else:
                for callback in self.unexpected_callbacks:
                    self._async_execution(callback, event_name, data)

    def _async_execution(self, callback, *args):
        #callback(*args)
        new_thread = Thread(target=callback, args=args)
        new_thread.daemon = True
        new_thread.start()

    def _send(self, data):
        bytes_data = json.dumps(data).encode()
        length = len(bytes_data)

        if not self.socket._closed:
            self.socket.sendall(self._get_size_info(length) + bytes_data)

    def _receive(self):
        if self.socket._closed:
            return None

        bytes_length = self._receive_all(self.length_info_size)
        length = self._get_length(bytes_length)

        bytes_data = self._receive_all(length)

        return json.loads(bytes_data.decode()) if len(bytes_data) > 0 else None

    def _receive_all(self, length):
        buffer = b""

        while length > 0:
            bytes_read = self.socket.recv(length)
            buffer += bytes_read
            length -= len(bytes_read)

        return buffer

    def _get_size_info(self, length):
        byte_values = [int(length / (255**x)) % 255 for x in range(0, self.length_info_size)]
        return bytes(byte_values)

    def _get_length(self, size_bytes):
        length = 0
        power = 1
        for value in size_bytes:
            length += value * power
            power *= 255
        return length
