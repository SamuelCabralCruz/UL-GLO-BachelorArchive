from STM32 import STM32
import threading
import time

class ADC(threading.Thread):
	def __init__(self, stm, sampleFrequency=60):
		super().__init__()
		self.daemon = True
		self.stm = stm
		self.period = 1/sampleFrequency

	def run(self):
		self._takeSample()

	def _takeSample(self):
		while True:
			time.sleep(self.period)
			self.stm._update()
			self.value = self.stm.getADC()

	def read(self):
		return self.value