
import cv2

class View:

	def __init__(self):
		self.camera = cv2.VideoCapture(0)
		self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 2000)
		self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 2000)

	def getImage(self):
		for i in range(4):
			self.camera.grab()
		ret, image = self.camera.read()
		return image
