#!/usr/bin/python3

from Serial import Serial
import struct
import time
import json
from threading import Thread, Lock
import os

s = Serial("/dev/ttyUSB0", 57600)
s.open()
s.read()
time.sleep(0.01)


move = struct.pack('=ciffff', b'\x14', 1, 0, 0, 1, 0)
probe = struct.pack('=ciiiii', b'\x14', 0, 0, 0, 0, 0)
acq = struct.pack('=ciiiii', b'\x14', 3, 0, 0, 0, 0)
readAcq = struct.pack('=ciiiii', b'\x14', 4, 0, 0, 0, 0)

forward = struct.pack('=ciffff', b'\x14', 1, 0, 0, 0.5, 0)
backward = struct.pack('=ciffff', b'\x14', 1, 0, 0, -0.5, 0)
left = struct.pack('=ciffff', b'\x14', 1, 0, 0, 0, 0.5)
right = struct.pack('=ciffff', b'\x14', 1, 0, 0, 0, -0.5)
stop = struct.pack('=ciffff', b'\x14', 1, 0, 0, 0, 0)

s.write(stop)
time.sleep(1)

s.write(acq)
time.sleep(0.2)

s.write(forward)
time.sleep(1)
s.write(backward)
time.sleep(1)
s.write(left)
time.sleep(1)
s.write(right)
time.sleep(1)
s.write(stop)
time.sleep(1)


s.write(readAcq)
time.sleep(6)


data = s.read()
#if( data != [] ):
#	print(data)


while data !=[]:
	i = struct.unpack("=fffIIII", b''.join(data[0:28]))
	data = data[28::]
	os.system('echo "'+str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3])+','+str(i[4])+','+str(i[5])+','+str(i[6])+'" >> testAqu.log')
