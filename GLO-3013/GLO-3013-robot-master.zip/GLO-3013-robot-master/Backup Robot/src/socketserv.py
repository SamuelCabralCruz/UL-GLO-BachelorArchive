import json
import socket
import sys
import logging
import random

logging.basicConfig(format='%(asctime)s %(message)s', level=logging.DEBUG)

from time import sleep
from threading import Thread

from brain.socket_client import SocketClient


class SocketServer():

    def __init__(self, host, port, connections=1):
        self.socket = socket.socket()
        self.socket.bind((host, port))
        self.socket.listen(connections)
        self.max_connections = connections
        self.connections = []

    def accept(self):
        connection, adress = server.socket.accept()
        client = SocketClient(connection=connection)
        self._new_connection(client)
        return client

    def close(self):
        for connection in self.connections:
            connection.close()

        self.socket.close()

    def send_all(self, event_name, data):
        if len(self.connections) == 0:
            return

        message = self.connections[0]._build_message(event_name, data)

        for connection in self.connections:
            connection.data_queue.append(message)

    def _new_connection(self, connection):
        connection.bind_to_close(lambda: self._clean_connection(connection))
        self.connections.append(connection)

    def _clean_connection(self, connection):
        self.connections.remove(connection)


port = int(sys.argv[1])

socket.setdefaulttimeout(1)

server = SocketServer(socket.gethostname(), port)

logging.info("server is ready")

while True:
    connection = None

    try:
        connection = server.accept()
        logging.info("client connected")
    except socket.timeout:
        pass

    if connection is not None:

        def event_received(event, data):
            print("Received event ->", event)
            print("                 ", data)

        connection.bind_to_unexpected_events(event_received)

        while True:
            event = input("send event ->")
            try:
                data = json.loads(input("data:"))
            except json.JSONDecodeError:
                data = {}
                print("error decoding json, setting data to ", data)

            if connection.is_closed():
                break
            else:
                connection.send(event, data)

        logging.info("waiting for a new connection")
