from GPIO import GPIO

class LED:

	def __init__(self, pinID):
		self.io = GPIO(pinID, "OUT", "UP")
		self.state = False

	def on(self):
		self.state = True
		self.io.set(True)

	def off(self):
		self.state = False
		self.io.set(False)

	def toggle(self):
		if self.state == True:
			self.off()
		else:
			self.on()
