import sys
sys.path.insert(0, '../')
from GPIO import GPIO
from LED import LED

print("============ TEST LED ===============")

led = LED(24)
readingPin = GPIO(23, "IN", "DOWN")

# Set LED on
led.on()
assert readingPin.get() == True
print("PASS: LED on")

# Set LED off
led.off()
assert readingPin.get() == False
print("PASS: LED off")

# toggle LED
led.toggle()
assert readingPin.get() == True
led.toggle()
assert readingPin.get() == False
print("PASS: LED toggle")
