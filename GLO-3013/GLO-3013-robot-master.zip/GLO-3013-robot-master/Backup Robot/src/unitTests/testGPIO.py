import sys
sys.path.insert(0, '../')
from GPIO import GPIO
import time
from multiprocessing import Process



# To do this test, pin 23 and 24 must be wired on the Rasberry pi
print("============ TEST GPIO ==============")


def interuptTest(io):
	time.sleep(2)
	io.set(False)
	io.set(True)
	time.sleep(5)
	print("Fail: interupt time out reached")
	return 1


# PULL UP/DOWN test
IN = GPIO(23, "IN", "UP")
OUT = GPIO(24, "IN", "UP")

assert IN.get() == True

IN = GPIO(23, "IN", "DOWN")
OUT = GPIO(24, "IN", "DOWN")

assert IN.get() == False

print("PASS: pull direction")

IN = GPIO(23, "IN", "DOWN")
OUT = GPIO(24, "OUT", "DOWN")


# read/write test
OUT.set(False)
assert IN.get() == False

OUT.set(True)
assert IN.get() == True

print("PASS: get/set")


#interupt test
IN.enableInterupt("RISING")
outProcess = Process(target=interuptTest, args=(OUT,))

outProcess.start()
timeStamp = time.time()
IN.interuptWait() #infinite loop if fail. Child will notify if such is the case
assert time.time() - timeStamp > 1
outProcess.terminate()
print("PASS: interupt")



#Tests invalid state
io = GPIO
io = GPIO(23, "OUT", "DOWN")


try:
	io = GPIO(23, "OUT", "DOWN")
	io.enableInterupt("RISING")
	print("FAIL: interupt enabled, but it's an output")
except :
	print("PASS: throw on invalid state")


