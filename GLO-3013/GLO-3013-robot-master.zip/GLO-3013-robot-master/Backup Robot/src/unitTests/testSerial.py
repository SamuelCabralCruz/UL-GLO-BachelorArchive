import sys
sys.path.insert(0, '../')
from Serial import Serial
import struct


print("============ TEST SERIAL ============")

usb_uart = Serial("/dev/ttyUSB0", 9600)

# Test done with the USB/UART component and an uart analyser.
# A good frame detected on the analyser prove the USB function properly along with the UART.

try:
	usb_uart.open()
	print("PASS: usb socket connected")
except:
	print("Failed to open the usb socket")

# send 4 char + '\0'
testFrame = struct.pack('ccccc', b'P', b'A', b'S', b'S', b'\0')
usb_uart.write(testFrame)

print("frame sent")


# read to be tested with STM32
buff = []
while len(buff) < 5:
	byte = usb_uart.read()
	if( byte != [] ):
		buff.append(byte)

print(buff)


try:
	usb_uart.close()
	print("PASS: usb socket closed")
except:
	print("Failed to close the usb socket")

