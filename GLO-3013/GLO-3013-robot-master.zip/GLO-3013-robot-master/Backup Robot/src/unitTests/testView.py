import sys
sys.path.insert(0, '../')
from View import View

print("============ TEST VIEW ==============")

view = View()
print("PASS: open the camera")

image = view.getImage()
assert str(type(image)) == "<class 'numpy.ndarray'>"
print("PASS: valid data type (<class 'numpy.ndarray'>)")

