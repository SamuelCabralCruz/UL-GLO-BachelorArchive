import os

# 2>&1 write stderr to stdout
print("============ TEST BEGIN ==============")
os.system("python3 testGPIO.py 2>&1 > testResult")
os.system("python3 testSerial.py 2>&1 >> testResult")
os.system("python3 testLED.py 2>&1 >> testResult")
os.system("python3 testView.py 2>&1 >> testResult")
