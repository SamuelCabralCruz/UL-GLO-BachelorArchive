import RPi.GPIO


class GPIO:

	def __init__(self, pinID, IO_direction, pull="DOWN"):

		self.pinID = pinID
		self.IO_direction = self._IN_OUT(IO_direction)
		self.pull = self._pull(pull)
		self.interupt = False

		RPi.GPIO.setmode(RPi.GPIO.BCM)
		RPi.GPIO.setwarnings(False)
		if IO_direction == "IN":
			RPi.GPIO.setup(pinID, self.IO_direction, pull_up_down=self.pull)
		else:
			RPi.GPIO.setup(pinID, self.IO_direction)

	def enableInterupt(self, interuptEdge):
		assert self.IO_direction == self._IN_OUT("IN")
		self.interupt = True
		self.interuptEdge = self._edge(interuptEdge)

	def interuptWait(self):
		assert self.interupt == True
		RPi.GPIO.wait_for_edge(self.pinID, self.interuptEdge)

	def set(self, value):
		assert self.IO_direction == self._IN_OUT("OUT")
		if value == True:
			RPi.GPIO.output(self.pinID, RPi.GPIO.HIGH)
		else:
			RPi.GPIO.output(self.pinID, RPi.GPIO.LOW)

	def get(self):
		assert self.IO_direction == self._IN_OUT("IN")
		return RPi.GPIO.input(self.pinID)

	def _IN_OUT(self, IO_direction):
		assert IO_direction == "IN" or IO_direction == "OUT"
		if IO_direction == "IN":
			IO_direction = RPi.GPIO.IN
		else:
			IO_direction = RPi.GPIO.OUT
		return IO_direction

	def _pull(self, pull):
		assert pull == "UP" or pull == "DOWN"
		if pull == "UP":
			pull = RPi.GPIO.PUD_UP
		else:
			pull = RPi.GPIO.PUD_DOWN
		return pull

	def _edge(self, edge):
		assert edge == "RISING" or edge == "FALLING" or edge == "BOTH"
		if edge == "RISING":
			edge = RPi.GPIO.RISING
		elif edge == "FALLING":
			edge = RPi.GPIO.FALLING
		else:
			edge = RPi.GPIO.BOTH
		return edge
