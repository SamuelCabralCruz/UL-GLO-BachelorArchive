from Serial import Serial
from GPIO import GPIO
import struct
import time

class STM32:
	dataPosition = {'payloadSize':0,'adc':1,'time':2}
	command = {'update':0, 'move':1, 'rotate':2}
	updateFrame = struct.pack('=ciiiii', b'\x14', command['update'], 0, 0, 0, 0)


	def __init__(self, serialPath, baudrate):
		# delay could need adjustment
		self.serial = Serial(serialPath, baudrate, 0.1)
		self.serial.open()
		self.adcValue = 0.0
		self.syncInterupt = GPIO(17, "OUT")
		self.stopInterupt = GPIO(27, "OUT")
		self.syncInterupt.set(False)
		self.stopInterupt.set(False)

		self.adcValue = 0
		self.speedX = 0
		self.speedY = 0
		self.positionX = 0
		self.positionY = 0

	def sync(self):
		self.syncInterupt.set(True)
		self.syncInterupt.set(False)

	def stop(self):
		self.stopInterupt.set(True)
		time.sleep(0.01)
		self.stopInterupt.set(False)

	def _update(self):
		# flush buffer
		self.serial.read()

		# get stm32 state
		self.serial.write(self.updateFrame)
		time.sleep(0.05)
		data = self.serial.read()
		if len(data) == 9:
			data = struct.unpack("=cif", b''.join(data))
			# TODO determine the range to squash it between 0 and 1
			self.adcValue = data[self.dataPosition['adc']]/4095
			self.robotTime = data[self.dataPosition['time']]

	def getSpeed(self):
		return [self.speedX, self.speedY]

	def getPosition(self):
		return [self.positionX, self.positionY]

	def getADC(self):
		return self.adcValue

	def move(self, speed, distance):
		self.serial.write(struct.pack('=ciffff', b'\x14', self.command['move'], distance[0], distance[1], speed[0], speed[1]))

	def rotate(self, speed, cap):
		self.serial.write(struct.pack('=ciffff', b'\x14', self.command['rotate'], speed, 0, 0, 0))
