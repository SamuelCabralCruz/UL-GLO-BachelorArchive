from communication import Communication
from Camera import Camera
from MotorPlatform import MotorPlatform
from STM32 import STM32
from LED import LED
from pyzbar.pyzbar import decode
from Charger import Charger
from Gripper import Gripper
from pathlib import Path
import logging
import time
import socket
import cv2
import base64

class CommandProcessor:

	def __init__(self):

		# init mouvement systems
		stm = STM32("/dev/ttyUSB0", 57600)
		self.motorPlatform = MotorPlatform(stm)

		# init vision systems
		self.camera = Camera()
		self.camera.start()
		self.camera.rotate("YAW", 0);
		self.camera.rotate("PITCH", 0);

		# init signal systems
		self.doneLED = LED(23)

		# init communication sytems
		self.server = Communication("192.168.1.33",8888) #192.168.1.33
		socket.setdefaulttimeout(1)

		# init charging system
		self.charger = Charger(stm, 3.3)

		#init gripping system
		#logging.error("The gripper servo is not integrated into Gripper class. You've been warned!")
		#self.gripper = Gripper(20,21,26,None)
		#self.gripper.retract()
		#time.sleep(0.5)
		#self.gripper.extend()




		self.main()

	def main(self):
		while True:
			self.connection = None

			try:
				self.connection = self.server.accept()
				print("client connected")
			except socket.timeout:
				pass

			if self.connection is not None:
	
				self.connection.connect("move",self.move)
				self.connection.connect("rotate",self.rotate)
				self.connection.connect("get_camera_capture", self.capture_camera)
				self.connection.connect("is_ready", self.ready)
				self.connection.connect("freeze", self.freeze)
				self.connection.connect("set_led", self.set_led)
				self.connection.connect("read_qr", self.read_qr)
				self.connection.connect("rotate_camera", self.rotate_camera)
				self.connection.connect("get_error", self.get_error)
				self.connection.connect("gripper", self.set_gripper)
				self.connection.connect("get_gripper_state", self.get_gripper_state)
				self.connection.connect("start_charging", self.start_charging)
				self.connection.connect("stop_charging", self.stop_charging)
				self.connection.connect("test",self.test)

			try:
				while self.connection.is_closed() == False:
					time.sleep(.5)
			except socket.timeout:
				print("connection lost. Waiting for connection...")

	def move(self, param):
		print("move :", param)
		#self.server.send("answer","")
		self.motorPlatform.move([ -1 * param['max_speed_x'], param['max_speed_y']])
		

	def rotate(self, param):
		print("rotate :", param)
		self.motorPlatform.rotate(param['direction'], 0, param['max_speed'])

	def capture_camera(self, param):
		print("capture")
		self.server.send("camera_capture",{"camera_capture" : base64.b64encode(self.camera.getImage()).decode("utf-8")})

	def rotate_camera(self, param):
		print("rotate camera :", param)
		self.camera.rotate("YAW", param["yaw"])
		self.camera.rotate("PITCH", param["pitch"])

	def ready(self, param):
		print("sending ready signal")
		self.server.send("ready", {})

	def freeze(self, param=None):
		print("freeze")
		self.motorPlatform.stop()

	def set_led(self, param):
		print("set led :", param)
		if(param['enabled']):
			self.doneLED.on()
		else:
			self.doneLED.off()

	def read_qr(self, param):
		try:
			self.server.send("qr_content_read", {"qr":str(decode(self.camera.getImage())[0].data, 'utf-8')})
		except IndexError:
			self.server.send("qr_content_read", {"qr":None})
	
	def test(self, data):
                self.server.send("answer","Connected")

	def get_error(self, param):
		self.server.send("error_log", {"error":Path("/home/pi/bin/error.log").read_text()})

	def set_gripper(self, param):
		if(param['action'] == "extend"):
			self.gripper.extend()
		elif(param['action'] == "retract"):
			self.gripper.retract()
		elif(param['action'] == "on"):
			self.gripper.on()
		elif(param['action'] == "off"):
			self.gripper.off()

	def get_gripper_state(self):
		state = {'position':None, 'state':None}
		state['position'] = self.gripper.state.lower()
		if( self.gripper.gripperPin.state == True ):
			state['state'] = "on"
		else:
			state['state'] = "off"
		self.server.send("gripper_state", state)

	def start_charging(self, param):
		self.charger.startCharging()

	def stop_charging(self, param):
		self.charger.stopCharging()
