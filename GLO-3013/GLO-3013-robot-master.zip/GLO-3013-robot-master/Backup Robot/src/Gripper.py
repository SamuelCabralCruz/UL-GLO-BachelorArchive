from Servo import Servo
from GPIO import GPIO
from LED import LED
from Serial import Serial
import threading
import time
import RPi.GPIO

class Gripper:
	def __init__(self, extendPin, retractPin, gripperPin, servoDevicePath="/dev/ttyACM0", servoBaudrate=9600, delay=0.1):
		super().__init__()
		self.servoDevice = Serial(servoDevicePath, servoBaudrate, delay)
		self.servo = Servo(0x0C, 0x02, 0x0510-25, self.servoDevice)
		self.extendPin = GPIO(extendPin, "IN", "DOWN")
		self.retractPin = GPIO(retractPin, "IN", "DOWN")
		self.gripperPin = LED(gripperPin)
		self.extendPin.enableInterupt("RISING")
		self.retractPin.enableInterupt("RISING")
		RPi.GPIO.add_event_detect(self.extendPin.pinID, self.extendPin.interuptEdge, self._extendedInterupt,bouncetime=100)
		RPi.GPIO.add_event_detect(self.retractPin.pinID, self.retractPin.interuptEdge, self._retractedInterupt, bouncetime=100)

		

	def start(self):
		self.servoDevice.open()
		self.servo.start()
		self.servo.setPosition(self.servo.neutralPosition+10)

	def _extendedInterupt(self, junkData):
		self.state = 'EXTENDED'
		self.servo.setPosition(self.servo.neutralPosition)

	def _retractedInterupt(self, junkData):
		self.state = 'RETRACTED'
		self.servo.setPosition(self.servo.neutralPosition)

	def extend(self):
		if(self.state != 'EXTENDED'):
			self.state = 'TRANSITING'
		self.servo.setPosition(self.servo.neutralPosition+10)
		print("extend not tested yet!!!")

	def retract(self):
		if(self.state != 'RETRACTED'):
			self.state = 'TRANSITING'
		self.servo.setPosition(self.neutralPosition-10)
		print("retract not tested yet!!!")

	def on(self):
		self.gripperPin.on()

	def off(self):
		self.gripperPin.off()
