import json
import socket
import sys
import logging
import random

from time import sleep
from threading import Thread

from socket_client import SocketClient


class Communication():

    def __init__(self, host="192.168.1.33", port=8888, connections=1):
        self.socket = socket.socket()
        self.socket.bind((host, port))
        self.socket.listen(connections)
        self.max_connections = connections
        self.connections = []

    def accept(self):
        connection, adress = self.socket.accept()
        client = SocketClient(connection=connection)
        self._new_connection(client)
        return client

    def close(self):
        for connection in self.connections:
            connection.close()

        self.socket.close()

    def send(self, event_name, data):
        if len(self.connections) == 0:
            return

        message = self.connections[0]._build_message(event_name, data)

        for connection in self.connections:
            connection.data_queue.append(message)

    def _new_connection(self, connection):
        connection.bind_to_close(lambda: self._clean_connection(connection))
        self.connections.append(connection)

    def _clean_connection(self, connection):
        self.connections.remove(connection)


