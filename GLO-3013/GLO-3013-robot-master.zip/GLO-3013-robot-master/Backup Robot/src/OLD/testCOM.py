from communication import Communication
import time

IP='192.168.1.33'
port=10112

com=Communication(IP,port)

while True:
    data = com.recv2()
    print('Data : ',data.decode())