#!/usr/bin/python
import socket
import numpy

class Communication:

    conn=0
    s=0
    TCP_IP=0
    TCP_PORT=0

    def recvall(s, count):
        buf = b''
        tmp=1
        while count>0:
            newbuf = s.recv(count)
            if not newbuf: return None
            buf += newbuf
            count -= len(newbuf)
        return buf

    def __init__(self, IP, Port,sock=None):
        
        self.TCP_IP = IP
        self.TCP_PORT=Port
        if sock is None:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.bind((self.TCP_IP, self.TCP_PORT))
        else:
            self.sock = sock
        
        
        #Communication.sock = socket.socket()
        #Communication.sock.connect((Communication.TCP_IP, Communication.TCP_PORT))

    def send(self, type, data):
        self.sock.send(type + '-' + data)

    def listen(self):
        self.sock.bind((self.TCP_IP, self.TCP_PORT))
        self.sock.listen(1)
        self.conn, addr = self.sock.accept()

    def recv2(self):
        self.sock.listen(1)
        conn2, addr = self.sock.accept()
        data=Communication.recv(conn2)
        #msg=b'1'
        #data = numpy.fromstring(Communication.recv(conn2),dtype='uint8')
        #self.sock.send(msg)
        conn2.close()
        return data
    
    def recv(conn3):
        length=Communication.recvall(conn3,2)
        stringData = Communication.recvall(conn3, int(length))
        return stringData

    def __del__(self):
        self.sock.close()
        #Communication.sock.close()
