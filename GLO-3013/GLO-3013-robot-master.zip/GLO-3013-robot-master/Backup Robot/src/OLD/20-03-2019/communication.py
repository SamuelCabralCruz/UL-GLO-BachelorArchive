import json
import socket

from time import sleep
from threading import Thread

from socket_communication import SocketClient, InvalidTransferData


class Communication():

    def __init__(self, host="192.168.1.33", port=8888, connections=1):
        self.testing = 0;
        self.buf = []
        self.socket = socket.socket()
        self.socket.bind((host, port))
        self.socket.listen(connections)
        self.connections = []
        self.accept()
        self.conn.connect(self._load)
        while (self.testing !=1):
            self.testing = self.test(host,port,connections)
            

    def accept(self):
        connection, adress = self.socket.accept()
        client = SocketClient(connection=connection)
        self.connections.append(client)
        self.conn = client

    def send(self,data):
        self.conn.send(data)
        
    def recv(self):
        if (len(self.buf)!=0):
            return self.buf.pop(0)

    def _load(self,event):
        self.buf.append(event)
        
    def test(self, host="192.168.1.33", port=8888, connections=1):
        try:
            self.send({"event":"test"})
        except:
            print("error")
            self.buf = []
            self.socket = socket.socket()
            self.socket.bind((host, port))
            self.socket.listen(connections)
            self.connections = []
            self.accept()
            self.conn.connect(self._load)
            return 0
        return 1


#server = Communication()
#try:
#    server.send({"event":"is_ready"})
#except:
#    print("error")

#while True:
 #   data = server.recv()
  #  if (data != None):
   #     if (data["event"] == "connected"):
    #        server.send({"event" : "answer", "result" : "Connected"})
     #       print("Client Connected")
      #  elif (data["event"] == "move"):
       #     server.send({"event" : "answer", "result" : "move ok"})
        #    print("event = ",data["event"])
        #else:
         #   print("event = ",data["event"])
  #  sleep(1)
