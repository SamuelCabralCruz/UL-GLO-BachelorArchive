from communication import Communication
#from Camera import Camera
#from MotorPlatform import MotorPlatform
from LED import LED
import time

class CommandProcessor:

	def __init__(self):
		#self.motorPlatform = MotorPlatform()
		#self.camera = Camera()
		self.readyLED = LED(23)

		#TODO enlever après présentation
		self.readyLED.off()
		for i in range(4):
			time.sleep(0.1)
			self.readyLED.toggle()
		self.readyLED.off()

		self.server = Communication("192.168.1.33",8888) #192.168.1.33
		self.processor = {
			'move' : self.move,
			'rotate' : self.rotate,
			'get_camera_capture' : self.capture_camera,
			'is_ready' : self.ready,
                        'test' : self.test
		}
		self.main()

	def main(self):
		while 1:
			command = self.server.recv()
			if(command != None):
				self.processor[command['event']](command)

	def move(self, param):
		self.motorPlatform.move(param["direction"], param['distance'], param['speed'])

	def rotate(self, param):
		self.motorPlatform.rotate(param['direction'], param['angle'], param['speed'])

	def capture_camera(self, param):
		self.server.send({
			"event" : "camera_capture",
			"camera_capture" : self.camera.getImage()
		})

	def ready(self, param):
		self.server.send({
			"event" : "ready"
		})
		self.readyLED.toggle() #TODO changer .toggle() par .on() après la présentation remise 2
	
	def test(self, param):
            self.server.send({
			"event" : "test"
	    })
            print("test : ok")

