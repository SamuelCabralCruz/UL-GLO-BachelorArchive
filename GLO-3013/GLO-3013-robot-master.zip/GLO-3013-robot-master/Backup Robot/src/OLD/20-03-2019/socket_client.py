import json
import socket

from concurrent.futures import ThreadPoolExecutor
from time import sleep
from threading import Thread


class InvalidTransferData(Exception):
    def __init__(self):
        Exception.__init__(self, "Data objects have to be dicts with a 'event' key")


class SocketClient():

    def __init__(self, host="0.0.0.0", port=8081, connection=None, frequency=60, max_threads=2):
        self.length_info_size = 4
        self.data_queue = []
        self.event_callbacks = {}
        self.sleep_time = 1 / frequency

        if connection is None:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
        else:
            self.socket = connection

        self.receive_thread = Thread(target=self._loop)
        self.receive_thread.daemon = True
        self.receive_thread.start()
        self.event_executor = ThreadPoolExecutor(max_workers=max_threads)

    def send(self, data):
        self._validate_data(data)
        self.data_queue.append(data)

    def connect(self, event_name, callback):
        if self.event_callbacks.get(event_name) is None:
            self.event_callbacks[event_name] = [callback]
        else:
            self.event_callbacks[event_name].append(callback)

    def _validate_data(self, data):
        if not (isinstance(data, dict) and isinstance(data.get("event"), str)):
            raise InvalidTransferData()

    def _loop(self):
        while True:
            sleep(self.sleep_time)

            if len(self.data_queue) > 0:
                data = self.data_queue
                self.data_queue = []
                self._send(data)
            else:
                self._send(None)

            data_received = self._receive()

            if data_received is not None:
                self._process_received_data(data_received)

    def _process_received_data(self, data):
        for event in data:
            for callback in self.event_callbacks.get(event["event"], []):
                self.event_executor.submit(callback, event)

    def _send(self, data):
        bytes_data = json.dumps(data).encode()
        length = len(bytes_data)

        self.socket.sendall(self._get_size_info(length) + bytes_data)

    def _receive(self):
        bytes_length = self._receive_all(self.length_info_size)
        length = self._get_length(bytes_length)

        bytes_data = self._receive_all(length)

        return json.loads(bytes_data.decode())

    def _receive_all(self, length):
        buffer = b""

        while length > 0:
            bytes_read = self.socket.recv(length)
            buffer += bytes_read
            length -= len(bytes_read)

        return buffer

    def _get_size_info(self, length):
        byte_values = [int(length / (255**x)) % 255 for x in range(0, self.length_info_size)]
        return bytes(byte_values)

    def _get_length(self, size_bytes):
        length = 0
        power = 1
        for value in size_bytes:
            length += value * power
            power *= 255
        return length
