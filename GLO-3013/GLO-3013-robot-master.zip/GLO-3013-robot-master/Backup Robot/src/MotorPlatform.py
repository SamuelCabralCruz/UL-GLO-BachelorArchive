from multiprocessing import Process
from PWM import PWM
import time

class MotorPlatform:

	# stm32 given to have port configuration in commandProcessor
	def __init__(self, stm32):
		self.active = True
		self.stm32 = stm32


	def move(self, speed):
		self.stm32.move(speed, [0, 0])

	def rotate(self, direction, cap, speed):
		if direction == 'clockwise':
			self.stm32.rotate(speed, cap)
		elif direction == 'counter_clockwise':
			self.stm32.rotate(-speed, cap)

	def stop(self):
		self.stm32.stop()
