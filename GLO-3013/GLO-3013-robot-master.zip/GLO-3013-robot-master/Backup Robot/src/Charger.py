from ADC import ADC
from LED import LED

class Charger:
	def __init__(self, stm, maxVoltage, samplingFrequency=20):
		self.adc = ADC(stm, samplingFrequency)
		self.adc.start()
		self.maxVoltage = maxVoltage
		self.chargePin = LED(16)

	def startCharging(self):
		self.chargePin.on()

	def stopCharging(self):
		self.chargePin.off()

	def getVoltage(self):
		return self.adc.read()*self.maxVoltage

	def getChargeLevel(self):
		return self.adc.read()
