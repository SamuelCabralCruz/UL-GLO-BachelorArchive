from time import sleep
from communication import Communication

def move(data):
    server.send({"event" : "answer", "result" : "move ok"})
    print("event = ",data["event"],"               ", "move :",data["data"])
    
def turn(data):
    server.send({"event" : "answer", "result" : "turn ok"})
    print("event = ",data["event"], "      ", "turn :",data["data"])



server = Communication("192.168.1.33",8888)

while True:
    data = server.recv()
    if (data != None):
        if (data["event"] == "connected"):
            server.send({"event" : "answer", "result" : "Connected"})
            print("Client Connected")
        elif (data["event"] == "move"):
            move(data)
        elif (data["event"] == "turn"):
            turn(data)
        else:
            print("event = ",data["event"])
    sleep(1)