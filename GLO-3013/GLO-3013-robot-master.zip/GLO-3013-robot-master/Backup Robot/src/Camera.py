
from Serial import Serial
from Servo import Servo
from View import View
import math

class Camera:

	def __init__(self, servoDevicePath='/dev/ttyACM0', servoBaudrate=9600, delay=0.1, servoDevice=None):
		self.cam = View()
		if(servoDevice == None):
			self.servoDevice = Serial(servoDevicePath, servoBaudrate, delay)
			self.servoDevice.open()
		else:
			self.servoDevice = servoDevice

		servo0 = Servo(0x0C, 0x00, 0x0510+31, self.servoDevice)
		servo1 = Servo(0x0C, 0x01, 0x1058, self.servoDevice)#0x0510+40
		servo0.resolution = 62
		servo1.resolution = 28
		self.servos = [servo0, servo1]
		self.servoBase = [0x0510+31, 0x0510+40]
		self.servo0step = 1.72
		self.servo1stepbas = 1.60
		self.servo1stephaut = 1.44
		self.precision = 5
	def start(self):
		self.servos[0].start()
		self.servos[1].start()

	def rotate(self, axis, angle):
		assert axis == 'YAW' or axis == 'PITCH'
		if axis == 'YAW':
			angle2 =math.floor( (angle/self.precision)*self.servo0step)
			#print(angle2)
			self.servos[0].setPosition(self.servoBase[0]+angle2)
			#print(self.servoBase[0])
			#print(self.servoBase[0]+angle2)
		else:
			if(angle >0):
				angle2=math.floor((angle/self.precision)*self.servo1stephaut)
			else:
				angle2=math.floor((angle/self.precision)*self.servo1stepbas)
			self.servos[1].setPosition(self.servoBase[1]+angle2)


	def getImage(self):
		return self.cam.getImage()
	
