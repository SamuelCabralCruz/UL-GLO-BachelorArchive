#!/usr/bin/python3

from Serial import Serial
from LED import LED
import struct
import time
import json
from threading import Thread, Lock
import os

print("=========starting aquisition=========")

s = Serial("/dev/ttyUSB0", 57600)
s.open()
s.read()
def extract(data):
	return struct.unpack('=cffffiiiiif', b''.join(data))


def acquisition():
    reset = struct.pack('=ciiiii', b'\x00', 0, 0, 0, 0, 0)
    probe = struct.pack('=ciiiii', b'\x14', 0, 0, 0, 0, 0)
    s.write(reset)
    s.write(probe)
    time.sleep(0.1)
    data = []
    while data == []:
        data = s.read()
    print(data)
    return extract(data)


def move(speedx, speedy):
    reset = struct.pack('=ciiiii', b'\x00', 0, 0, 0, 0, 0)
    move = struct.pack('=ciffff', b'\x14', 1, 0, 0, speedx, speedy)
    s.write(reset)
    s.write(move)

def rotate(speed):
    reset = struct.pack('=ciiiii', b'\x00', 0, 0, 0, 0, 0)
    rotate = struct.pack('=ciffff', b'\x14', 2, speed, 0, 0, 0)
    s.write(reset)
    s.write(rotate)




mapping = ['positionX','positionY','vitesseX','vitesseY','adc','Moteur0','Moteur1','Moteur2','Moteur3','temps']

class A:
    def __init__(self):
        self.data = []
        self.lock = Lock()
        self.reading = True

    def stop(self):
        self.reading = False

    def move_robot(self):
        var = 2
        print("forward", time.time())
        with self.lock:
            move(1.0, 0.0)
        time.sleep(var)
        print("backward", time.time())
        with self.lock:
            move(-1.0, 0.0)
        time.sleep(var)
        print("right", time.time())
        with self.lock:
            move(0.0, 1.0)
        time.sleep(var)
        print("left", time.time())
        with self.lock:
            move(0.0, -1.0)
        time.sleep(var)

        time.sleep(var)
        print("rleft", time.time())
        with self.lock:
            rotate(1.0)
        time.sleep(var)
        print("rright", time.time())
        with self.lock:
            rotate(-1.0)

        print("stop", time.time())
        with self.lock:
            move(0.0, 0.0)


    def read_data(self):
        while self.reading:
            time.sleep(0.05)
            with self.lock:
                self.data += [acquisition()[1:]]


a = A()
read_thread = Thread(target=a.read_data, name="read")
read_thread.daemon = False
read_thread.start()

for i in range(1):
	a.move_robot()

a.stop()
data = []

print("========================")
for i in a.data:
	print(i)
	data += [{key:i[j] for j, key in enumerate(mapping)}]

with open('test.json', 'a') as outfile:
    outfile.write("=====================\n")
    json.dump(data, outfile)

for i in data:
	os.system('echo "'+str(i['temps'])+','+str(i['Moteur0'])+','+str(i['Moteur1'])+','+str(i['Moteur2'])+','+str(i['Moteur3'])+'" >> testAqu.log')

s.close()
