import serial
import time

class Serial:


	def __init__(self, devicePath, baudrate, delay=0):
		self.serialInterface = serial.Serial()
		self.serialInterface.port = devicePath
		self.serialInterface.baudrate = baudrate
		self.serialInterface.parity = 'E'
		self.serialInterface.byteSize = 8
		self.delay = delay

	def open(self):
		self.serialInterface.open()

	def close(self):
		self.serialInterface.close()

	#data format: any, but must use struct
	def write(self, dataBuffer):
		self.serialInterface.write(dataBuffer)
		if self.delay != 0:
			time.sleep(self.delay)

	def read(self):
		dataBuffer = []
		while self.serialInterface.in_waiting > 0:
			data = self.serialInterface.read()
			if( data != [] ):
				dataBuffer.append(data)
		return dataBuffer
