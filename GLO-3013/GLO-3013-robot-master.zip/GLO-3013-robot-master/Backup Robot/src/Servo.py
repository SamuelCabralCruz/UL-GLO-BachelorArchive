import struct
from Serial import Serial

class Servo:
	baseOffset = 0x0510
	resolution = 10
	neutralPosition = 0x0510
	servoID = 0x0D
	servoPort = 0x00
	currentPosition = 0x0510

	def __init__(self, servoID, servoPort, neutralPosition, serialDevice):
		self.servoID = servoID
		self.servoPort = servoPort
		self.neutralPosition = neutralPosition
		self.device = serialDevice

	def start(self):
		self.setPosition(self.neutralPosition)

	def setPosition(self, position):
		bytePort = struct.pack("B", self.servoPort)
		byteID = struct.pack("B" ,self.servoID)

		dataFrame = struct.pack('>cccch',
					b'\xAA',
					byteID,
					b'\x04',
					bytePort,
					position)
		print(dataFrame)
		self.device.write(dataFrame)

	def getPosition(self):
		return currentPosition
