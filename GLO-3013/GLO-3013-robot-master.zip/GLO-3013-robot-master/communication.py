#!/usr/bin/python
import socket

class Communication:

    conn=0
    s=0
    sock=0
    TCP_IP=0
    TCP_PORT=0

    def recvall(sock, count):
        buf = b''
        while count:
            newbuf = sock.recv(count)
            if not newbuf: return None
            buf += newbuf
            count -= len(newbuf)
        return buf

    def __init__(self, IP, Port):
        Communication.TCP_IP = IP
        Communication.TCP_PORT=Port
        Communication.sock = socket.socket()
        Communication.sock.connect((Communication.TCP_IP, Communication.TCP_PORT))

    def send(self, type, data):
        Communication.sock.send(type + '-' + data)

    def listen(self):
        Communication.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        Communication.s.bind((Communication.TCP_IP, Communication.TCP_PORT))
        Communication.s.listen(True)
        Communication.conn, addr = Communication.s.accept()

    def recv(self):
        length = Communication.recvall(Communication.conn, 16)
        stringData = Communication.recvall(Communication.conn, int(length))
        return stringData

    def __delete__(self, instance):
        Communication.s.close()
        Communication.sock.close()