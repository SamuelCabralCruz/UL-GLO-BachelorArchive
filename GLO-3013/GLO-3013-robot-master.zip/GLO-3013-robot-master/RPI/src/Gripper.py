from Servo import Servo
from GPIO import GPIO
from LED import LED
from Serial import Serial
import threading
import time
import RPi.GPIO

class Gripper:
	def __init__(self, extendPin, retractPin, platformPin, gripperPin, servoDevicePath="/dev/ttyACM0", servoBaudrate=9600, delay=0.1):
		super().__init__()
		self.state = 'UNKNOWN'

		self.checkPlatform = False

		self.servoDevice = Serial(servoDevicePath, servoBaudrate, delay)
		self.servo = [None, None]
		self.servo[0] = Servo(0x0C, 0x02, 0x0510+40, self.servoDevice) #+36
		self.servo[1] = Servo(0x0C, 0x03, 0x0510+41+3, self.servoDevice) #41

		self.speed = 30

		self.extendPin = GPIO(extendPin, "IN", "DOWN")
		self.retractPin = GPIO(retractPin, "IN", "DOWN")
		self.platformPin = GPIO(platformPin, "IN", "DOWN")

		self.gripperPin = LED(gripperPin)

		self.extendPin.enableInterupt("RISING")
		self.retractPin.enableInterupt("RISING")
		self.platformPin.enableInterupt("RISING")

		RPi.GPIO.add_event_detect(self.extendPin.pinID, self.extendPin.interuptEdge, self._extendedInterupt,bouncetime=100)
		RPi.GPIO.add_event_detect(self.retractPin.pinID, self.retractPin.interuptEdge, self._retractedInterupt, bouncetime=100)
		RPi.GPIO.add_event_detect(self.platformPin.pinID, self.platformPin.interuptEdge, self._platformInterupt, bouncetime=100)
		

	def start(self):
		self.servoDevice.open()
		for s in self.servo:
			s.start()
			s.setPosition(s.neutralPosition)
		self.servo[1].setPosition(0)
		self.servo[0].setPosition(self.servo[0].neutralPosition-52)

		self.state = "UNKNOWN"
		self.reset()

	def reset(self):
		self.rotate(1)
		self.rotate(1)
		time.sleep(2)
		self.extend()
		time.sleep(0.1)
		self.extend()
		time.sleep(0.1)
		self.extend()
		time.sleep(1)
		while self.state != 'RETRACTED':
			time.sleep(0.05)
			self.retract()
		self.rotate(0)


	def _extendedInterupt(self, junkData):
		self.state = 'EXTENDED'
		self.servo[1].setPosition(self.servo[1].neutralPosition*0)
		print(time.time(), "EXTENDED EVENT")
		#self.servo[1].setPosition(0)
		#time.sleep(2)
		#self.servo[1].setPosition(self.servo[1].neutralPosition)

	def _retractedInterupt(self, junkData):
		self.state = 'RETRACTED'
		self.servo[1].setPosition(self.servo[1].neutralPosition*0)
		print(time.time(), "RETRACTED EVENT")

	def _platformInterupt(self, junkData):
		if self.checkPlatform:
			self.state = 'PLATFORM'
			self.servo[1].setPosition(self.servo[1].neutralPosition*0)

	def rotate(self, angle):
		if angle == 0 and self.state == 'RETRACTED':
			self.servo[0].setPosition(self.servo[0].neutralPosition)
		elif angle != 0 and self.state == 'RETRACTED':
			self.servo[0].setPosition(self.servo[0].neutralPosition-52)

	def extend(self):
		print("extend command")
		if(self.state != 'EXTENDED' and self.state != 'PLATFORM'):
			self.state = 'TRANSITING'
			self.servo[1].setPosition(self.servo[1].neutralPosition+self.speed)#60
			#time.sleep(0.05)
			#self.servo[1].setPosition(self.servo[1].neutralPosition-self.speed)#60
			#time.sleep(0.05)
			#self.servo[1].setPosition(self.servo[1].neutralPosition-self.speed)#60

	def retract(self):
		print("retract command")
		if(self.state != 'RETRACTED'):
			self.state = 'TRANSITING'
			self.servo[1].setPosition(self.servo[1].neutralPosition-self.speed)
			#time.sleep(0.05)
			#self.servo[1].setPosition(self.servo[1].neutralPosition+self.speed)
			#time.sleep(0.05)
			#self.servo[1].setPosition(self.servo[1].neutralPosition+self.speed)

	def stop(self):
		self.servo[1].setPosition(0)

	def on(self):
		self.gripperPin.on()

	def off(self):
		self.gripperPin.off()
