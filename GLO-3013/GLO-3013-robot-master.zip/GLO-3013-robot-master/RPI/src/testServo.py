#!/usr/bin/python3

import serial
import time

usb = serial.Serial()
usb.port = "/dev/ttyACM0"
usb.baudrate = 9600
usb.parity = 'E'
usb.stopbits = serial.STOPBITS_ONE
usb.open()

#time.sleep(3)

#yaw 0x0510 - 0x054E (62 itérations)
#pitch 0x0510 -0x052C (28 itérations)
#42.5 cm
#x 1.85 cm (résolution de 2.49 degrée)
#y 2.1 cm (résolution de 2.83 degrée)

#d = bytes([0xAA, 0x0C, 0x04, 0x01, 0x05, 0xD8]);
#usb.write(d)
#time.sleep(1)

while 1:
	d = bytes([0xAA, 0x0C, 0x04, 0x01, 0x05, 0x10+20]);
	usb.write(d)
	time.sleep(1)
	d = bytes([0xAA, 0x0C, 0x04, 0x01, 0x05, 0x10+40]);
	#usb.write(d)
	#time.sleep(1)
	time.sleep(2)

usb.close()
