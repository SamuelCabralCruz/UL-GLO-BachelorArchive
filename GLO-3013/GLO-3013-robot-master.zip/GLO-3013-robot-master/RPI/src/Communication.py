
import socket
import json

class Communication:

	def __init__(self, host='192.168.1.33', port=8888):
		self.socket = socket.socket()
		self.socket.bind((host, port))
		self.socket.listen(1)
		self.connection, self.clientAddress = self.socket.accept()
		self.recvString = ''

	def send(self, data):
		pass

	def recv(self):
		self.recvString.join((b''.join(self.connection.recv(1024)).encode('ascii')))
		return self.recvString
