newman run doc/tests/postman/tests_postman -e doc/tests/postman/environment_postman > postman.log
sed -n '/┌─────────────────────────┬──────────┬──────────┐/,/└───────────────────────────────────────────────┘/p' postman.log
rm postman.log
