package ca.ulaval.glo4002.trading.rest.account;


public final class CreditRequestObjectMother {

    public static final float VALID_AMOUNT = 10f;
    public static final String DEFAULT_CURRENCY_VALUE = "USD";
    public static final float NEGATIVE_AMOUNT = -5f;

    public static CreditRequest createValidCreditRequest() {
        return createBaseCreditRequest();
    }

    public static CreditRequest createInvalidCreditRequest() {
        CreditRequest creditRequest = createBaseCreditRequest();
        creditRequest.amount = NEGATIVE_AMOUNT;
        return creditRequest;
    }

    private static CreditRequest createBaseCreditRequest() {
        CreditRequest creditRequest = new CreditRequest();
        creditRequest.amount = VALID_AMOUNT;
        creditRequest.currency = DEFAULT_CURRENCY_VALUE;
        return creditRequest;
    }

    public static class CreditRequest {
        public String currency;
        public float amount;
    }
}