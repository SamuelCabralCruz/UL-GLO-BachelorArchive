package ca.ulaval.glo4002.trading.suites;

import ca.ulaval.glo4002.trading.TradingServer;
import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.contexts.DevContext;
import ca.ulaval.glo4002.trading.rest.account.AccountControllerRestTest;
import ca.ulaval.glo4002.trading.rest.report.ReportControllerRestTest;
import ca.ulaval.glo4002.trading.rest.transaction.TransactionControllerRestTest;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
        AccountControllerRestTest.class,
        TransactionControllerRestTest.class,
        ReportControllerRestTest.class})
public class ApiTestSuite extends BaseTestSuite {

    public static final int TEST_SERVER_PORT = 9292;

    private static TradingServer tradingServer;

    @BeforeClass
    public static void setUpClass() {
        tradingServer = new TradingServer();
        tradingServer.start(TEST_SERVER_PORT, new DevContext(), false);
    }

}