package ca.ulaval.glo4002.trading.rest.transaction;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.rest.transaction.StockRequestObjectMother.StockRequest;

import java.time.LocalDateTime;

public class TransactionRequestObjectMother {

    public static final TransactionNumber TRANSACTION_NUMBER = new TransactionNumber();
    public static final String TRANSACTION_NUMBER_VALUE = TRANSACTION_NUMBER.getValue().toString();
    public static final String TRANSACTION_TYPE_BUY = "BUY";
    public static final String TRANSACTION_TYPE_SELL = "SELL";
    public static final String TRANSACTION_DATE_VALUE = "2018-08-21T15:23:20.142Z";
    public static final LocalDateTime TRANSACTION_DATE = LocalDateTime.of(2018, 8, 21, 15, 23, 20, 000000142);
    public static final long TRANSACTION_QUANTITY = 10L;
    public static final String UNSUPPORTED_TRANSACTION_TYPE = "UNSUPPORTED";
    public static final String INVALID_DATE = "INVALID";
    public static final long NEGATIVE_QUANTITY = -10L;
    public static final long ZERO_QUANTITY = 0L;
    public static final float PRICE_AMOUNT = 45.45f;
    public static final Money PRICE = new Money(PRICE_AMOUNT);
    public static final float FEES_AMOUNT = 3.12f;
    public static final Money FEES = new Money(FEES_AMOUNT);


    public static TransactionRequest createValidBuyTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.type = TRANSACTION_TYPE_BUY;
        return request;
    }

    public static TransactionRequest createValidSellTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.type = TRANSACTION_TYPE_SELL;
        request.transactionNumber = TRANSACTION_NUMBER_VALUE;
        return request;
    }

    public static TransactionRequest createInvalidTypeTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.type = UNSUPPORTED_TRANSACTION_TYPE;
        return request;
    }

    public static TransactionRequest createZeroQuantityTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.quantity = ZERO_QUANTITY;
        return request;
    }

    public static TransactionRequest createNegativeQuantityTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.quantity = NEGATIVE_QUANTITY;
        return request;
    }

    public static TransactionRequest createInvalidDateTransactionRequest() {
        TransactionRequest request = createBaseTransactionRequest();
        request.date = INVALID_DATE;
        return request;
    }

    private static TransactionRequest createBaseTransactionRequest() {
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.date = TRANSACTION_DATE_VALUE;
        transactionRequest.quantity = TRANSACTION_QUANTITY;
        transactionRequest.stock = StockRequestObjectMother.createValidStockRequest();
        return transactionRequest;
    }

    public static class TransactionRequest {
        public String type;
        public String date;
        public StockRequest stock;
        public String transactionNumber;
        public long quantity;
    }

}
