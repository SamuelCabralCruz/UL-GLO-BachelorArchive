package ca.ulaval.glo4002.trading.rest.account;

import ca.ulaval.glo4002.trading.BaseITest;
import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.account.AccountApplicationService;
import ca.ulaval.glo4002.trading.application.account.AccountDTO;
import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountAlreadyOpenException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.EmptyCreditsException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidAmountException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import io.restassured.http.ContentType;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static ca.ulaval.glo4002.trading.rest.account.AccountRequestObjectMother.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;

public class AccountControllerRestTest extends BaseITest {

    public static final String ACCOUNTS_PATH = "/accounts";

    private AccountApplicationService accountApplicationService;

    @Before
    public void setUp() {
        accountApplicationService = ServiceLocator.resolve(AccountApplicationService.class);
    }

    @Test
    public void givenValidAccountRequest_whenPost_thenCreated() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        willReturn(ACCOUNT_NUMBER).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        scenario.then()
                .statusCode(Response.Status.CREATED.getStatusCode());
    }

    @Test
    public void givenValidAccountRequest_whenPost_thenLocationContainsAccountNumber() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        willReturn(ACCOUNT_NUMBER).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        String expectedLocation = joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE);
        scenario.then()
                .header("location", endsWith(expectedLocation));
    }

    @Test
    public void givenAlreadyOpenAccountRequest_whenPost_thenBadRequest() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        AccountAlreadyOpenException exception = new AccountAlreadyOpenException(INVESTOR_ID);
        willThrow(exception).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenAlreadyOpenAccountRequest_whenPost_thenErrorMessage() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        AccountAlreadyOpenException exception = new AccountAlreadyOpenException(INVESTOR_ID);
        willThrow(exception).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        String expectedError = "ACCOUNT_ALREADY_OPEN";
        String expectedDescription = String.format("account already open for investor %d", INVESTOR_ID_VALUE);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenEmptyCreditsAccountRequest_whenPost_thenBadRequest() {
        AccountRequest request = AccountRequestObjectMother.createEmptyCreditsAccountRequest();
        willThrow(EmptyCreditsException.class).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenEmptyCreditsAccountRequest_whenPost_thenErrorMessage() {
        AccountRequest request = AccountRequestObjectMother.createEmptyCreditsAccountRequest();
        willThrow(EmptyCreditsException.class).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        String expectedError = "EMPTY_CREDITS";
        String expectedDescription = "an account cannot be opened without credits";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenInvalidAmountAccountRequest_whenPost_thenBadRequest() {
        AccountRequest request = AccountRequestObjectMother.createInvalidAmountAccountRequest();
        willThrow(InvalidAmountException.class).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenInvalidAmountAccountRequest_whenPost_thenErrorMessage() {
        AccountRequest request = AccountRequestObjectMother.createInvalidAmountAccountRequest();
        willThrow(InvalidAmountException.class).given(accountApplicationService).createAccount(any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(ACCOUNTS_PATH);

        String expectedError = "INVALID_AMOUNT";
        String expectedDescription = "credit amount cannot be lower than or equal to zero";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenValidAccountNumber_whenGet_thenOk() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        AccountDTO accountDTO = getValidAccountDTO(request);
        willReturn(accountDTO).given(accountApplicationService).getByAccountNumber(ACCOUNT_NUMBER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    public void givenValidAccountNumber_whenGet_thenAccountMessage() {
        AccountRequest request = AccountRequestObjectMother.createValidAccountRequest();
        AccountDTO accountDTO = getValidAccountDTO(request);
        willReturn(accountDTO).given(accountApplicationService).getByAccountNumber(ACCOUNT_NUMBER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE));

        scenario.then()
                .body("accountNumber", equalTo(ACCOUNT_NUMBER_VALUE))
                .body("investorId", equalTo(INVESTOR_ID_VALUE))
                .body("investorProfile.type", equalTo(INVESTOR_TYPE.toString()))
                .body("investorProfile.focusAreas", empty())
                .body("credits.size()", is(request.credits.size()))
                .body("total", isA(Float.class));
    }

    @Test
    public void givenInvalidAccountNumber_whenGet_thenNotFound() {
        AccountNotFoundException exception = new AccountNotFoundException(ACCOUNT_NUMBER);
        willThrow(exception).given(accountApplicationService).getByAccountNumber(ACCOUNT_NUMBER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    @Test
    public void givenInvalidAccountNumber_whenGet_thenErrorMessage() {
        AccountNotFoundException exception = new AccountNotFoundException(ACCOUNT_NUMBER);
        willThrow(exception).given(accountApplicationService).getByAccountNumber(ACCOUNT_NUMBER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE));

        String expectedError = "ACCOUNT_NOT_FOUND";
        String expectedDescription = String.format("account with number %s not found", ACCOUNT_NUMBER_VALUE);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    private AccountDTO getValidAccountDTO(AccountRequest accountRequest) {
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setAccountNumber(ACCOUNT_NUMBER);
        accountDTO.setInvestorId(new InvestorId(accountRequest.investorId));
        accountDTO.setInvestorType(INVESTOR_TYPE);
        accountDTO.setFocusAreas(FOCUS_AREAS);
        List<Money> credits = accountRequest.credits.stream().map(
                credit -> new Money(credit.amount, new Currency(credit.currency))
        ).collect(Collectors.toList());
        accountDTO.setBalance(new Balance(credits));
        return accountDTO;
    }
}