package ca.ulaval.glo4002.trading.rest.account;


import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static ca.ulaval.glo4002.trading.rest.account.CreditRequestObjectMother.CreditRequest;
import static ca.ulaval.glo4002.trading.rest.account.CreditRequestObjectMother.createValidCreditRequest;

public final class AccountRequestObjectMother {

    public static final String ACCOUNT_NUMBER_VALUE = "UB-0";
    public static final AccountNumber ACCOUNT_NUMBER = new AccountNumber(ACCOUNT_NUMBER_VALUE);
    public static final String INVALID_ACCOUNT_NUMBER = "INVALID";
    public static final String INVESTOR_NAME = "Uncle Bob";
    public static final String INVESTOR_EMAIL = "bob@example.com";
    public static final long INVESTOR_ID_VALUE = 1212L;
    public static final InvestorId INVESTOR_ID = new InvestorId(INVESTOR_ID_VALUE);
    public static final InvestorType INVESTOR_TYPE = InvestorType.CONSERVATIVE;
    public static final List<String> FOCUS_AREAS = new ArrayList<>();

    public static AccountRequest createValidAccountRequest() {
        return createBaseAccountRequest();
    }

    public static AccountRequest createInvalidAmountAccountRequest() {
        AccountRequest accountRequest = createBaseAccountRequest();
        CreditRequest negativeCreditRequest = CreditRequestObjectMother.createInvalidCreditRequest();
        accountRequest.credits = Arrays.asList(negativeCreditRequest);
        return accountRequest;
    }

    public static AccountRequest createEmptyCreditsAccountRequest() {
        AccountRequest accountRequest = createBaseAccountRequest();
        accountRequest.credits = new ArrayList<>();
        return accountRequest;
    }

    private static AccountRequest createBaseAccountRequest() {
        AccountRequest accountRequest = new AccountRequest();
        accountRequest.investorId = INVESTOR_ID_VALUE;
        accountRequest.investorName = INVESTOR_NAME;
        accountRequest.email = INVESTOR_EMAIL;
        CreditRequest validCreditRequestRequest = createValidCreditRequest();
        accountRequest.credits = Arrays.asList(validCreditRequestRequest);
        return accountRequest;
    }

    public static class AccountRequest {
        public long investorId;
        public String investorName;
        public String email;
        public List<CreditRequest> credits;
    }
}