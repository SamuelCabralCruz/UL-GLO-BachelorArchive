package ca.ulaval.glo4002.trading.rest.transaction;

public class StockRequestObjectMother {

    public static final String VALID_SYMBOL = "MSFT";
    public static final String VALID_MARKET = "NASDAQ";
    public static final String INVALID_SYMBOL = "INVALID";
    public static final String INVALID_MARKET = "INVALID";

    public static StockRequest createValidStockRequest() {
        return createBaseStockRequest();
    }

    private static StockRequest createBaseStockRequest() {
        StockRequestObjectMother.StockRequest stockRequest = new StockRequest();
        stockRequest.market = VALID_MARKET;
        stockRequest.symbol = VALID_SYMBOL;
        return stockRequest;
    }

    public static class StockRequest {
        public String market;
        public String symbol;
    }
}
