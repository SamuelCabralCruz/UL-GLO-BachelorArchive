package ca.ulaval.glo4002.trading.contexts;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.account.AccountApplicationService;
import ca.ulaval.glo4002.trading.application.dividend.DividendApplicationService;
import ca.ulaval.glo4002.trading.application.report.ReportApplicationService;
import ca.ulaval.glo4002.trading.application.transaction.TransactionApplicationService;
import ca.ulaval.glo4002.trading.domain.report.Reporter;

import static org.mockito.Mockito.mock;

public class DevContext implements ApplicationContext {

    @Override
    public void execute() {
        registerAllClasses();
    }

    private void registerAllClasses() {
        registerServices();
    }

    private void registerServices() {
        ServiceLocator.register(Reporter.class, mock(Reporter.class));
        ServiceLocator.register(AccountApplicationService.class, mock(AccountApplicationService.class));
        ServiceLocator.register(TransactionApplicationService.class, mock(TransactionApplicationService.class));
        ServiceLocator.register(DividendApplicationService.class, mock(DividendApplicationService.class));
        ServiceLocator.register(ReportApplicationService.class, mock(ReportApplicationService.class));
    }

}
