package ca.ulaval.glo4002.trading.rest.transaction;

import ca.ulaval.glo4002.trading.BaseITest;
import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.transaction.TransactionApplicationService;
import ca.ulaval.glo4002.trading.application.transaction.TransactionDTO;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionType;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.StockNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.pending.MarketClosedException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.*;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.rest.transaction.TransactionRequestObjectMother.*;
import io.restassured.http.ContentType;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.core.Response;

import static ca.ulaval.glo4002.trading.rest.account.AccountControllerRestTest.ACCOUNTS_PATH;
import static ca.ulaval.glo4002.trading.rest.account.AccountRequestObjectMother.ACCOUNT_NUMBER_VALUE;
import static ca.ulaval.glo4002.trading.rest.account.AccountRequestObjectMother.INVALID_ACCOUNT_NUMBER;
import static ca.ulaval.glo4002.trading.rest.transaction.StockRequestObjectMother.*;
import static ca.ulaval.glo4002.trading.rest.transaction.TransactionRequestObjectMother.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;

public class TransactionControllerRestTest extends BaseITest {

    public static final String TRANSACTIONS_PATH = "/transactions";

    private TransactionApplicationService transactionApplicationService;

    @Before
    public void setUp() {
        transactionApplicationService = ServiceLocator.resolve(TransactionApplicationService.class);
    }

    @Test
    public void givenValidBuyTransactionRequest_whenPost_thenCreated() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        willReturn(TRANSACTION_NUMBER).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH));

        scenario.then()
                .statusCode(Response.Status.CREATED.getStatusCode());
    }

    @Test
    public void givenValidBuyTransactionRequest_whenPost_thenLocationContainsTransactionNumber() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        willReturn(TRANSACTION_NUMBER).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH));

        String expectedLocation = joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE);
        scenario.then()
                .header("location", endsWith(expectedLocation));
    }

    @Test
    public void givenValidSellTransactionRequest_whenPost_thenCreated() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willReturn(TRANSACTION_NUMBER).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH));

        scenario.then()
                .statusCode(Response.Status.CREATED.getStatusCode());
    }

    @Test
    public void givenValidSellTransactionRequest_whenPost_thenLocationContainsTransactionNumber() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willReturn(TRANSACTION_NUMBER).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH));

        String expectedLocation = joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE);
        scenario.then()
                .header("location", endsWith(expectedLocation));
    }

    @Test
    public void givenAccountNotFound_whenPost_thenNotFound() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, INVALID_ACCOUNT_NUMBER, TRANSACTIONS_PATH));

        scenario.then()
                .statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    @Test
    public void givenAccountNotFound_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, INVALID_ACCOUNT_NUMBER, TRANSACTIONS_PATH));

        String expectedError = "ACCOUNT_NOT_FOUND";
        String expectedDescription = String.format("account with number %s not found", INVALID_ACCOUNT_NUMBER);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenUnsupportedTransactionType_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createInvalidTypeTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenUnsupportedTransactionType_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createInvalidTypeTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "UNSUPPORTED_TRANSACTION_TYPE";
        String expectedDescription = String.format("transaction '%s' is not supported", UNSUPPORTED_TRANSACTION_TYPE);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenNotEnoughCreditsBuy_whenPost_thenBadRequest() {
        NotEnoughCreditsBuyException exception = new NotEnoughCreditsBuyException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenNotEnoughCreditsBuy_whenPost_thenErrorMessage() {
        NotEnoughCreditsBuyException exception = new NotEnoughCreditsBuyException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "NOT_ENOUGH_CREDITS";
        String expectedDescription = "not enough credits in wallet";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenNotEnoughCreditsSell_whenPost_thenBadRequest() {
        NotEnoughCreditsSellException exception = new NotEnoughCreditsSellException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenNotEnoughCreditsSell_whenPost_thenErrorMessage() {
        NotEnoughCreditsSellException exception = new NotEnoughCreditsSellException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "NOT_ENOUGH_CREDITS";
        String expectedDescription = "not enough credits to pay the transaction fee";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenZeroQuantity_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createZeroQuantityTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenNegativeQuantity_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createNegativeQuantityTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenInvalidQuantity_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createNegativeQuantityTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "INVALID_QUANTITY";
        String expectedDescription = "quantity is invalid";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenStockNotFound_whenPost_thenBadRequest() {
        StockNotFoundException exception = new StockNotFoundException(new StockId(INVALID_MARKET, INVALID_SYMBOL));
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenStockNotFound_whenPost_thenErrorMessage() {
        StockNotFoundException exception = new StockNotFoundException(new StockId(INVALID_MARKET, INVALID_SYMBOL));
        willThrow(exception).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "STOCK_NOT_FOUND";
        String expectedDescription = String.format("stock '%s:%s' not found", INVALID_SYMBOL, INVALID_MARKET);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenInvalidDate_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createInvalidDateTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenInvalidDate_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createInvalidDateTransactionRequest();

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "INVALID_DATE";
        String expectedDescription = "the transaction date is invalid";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenMarketClosed_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        willThrow(MarketClosedException.class).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenMarketClosed_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        willThrow(MarketClosedException.class).given(transactionApplicationService).purchaseTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "MARKET_CLOSED";
        String expectedDescription = String.format("market '%s' is closed", VALID_MARKET);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenInvalidTransactionNumberSell_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(InvalidTransactionNumberException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenInvalidTransactionNumberSell_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(InvalidTransactionNumberException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "INVALID_TRANSACTION_NUMBER";
        String expectedDescription = "the transaction number is invalid";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenNotEnoughStock_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(NotEnoughStockException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenNotEnoughStock_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(NotEnoughStockException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "NOT_ENOUGH_STOCK";
        String expectedDescription = String.format("not enough stock '%s:%s'", INVALID_SYMBOL, INVALID_MARKET);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenStockParametersDontMatch_whenPost_thenBadRequest() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(StockParametersDontMatchException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenStockParametersDontMatch_whenPost_thenErrorMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        willThrow(StockParametersDontMatchException.class).given(transactionApplicationService).sellTransaction(any(), any());

        scenario.given()
                .body(request);

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "STOCK_PARAMETERS_DONT_MATCH";
        String expectedDescription = "stock parameters don't match existing ones";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenValidTransactionNumber_whenGet_thenOk() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        TransactionDTO transactionDTO = getValidTransactionDTO(request);
        willReturn(transactionDTO).given(transactionApplicationService).getByTransactionNumber(any(), any());

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    public void givenValidBuyTransactionNumber_whenGet_thenAccountMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidBuyTransactionRequest();
        TransactionDTO transactionDTO = getValidTransactionDTO(request);
        willReturn(transactionDTO).given(transactionApplicationService).getByTransactionNumber(any(), any());

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .body("transactionNumber", equalTo(TRANSACTION_NUMBER_VALUE))
                .body("type", equalTo(TRANSACTION_TYPE_BUY))
                .body("date", equalTo(TRANSACTION_DATE_VALUE))
                .body("stock.market", equalTo(VALID_MARKET))
                .body("stock.symbol", equalTo(VALID_SYMBOL))
                .body("purchasedPrice", isA(Float.class))
                .body("quantity", equalTo(TRANSACTION_QUANTITY));
    }

    @Test
    public void givenValidSellTransactionNumber_whenGet_thenAccountMessage() {
        TransactionRequest request = TransactionRequestObjectMother.createValidSellTransactionRequest();
        TransactionDTO transactionDTO = getValidTransactionDTO(request);
        willReturn(transactionDTO).given(transactionApplicationService).getByTransactionNumber(any(), any());

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .body("transactionNumber", equalTo(TRANSACTION_NUMBER_VALUE))
                .body("type", equalTo(TRANSACTION_TYPE_SELL))
                .body("date", equalTo(TRANSACTION_DATE_VALUE))
                .body("stock.market", equalTo(VALID_MARKET))
                .body("stock.symbol", equalTo(VALID_SYMBOL))
                .body("soldPrice", isA(Float.class))
                .body("quantity", equalTo(TRANSACTION_QUANTITY));
    }

    @Test
    public void givenTransactionNotFound_whenGet_thenNotFound() {
        TransactionNotFoundException exception = new TransactionNotFoundException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).getByTransactionNumber(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    @Test
    public void givenTransactionNotFound_whenGet_thenErrorMessage() {
        TransactionNotFoundException exception = new TransactionNotFoundException(TRANSACTION_NUMBER);
        willThrow(exception).given(transactionApplicationService).getByTransactionNumber(any(), any());

        scenario.when()
                .post(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, TRANSACTIONS_PATH, TRANSACTION_NUMBER_VALUE));

        String expectedError = "ACCOUNT_NOT_FOUND";
        String expectedDescription = String.format("account with number %s not found", TRANSACTION_NUMBER_VALUE);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    private TransactionDTO getValidTransactionDTO(TransactionRequest transactionRequest) {
        TransactionDTO transactionDTO = new TransactionDTO();
        transactionDTO.setType(TransactionType.valueOf(transactionRequest.type));
        transactionDTO.setDate(TRANSACTION_DATE);
        transactionDTO.setStockId(new StockId(transactionRequest.stock.market, transactionRequest.stock.symbol));
        transactionDTO.setPrice(PRICE);
        transactionDTO.setQuantity(transactionRequest.quantity);
        transactionDTO.setFees(FEES);
        transactionDTO.setTransactionNumber(TRANSACTION_NUMBER);
        TransactionNumber referencedTransactionNumber;
        if (transactionRequest.transactionNumber == null) {
            referencedTransactionNumber = null;
        } else {
            referencedTransactionNumber = new TransactionNumber(transactionRequest.transactionNumber);
        }
        transactionDTO.setReferencedTransactionNumber(referencedTransactionNumber);
        return transactionDTO;
    }
}