package ca.ulaval.glo4002.trading;

import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

import static ca.ulaval.glo4002.trading.suites.ApiTestSuite.TEST_SERVER_PORT;
import static io.restassured.RestAssured.given;

public class BaseITest {

    protected RequestSpecification scenario = givenBaseRequest();

    protected RequestSpecification givenBaseRequest() {
        return given()
                .accept(ContentType.JSON)
                .port(TEST_SERVER_PORT)
                .contentType(ContentType.JSON);
    }

    protected String joinPath(String... paths) {
        return String.join("/", paths);
    }
}