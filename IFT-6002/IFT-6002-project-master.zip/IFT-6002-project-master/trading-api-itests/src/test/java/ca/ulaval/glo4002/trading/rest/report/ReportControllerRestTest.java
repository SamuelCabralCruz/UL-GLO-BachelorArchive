package ca.ulaval.glo4002.trading.rest.report;

import ca.ulaval.glo4002.trading.BaseITest;
import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.report.ReportApplicationService;
import ca.ulaval.glo4002.trading.application.report.daily.DailyReportDTO;
import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterlyReportDTO;
import io.restassured.http.ContentType;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.core.Response;
import java.time.LocalDate;

import static ca.ulaval.glo4002.trading.rest.account.AccountControllerRestTest.ACCOUNTS_PATH;
import static ca.ulaval.glo4002.trading.rest.account.AccountRequestObjectMother.ACCOUNT_NUMBER_VALUE;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.Matchers.any;

public class ReportControllerRestTest extends BaseITest {

    public static final String REPORTS_PATH = "/reports";
    public static final String TYPE_QUERY_PARAM_NAME = "type";
    public static final String DAILY = "DAILY";
    public static final String QUARTERLY = "QUARTERLY";
    public static final String DATE_QUERY_PARAM_NAME = "date";
    public static final String DATE = LocalDate.now().minusDays(1).toString();
    public static final String YEAR_QUERY_PARAM_NAME = "year";
    public static final String YEAR = "2017";
    public static final String QUARTER_QUERY_PARAM_NAME = "quarter";
    public static final String QUARTER = "Q1";
    public static final String INVALID = "INVALID";

    private ReportApplicationService reportApplicationService;

    @Before
    public void setUp() {
        reportApplicationService = ServiceLocator.resolve(ReportApplicationService.class);
    }

    @Test
    public void givenValidReportDailyRequest_whenGet_thenOk() {
        willReturn(new DailyReportDTO()).given(reportApplicationService).generateDailyReport(any(), any());

        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, DAILY)
                .queryParam(DATE_QUERY_PARAM_NAME, DATE);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    public void givenReportUnsupportedTypeRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, INVALID)
                .queryParam(DATE_QUERY_PARAM_NAME, DATE);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportUnsupportedTypeRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, INVALID)
                .queryParam(DATE_QUERY_PARAM_NAME, DATE);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "REPORT_TYPE_UNSUPPORTED";
        String expectedDescription = String.format("report '%s' is not supported", INVALID);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenMissingDateRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, DAILY);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportMissingDateRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, DAILY);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "MISSING_DATE";
        String expectedDescription = "date is missing";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenReportMissingTypeRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(DATE_QUERY_PARAM_NAME, DATE);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportMissingTypeRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(DATE_QUERY_PARAM_NAME, DATE);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "MISSING_REPORT_TYPE";
        String expectedDescription = "report type is missing";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenReportInvalidDateRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, DAILY)
                .queryParam(DATE_QUERY_PARAM_NAME, INVALID);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportInvalidDateRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, DAILY)
                .queryParam(DATE_QUERY_PARAM_NAME, INVALID);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "INVALID_DATE";
        String expectedDescription = String.format("date '%s' is invalid", INVALID);
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenValidReportQuarterlyRequest_whenGet_thenOk() {
        willReturn(new QuarterlyReportDTO()).given(reportApplicationService).generateQuarterlyReport(any(), any());

        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, QUARTERLY)
                .queryParam(YEAR_QUERY_PARAM_NAME, YEAR)
                .queryParam(QUARTER_QUERY_PARAM_NAME, QUARTER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .statusCode(Response.Status.OK.getStatusCode());
    }

    @Test
    public void givenReportInvalidYearRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, QUARTERLY)
                .queryParam(YEAR_QUERY_PARAM_NAME, INVALID)
                .queryParam(QUARTER_QUERY_PARAM_NAME, QUARTER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportInvalidYearRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, QUARTERLY)
                .queryParam(YEAR_QUERY_PARAM_NAME, INVALID)
                .queryParam(QUARTER_QUERY_PARAM_NAME, QUARTER);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "INVALID_YEAR";
        String expectedDescription = "the year is invalid";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

    @Test
    public void givenReportInvalidQuarterRequest_whenGet_thenBadRequest() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, QUARTERLY)
                .queryParam(YEAR_QUERY_PARAM_NAME, YEAR)
                .queryParam(QUARTER_QUERY_PARAM_NAME, INVALID);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        scenario.then()
                .contentType(ContentType.JSON)
                .statusCode(Response.Status.BAD_REQUEST.getStatusCode());
    }

    @Test
    public void givenReportInvalidQuarterRequest_whenGet_thenErrorMessage() {
        scenario.given()
                .queryParam(TYPE_QUERY_PARAM_NAME, QUARTERLY)
                .queryParam(YEAR_QUERY_PARAM_NAME, YEAR)
                .queryParam(QUARTER_QUERY_PARAM_NAME, INVALID);

        scenario.when()
                .get(joinPath(ACCOUNTS_PATH, ACCOUNT_NUMBER_VALUE, REPORTS_PATH));

        String expectedError = "INVALID_QUARTER";
        String expectedDescription = "the quarter is invalid";
        scenario.then()
                .body("error", equalTo(expectedError))
                .body("description", equalTo(expectedDescription));
    }

}