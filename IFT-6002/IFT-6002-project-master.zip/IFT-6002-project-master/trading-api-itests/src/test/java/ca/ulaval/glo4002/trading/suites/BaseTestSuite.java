package ca.ulaval.glo4002.trading.suites;

import ca.ulaval.glo4002.trading.TradingServer;
import ca.ulaval.glo4002.trading.application.ServiceLocator;
import org.junit.AfterClass;
import org.junit.BeforeClass;

public class BaseTestSuite {

    public static final int TEST_SERVER_PORT = 9393;

    private static TradingServer tradingServer;

    @BeforeClass
    public static void setUpClass() {
        tradingServer = new TradingServer();
        tradingServer.start(TEST_SERVER_PORT);
    }

    @AfterClass
    public static void tearDownClass() {
        if (tradingServer != null) {
            tradingServer.stop();
        }
    }

}
