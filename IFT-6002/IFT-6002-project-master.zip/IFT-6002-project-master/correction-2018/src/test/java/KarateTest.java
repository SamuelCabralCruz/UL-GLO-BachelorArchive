import ca.ulaval.glo4002.stocks.StocksServer;
import ca.ulaval.glo4002.trading.TradingServer;
import com.intuit.karate.junit4.Karate;
import cucumber.api.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@CucumberOptions(tags = {"~@ignore"})
@RunWith(Karate.class)
public class KarateTest {

    public static final int TEST_SERVER_PORT = 9494;

    private static TradingServer tradingServer;
    private static Thread stocksServer;

    @BeforeClass
    public static void setUpClass() throws InterruptedException {
        tradingServer = new TradingServer();
        tradingServer.start(TEST_SERVER_PORT);
        stocksServer = new Thread(new StocksServer(new String[]{}));
        stocksServer.start();
        stocksServer.join();
    }

    @AfterClass
    public static void tearDownClass() {
        if (stocksServer != null) {
            stocksServer.interrupt();
        }
        if (tradingServer != null) {
            tradingServer.stop();
        }
    }

}
