function configure() {
    karate.configure('headers', {'Content-Type': 'application/json'});

    return {
        tradingApiBaseUrl: 'http://localhost:9494',
        extractPath: function(path, location) {
            var loc = location.split(path);
            if (loc.length > 1) {
                return path + loc[1];
            } else {
                return location;
            }
        },
        randomInt: function () {
            return Math.floor(Math.random() * 100000)
        },
        closeTo: function (actual, expected, delta) {
            delta = delta || 0.10;
            return Math.abs(actual - expected) <= delta
        },
        getBody: function(response) {
            if (Object.prototype.toString.call(response) == '[object net.minidev.json.JSONArray]') {
                return response[0];
            } else {
                return response;
            }
        },
        exchangeRates: {
            USD: 1.31,
            CHF: 1.45,
            JPY: 0.01
        }
    };
}
