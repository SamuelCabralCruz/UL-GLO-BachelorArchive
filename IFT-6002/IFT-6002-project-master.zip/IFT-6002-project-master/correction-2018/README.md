# GLO-4002 UL - Correction projet 2018

## Prérequis

- Java 8
- Maven

## Utilisation

Démarrez le projet sous tests et exécutez la commande suivante:

```sh
mvn test
```

Ou faites un run de la classe KarateTest

