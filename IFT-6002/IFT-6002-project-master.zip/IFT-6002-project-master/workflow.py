import subprocess
import time
import signal

devnull = open('/dev/null', 'w')
log_file_name = __file__ + ".log"

exec = ["mvn", "clean"]
subprocess.run(exec, stdout=devnull)

exec = ["mvn", "test", "-l", log_file_name]
subprocess.run(exec, stdout=devnull)
exec = "tac " + log_file_name + " | grep -m1 -B $(cat " + log_file_name + " | wc -l) 'Results :' | tac"
subprocess.run(exec, shell=True)
exec = ["rm", log_file_name]
subprocess.run(exec)

exec = ["mvn", "exec:java", "-pl", "application"]
p1 = subprocess.Popen(exec, stdout=devnull)

time.sleep(20)

subprocess.run(["sh", "postman.sh"])
p1.send_signal(signal.SIGINT)
