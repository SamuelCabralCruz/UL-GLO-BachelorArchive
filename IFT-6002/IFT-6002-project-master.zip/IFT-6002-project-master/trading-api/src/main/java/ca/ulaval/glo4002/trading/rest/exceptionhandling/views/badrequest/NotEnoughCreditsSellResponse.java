package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.NotEnoughCreditsSellException;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class NotEnoughCreditsSellResponse extends BadRequestResponse {

    private static final String ERROR = "NOT_ENOUGH_CREDITS";
    private static final String DESCRIPTION = "not enough credits to pay the transaction fee";
    private final TransactionNumber transactionNumber;

    public NotEnoughCreditsSellResponse(NotEnoughCreditsSellException e) {
        this.transactionNumber = e.getTransactionNumber();
    }

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, DESCRIPTION, transactionNumber);
    }

}
