package ca.ulaval.glo4002.trading.domain.commons;


import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.currency.Currency;

import java.math.BigDecimal;
import java.util.stream.Collector;

public class Money extends ValueObject {

    private final Amount amount;
    private final Currency currency;

    public Money(double amount) {
        this(BigDecimal.valueOf(amount), Currency.DEFAULT_CURRENCY);
    }

    public Money(double amount, Currency currency) {
        this(BigDecimal.valueOf(amount), currency);
    }

    private Money(BigDecimal bigDecimal, Currency currency) {
        this.amount = new Amount(bigDecimal.doubleValue());
        this.currency = currency;
    }

    public Money(Money money) {
        this(money.getAmount(), money.getCurrency());
    }

    public Money(Amount amount, Currency currency) {
        this.amount = amount;
        this.currency = currency;
    }

    public Currency getCurrency() {
        return currency;
    }

    public Amount getAmount() {
        return amount;
    }

    public Money add(Money otherMoney) {
        return new Money(amount.add(otherMoney.amount), currency);
    }

    public Money subtract(Money otherMoney) {
        return new Money(amount.subtract(otherMoney.amount), currency);
    }

    public Money multiply(double number) {
        return new Money(amount.multiply(number), currency);
    }

    public Money negate() {
        return new Money(amount.negate(), currency);
    }

    public Money abs() {
        return new Money(amount.abs(), currency);
    }

    public boolean isNegativeAmount() {
        return amount.isNegativeAmount();
    }

    public boolean isNullAmount() {
        return amount.isNullAmount();
    }

    public static Collector<DividendPayment, Money[], Money> getSummingCollector() {
        return Collector.of(
                () -> new Money[1],
                (result, newItem) -> {
                    if (result[0] == null) {
                        result[0] = newItem.getValue();
                    } else {
                        result[0] = result[0].add(newItem.getValue());
                    }
                },
                (result1, result2) -> {
                    result1[0] = result1[0].add(result2[0]);
                    return result1;
                },
                total -> total[0]);
    }

    public double doubleValue() {
        return amount.getValue().doubleValue();
    }
}
