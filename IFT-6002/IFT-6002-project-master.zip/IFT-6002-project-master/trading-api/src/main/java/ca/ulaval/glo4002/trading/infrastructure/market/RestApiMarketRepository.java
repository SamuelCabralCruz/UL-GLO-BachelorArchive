package ca.ulaval.glo4002.trading.infrastructure.market;

import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.MarketNotFoundException;
import ca.ulaval.glo4002.trading.domain.market.Market;
import ca.ulaval.glo4002.trading.domain.market.MarketFactory;
import ca.ulaval.glo4002.trading.domain.market.MarketId;
import ca.ulaval.glo4002.trading.domain.market.MarketRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import java.io.IOException;

public class RestApiMarketRepository implements MarketRepository {

    private static final String URI = "http://localhost:8080";

    private static final String PATH = "markets";

    private WebTarget target;
    private MarketFactory marketFactory;

    public RestApiMarketRepository() {
        this(new MarketFactory());
    }

    public RestApiMarketRepository(MarketFactory marketFactory) {
        this.marketFactory = marketFactory;
        this.target = ClientBuilder.newClient()
                .target(URI)
                .path(PATH);
    }

    @Override
    public Market findByMarketId(MarketId marketId) {
        String response = getResponse(marketId);
        ObjectMapper mapper = new ObjectMapper();
        try {
            RestApiMarketDTO restApiMarketDTO = mapper.readValue(response, RestApiMarketDTO.class);
            return marketFactory.create(
                    restApiMarketDTO.getSymbol(),
                    restApiMarketDTO.getTimezone(),
                    restApiMarketDTO.getOpenHours());
        } catch (IOException e) {
            throw new MarketNotFoundException(marketId);
        }
    }

    private String getResponse(MarketId marketId) {
        String market = marketId.getValue();
        return target.path(market).request().get(String.class);
    }

}
