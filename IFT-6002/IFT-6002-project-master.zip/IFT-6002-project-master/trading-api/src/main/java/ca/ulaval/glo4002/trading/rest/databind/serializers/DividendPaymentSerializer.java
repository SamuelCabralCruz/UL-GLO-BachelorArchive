package ca.ulaval.glo4002.trading.rest.databind.serializers;

import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.rest.dividend.views.responses.DividendPaymentResponse;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

public class DividendPaymentSerializer extends JsonSerializer<DividendPayment> {

    @Override
    public void serialize(DividendPayment dividendPayment, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        DividendPaymentResponse dividendPaymentResponse = new DividendPaymentResponse();
        dividendPaymentResponse.setMarket(dividendPayment.getStockId().getMarket());
        dividendPaymentResponse.setSymbol(dividendPayment.getStockId().getSymbol());
        dividendPaymentResponse.setMarketprice(dividendPayment.getMarketPrice());
        dividendPaymentResponse.setDividends(dividendPayment.getValue());
        jsonGenerator.writeObject(dividendPaymentResponse);
    }

}
