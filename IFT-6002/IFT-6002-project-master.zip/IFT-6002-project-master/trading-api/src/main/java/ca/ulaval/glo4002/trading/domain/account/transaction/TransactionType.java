package ca.ulaval.glo4002.trading.domain.account.transaction;

public enum TransactionType {
    BUY,
    SELL
}
