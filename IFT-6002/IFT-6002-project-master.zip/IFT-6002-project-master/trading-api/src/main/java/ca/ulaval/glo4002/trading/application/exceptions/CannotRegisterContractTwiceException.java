package ca.ulaval.glo4002.trading.application.exceptions;

public class CannotRegisterContractTwiceException extends ServiceLocatorException {

    private static final long serialVersionUID = 1L;

    public CannotRegisterContractTwiceException(Class<?> contract) {
        super(String.format("You've tried to register this contract twice : '%s'", contract.getCanonicalName()));
    }

}