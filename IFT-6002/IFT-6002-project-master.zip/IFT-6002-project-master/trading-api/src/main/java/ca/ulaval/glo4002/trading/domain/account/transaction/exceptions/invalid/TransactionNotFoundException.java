package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

public class TransactionNotFoundException extends InvalidTransactionException {

    private final TransactionNumber transactionNumber;

    public TransactionNotFoundException(TransactionNumber transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public TransactionNumber getTransactionNumber() {
        return transactionNumber;
    }

}
