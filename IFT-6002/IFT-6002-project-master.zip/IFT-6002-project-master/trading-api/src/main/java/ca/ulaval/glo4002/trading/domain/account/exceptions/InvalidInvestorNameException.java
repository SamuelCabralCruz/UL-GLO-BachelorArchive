package ca.ulaval.glo4002.trading.domain.account.exceptions;

public class InvalidInvestorNameException extends AccountException {

    private final String investorName;

    public InvalidInvestorNameException(String investorName) {
        this.investorName = investorName;
    }

    public String getInvestorName() {
        return investorName;
    }

}
