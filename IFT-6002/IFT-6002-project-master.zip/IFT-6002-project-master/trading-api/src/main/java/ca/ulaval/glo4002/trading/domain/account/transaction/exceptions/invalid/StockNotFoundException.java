package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid;

import ca.ulaval.glo4002.trading.domain.stock.StockId;

public class StockNotFoundException extends InvalidTransactionException {

    private final StockId stockId;

    public StockNotFoundException(StockId stockId) {
        this.stockId = stockId;
    }

    public StockId getStockId() {
        return stockId;
    }

}
