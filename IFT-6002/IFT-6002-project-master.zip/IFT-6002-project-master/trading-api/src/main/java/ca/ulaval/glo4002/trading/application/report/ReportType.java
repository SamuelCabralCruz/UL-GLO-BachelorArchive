package ca.ulaval.glo4002.trading.application.report;

public enum ReportType {
    DAILY,
    QUARTERLY
}
