package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

public class NotEnoughCreditsBuyException extends NotEnoughCreditsException {

    public NotEnoughCreditsBuyException(TransactionNumber transactionNumber) {
        super(transactionNumber);
    }

}
