package ca.ulaval.glo4002.trading.domain.commons;

import java.math.BigDecimal;

public class Amount extends ValueObject {

    private final BigDecimal value;

    public Amount(double amount) {
        this(BigDecimal.valueOf(amount));
    }

    private Amount(BigDecimal bigDecimal) {
        this.value = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    public BigDecimal getValue() {
        return value;
    }

    public Amount add(Amount otherAmount) {
        return new Amount(value.add(otherAmount.value));
    }

    public Amount subtract(Amount otherAmount) {
        return new Amount(value.subtract(otherAmount.value));
    }

    public Amount multiply(double number) {
        return new Amount(value.doubleValue() * number);
    }

    public Amount negate() {
        return new Amount(value.negate());
    }

    public Amount abs() {
        return new Amount(value.abs());
    }

    public boolean isNegativeAmount() {
        return value.compareTo(BigDecimal.ZERO) < 0;
    }

    public boolean isNullAmount() {
        return value.compareTo(BigDecimal.ZERO) == 0;
    }

}
