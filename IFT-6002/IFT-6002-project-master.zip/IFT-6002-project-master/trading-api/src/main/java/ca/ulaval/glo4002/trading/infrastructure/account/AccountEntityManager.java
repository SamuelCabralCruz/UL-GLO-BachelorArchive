package ca.ulaval.glo4002.trading.infrastructure.account;

import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedAccount;
import ca.ulaval.glo4002.trading.domain.account.PersistedId;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.function.Predicate;

public class AccountEntityManager {

    public static final String GET_ALL_QUERY = "select o from PersistedAccount o";

    public AccountEntityManager() {
    }

    public PersistedId create() {
        PersistedAccount persistedAccount = new PersistedAccount();
        EntityManager entityManager = EntityManagerProvider.getEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(persistedAccount);
        } finally {
            entityManager.getTransaction().commit();
        }
        return persistedAccount.getPersistedId();
    }

    public void save(PersistedAccount persistedAccount) {
        EntityManager entityManager = EntityManagerProvider.getEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(persistedAccount);
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public void update(PersistedAccount accountToUpdate) {
        EntityManager entityManager = EntityManagerProvider.getEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(accountToUpdate);
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public void delete(PersistedId persistedId) {
        EntityManager entityManager = EntityManagerProvider.getEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.remove(getByPersistedId(persistedId));
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public List<PersistedAccount> getAll() {
        EntityManager entityManager = EntityManagerProvider.getEntityManager();
        return entityManager.createQuery(GET_ALL_QUERY, PersistedAccount.class).getResultList();
    }

    public PersistedAccount getByPersistedId(PersistedId persistedId) {
        Predicate<PersistedAccount> predicate = persistedAccount -> {
            PersistedId currentPersistedId = persistedAccount.getPersistedId();
            return currentPersistedId.equals(persistedId);
        };
        return getBy(predicate);
    }

    public PersistedAccount getByAccountNumber(AccountNumber accountNumber) {
        String accountNumberValue = accountNumber.getValue();
        Predicate<PersistedAccount> predicate = persistedAccount -> {
            String currentAccountNumber = persistedAccount.getAccountNumber();
            return currentAccountNumber.equals(accountNumberValue);
        };
        return getBy(predicate);
    }

    private PersistedAccount getBy(Predicate<PersistedAccount> predicate) {
        List<PersistedAccount> persistedAccounts = this.getAll();
        return persistedAccounts.stream().filter(predicate).findFirst().orElse(null);
    }


}
