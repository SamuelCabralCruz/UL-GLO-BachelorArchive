package ca.ulaval.glo4002.trading.rest.report.assemblers;

import ca.ulaval.glo4002.trading.application.report.daily.DailyReportDTO;
import ca.ulaval.glo4002.trading.rest.report.views.responses.DailyReportResponse;
import ca.ulaval.glo4002.trading.rest.transaction.TransactionViewAssembler;
import ca.ulaval.glo4002.trading.rest.transaction.views.responses.TransactionResponse;

import java.util.List;
import java.util.stream.Collectors;

public class DailyReportViewAssembler {

    private final TransactionViewAssembler transactionViewAssembler;

    public DailyReportViewAssembler() {
        this.transactionViewAssembler = new TransactionViewAssembler();
    }

    public DailyReportResponse from(DailyReportDTO dailyReportDTO) {
        DailyReportResponse dailyReportResponse = new DailyReportResponse();
        dailyReportResponse.setDate(dailyReportDTO.getDate());
        dailyReportResponse.setCredits(dailyReportDTO.getBalance());
        dailyReportResponse.setPortfolioValue(dailyReportDTO.getPortfolioValue());
        List<TransactionResponse> transactionResponses = dailyReportDTO.getTransactionDTOs().stream()
                .map(transactionViewAssembler::from).collect(Collectors.toList());
        dailyReportResponse.setTransactions(transactionResponses);
        dailyReportResponse.setStocks(dailyReportDTO.getDividendPayments());
        return dailyReportResponse;
    }

}
