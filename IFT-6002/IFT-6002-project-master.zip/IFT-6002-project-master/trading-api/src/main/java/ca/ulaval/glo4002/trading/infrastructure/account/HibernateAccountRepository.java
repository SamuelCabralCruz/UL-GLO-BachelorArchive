package ca.ulaval.glo4002.trading.infrastructure.account;

import ca.ulaval.glo4002.trading.domain.account.Account;
import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.AccountRepository;
import ca.ulaval.glo4002.trading.domain.account.PersistedId;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedAccount;
import ca.ulaval.glo4002.trading.infrastructure.account.hydratators.AccountHydratator;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HibernateAccountRepository implements AccountRepository {

    private AccountEntityManager accountEntityManager;
    private AccountHydratator accountHydratator;

    public HibernateAccountRepository() {
        this.accountEntityManager = new AccountEntityManager();
        this.accountHydratator = new AccountHydratator();
    }

    @Override
    public PersistedId create() {
        return accountEntityManager.create();
    }

    @Override
    public void save(PersistedId persistedId, Account account) {
        PersistedAccount persistedAccount = accountHydratator.dehydrate(account);
        persistedAccount.setPersistedId(persistedId);
        accountEntityManager.save(persistedAccount);
    }

    @Override
    public void update(Account account) {
        PersistedAccount persistedAccount = accountEntityManager.getByAccountNumber(account.getAccountNumber());
        PersistedAccount updatedPersistedAccount = accountHydratator.update(account, persistedAccount);
        accountEntityManager.update(updatedPersistedAccount);
    }

    @Override
    public void delete(PersistedId persistedId) {
        accountEntityManager.delete(persistedId);
    }

    @Override
    public List<Account> getAll() {
        List<PersistedAccount> persistedAccounts = accountEntityManager.getAll();
        Function<PersistedAccount, Account> function = persistedAccount -> accountHydratator.hydrate(persistedAccount);
        List<Account> accounts = persistedAccounts.stream().map(function).collect(Collectors.toList());
        return accounts;
    }

    @Override
    public Account findByAccountNumber(AccountNumber accountNumber) {
        PersistedAccount persistedAccount = accountEntityManager.getByAccountNumber(accountNumber);
        if (persistedAccount == null) {
            throw new AccountNotFoundException(accountNumber);
        }
        return accountHydratator.hydrate(persistedAccount);
    }

    @Override
    public boolean isExistingInvestor(InvestorId investorId) {
        List<Account> accounts = this.getAll();
        Predicate<Account> predicate = account -> account.getInvestorId().equals(investorId);
        return accounts.stream().anyMatch(predicate);
    }

}
