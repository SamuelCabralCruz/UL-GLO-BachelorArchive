package ca.ulaval.glo4002.trading.domain.account.dividend;

import ca.ulaval.glo4002.trading.domain.account.InvestmentPosition;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import org.apache.commons.lang.builder.EqualsBuilder;

import java.time.LocalDateTime;

public class Dividend {

    private LocalDateTime date;
    private Stock stock;
    private double dividendPerShare;

    public Dividend(Stock stock, LocalDateTime date, double dividendPerShare) {
        this.date = date;
        this.dividendPerShare = dividendPerShare;
        this.stock = stock;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public StockId getStockId() {
        return stock.getStockId();
    }

    public DividendPayment convertToPayment(InvestmentPosition investmentPosition) {
        Money marketPrice = stock.getPrice();
        long quantity = investmentPosition.getQuantity();
        Money commonDividend = new Money(quantity * dividendPerShare, marketPrice.getCurrency());
        Money preferredDividend = marketPrice.multiply(quantity * stock.getDividendRate());
        Money value = commonDividend.add(preferredDividend);
        return new DividendPayment(investmentPosition.getTransactionNumber(), stock.getStockId(), date, marketPrice, value);
    }

    @Override
    public boolean equals(Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

}
