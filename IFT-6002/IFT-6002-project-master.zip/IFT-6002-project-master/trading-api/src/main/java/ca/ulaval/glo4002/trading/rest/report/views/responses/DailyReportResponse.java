package ca.ulaval.glo4002.trading.rest.report.views.responses;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.rest.transaction.views.responses.TransactionResponse;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@JsonPropertyOrder({"date", "credits", "portfolioValue", "transactions", "stocks"})
public class DailyReportResponse {

    private LocalDateTime date;
    private Balance credits;
    private Money portfolioValue;
    private List<TransactionResponse> transactions = new ArrayList<>();
    private List<DividendPayment> stocks = new ArrayList<>();

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Balance getCredits() {
        return credits;
    }

    public void setCredits(Balance credits) {
        this.credits = credits;
    }

    public List<TransactionResponse> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<TransactionResponse> transactions) {
        this.transactions = transactions;
    }

    public Money getPortfolioValue() {
        return portfolioValue;
    }

    public void setPortfolioValue(Money portfolioValue) {
        this.portfolioValue = portfolioValue;
    }

    public List<DividendPayment> getStocks() {
        return stocks;
    }

    public void setStocks(List<DividendPayment> stocks) {
        this.stocks = stocks;
    }

}
