package ca.ulaval.glo4002.trading.rest.exceptionhandling;

import ca.ulaval.glo4002.trading.domain.account.dividend.exceptions.DividendInvalidDateException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountAlreadyOpenException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.EmptyCreditsException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidAmountException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.StockNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionInvalidDateException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.pending.MarketClosedException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.*;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;
import ca.ulaval.glo4002.trading.domain.currency.exceptions.UnsupportedCurrencyException;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest.*;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.views.notfound.AccountNotFoundResponse;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.views.notfound.TransactionNotFoundResponse;

import javax.ws.rs.core.Response.Status;

class ExceptionResponseFactory {

    ExceptionResponse createExceptionView(TradingApiException e) {
        if (e instanceof AccountAlreadyOpenException) {
            return new AccountAlreadyOpenResponse((AccountAlreadyOpenException) e);
        } else if (e instanceof AccountNotFoundException) {
            return new AccountNotFoundResponse((AccountNotFoundException) e);
        } else if (e instanceof InvalidAmountException) {
            return new InvalidAmountResponse();
        } else if (e instanceof InvalidTransactionNumberException) {
            return new InvalidTransactionNumberResponse((InvalidTransactionNumberException) e);
        } else if (e instanceof MarketClosedException) {
            return new MarketClosedResponse((MarketClosedException) e);
        } else if (e instanceof NotEnoughCreditsBuyException) {
            return new NotEnoughCreditsBuyResponse((NotEnoughCreditsBuyException) e);
        } else if (e instanceof NotEnoughCreditsSellException) {
            return new NotEnoughCreditsSellResponse((NotEnoughCreditsSellException) e);
        } else if (e instanceof NotEnoughStockException) {
            return new NotEnoughStockResponse((NotEnoughStockException) e);
        } else if (e instanceof StockNotFoundException) {
            return new StockNotFoundResponse((StockNotFoundException) e);
        } else if (e instanceof StockParametersDontMatchException) {
            return new StockParametersDontMatchResponse((StockParametersDontMatchException) e);
        } else if (e instanceof TransactionInvalidDateException) {
            return new TransactionInvalidDateResponse();
        } else if (e instanceof TransactionNotFoundException) {
            return new TransactionNotFoundResponse((TransactionNotFoundException) e);
        } else if (e instanceof EmptyCreditsException) {
            return new EmptyCreditsResponse();
        } else if (e instanceof UnsupportedCurrencyException) {
            return new UnsupportedCurrencyResponse((UnsupportedCurrencyException) e);
        } else if (e instanceof DividendInvalidDateException) {
            return new DividendInvalidDateResponse();
        }

        return new ExceptionResponse() {
            @Override
            public Status getStatus() {
                return Status.INTERNAL_SERVER_ERROR;
            }

            @Override
            public ExceptionMessage getMessage() {
                String error = "INTERNAL_SERVER_ERROR";
                String description = e.toString();
                return new ExceptionMessage(error, description);
            }
        };
    }

}
