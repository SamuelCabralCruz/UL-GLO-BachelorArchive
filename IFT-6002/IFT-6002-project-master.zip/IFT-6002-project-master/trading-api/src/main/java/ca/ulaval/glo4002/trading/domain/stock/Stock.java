package ca.ulaval.glo4002.trading.domain.stock;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

public class Stock {

    private StockId stockId;
    private Money price;
    private StockType type;
    private double dividendRate;

    public Stock(StockId stockId, Money price, StockType type, double dividendRate) {
        this.stockId = stockId;
        this.price = price;
        this.type = type;
        this.dividendRate = dividendRate;
    }

    public StockId getStockId() {
        return stockId;
    }

    public Money getPrice() {
        return price;
    }

    public StockType getType() {
        return type;
    }

    public double getDividendRate() {
        return dividendRate;
    }

}
