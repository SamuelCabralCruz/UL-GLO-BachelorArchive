package ca.ulaval.glo4002.trading.application.account;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.*;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountAlreadyOpenException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.currency.CurrencyExchanger;
import ca.ulaval.glo4002.trading.domain.currency.ExchangeRateRepository;
import ca.ulaval.glo4002.trading.domain.currency.exceptions.UnsupportedCurrencyException;

import java.util.List;

public class AccountApplicationService {

    private final AccountRepository accountRepository;
    private final AccountFactory accountFactory;
    private final AccountDomainAssembler accountDomainAssembler;
    private final ExchangeRateRepository exchangeRateRepository;
    private final CurrencyExchanger currencyExchanger;

    public AccountApplicationService() {
        this(
                ServiceLocator.resolve(AccountRepository.class),
                ServiceLocator.resolve(AccountFactory.class),
                ServiceLocator.resolve(AccountDomainAssembler.class),
                ServiceLocator.resolve(ExchangeRateRepository.class),
                ServiceLocator.resolve(CurrencyExchanger.class)
        );
    }

    AccountApplicationService(AccountRepository accountRepository,
                              AccountFactory accountFactory,
                              AccountDomainAssembler accountDomainAssembler,
                              ExchangeRateRepository exchangeRateRepository,
                              CurrencyExchanger currencyExchanger) {
        this.accountRepository = accountRepository;
        this.accountFactory = accountFactory;
        this.accountDomainAssembler = accountDomainAssembler;
        this.exchangeRateRepository = exchangeRateRepository;
        this.currencyExchanger = currencyExchanger;
    }

    public AccountNumber createAccount(AccountDTO accountDTO) {
        checkIfAlreadyOpenAccount(accountDTO.getInvestorId());
        checkIfValidCurrencies(accountDTO.getBalance().getCredits());
        PersistedId persistedId = accountRepository.create();
        try {
            Account account = accountFactory.create(
                    persistedId,
                    accountDTO.getInvestorId(),
                    accountDTO.getInvestorName(),
                    accountDTO.getBalance());
            accountRepository.save(persistedId, account);
            return account.getAccountNumber();
        } catch (Exception e) {
            accountRepository.delete(persistedId);
            throw e;
        }
    }

    private void checkIfAlreadyOpenAccount(InvestorId investorId) {
        if (accountRepository.isExistingInvestor(investorId)) {
            throw new AccountAlreadyOpenException(investorId);
        }
    }

    private void checkIfValidCurrencies(List<Money> credits) {
        for (Money credit : credits) {
            Currency currency = credit.getCurrency();
            checkIfValidCurrency(currency);
        }
    }

    private void checkIfValidCurrency(Currency currency) {
        if (!exchangeRateRepository.containsCurrency(currency)) {
            throw new UnsupportedCurrencyException(currency);
        }
    }

    public AccountDTO getByAccountNumber(AccountNumber accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        AccountDTO accountDTO = accountDomainAssembler.from(account);
        accountDTO.setTotal(currencyExchanger.getTotal(account.getBalance().getCredits()));
        return accountDTO;
    }

}