package ca.ulaval.glo4002.trading.domain.currency.exceptions;

import ca.ulaval.glo4002.trading.domain.currency.Currency;

public class UnsupportedCurrencyException extends CurrencyException {

    private final Currency currency;

    public UnsupportedCurrencyException(Currency currency) {
        this.currency = currency;
    }

    public Currency getCurrency() {
        return currency;
    }
}
