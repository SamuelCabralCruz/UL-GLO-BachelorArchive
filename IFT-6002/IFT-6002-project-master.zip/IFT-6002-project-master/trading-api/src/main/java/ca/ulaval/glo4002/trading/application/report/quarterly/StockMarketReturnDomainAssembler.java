package ca.ulaval.glo4002.trading.application.report.quarterly;

import ca.ulaval.glo4002.trading.domain.report.stockmarketreturn.StockMarketReturn;

public class StockMarketReturnDomainAssembler {

    public StockMarketReturnDTO from(StockMarketReturn stockMarketReturn) {
        StockMarketReturnDTO stockMarketReturnDTO = new StockMarketReturnDTO();
        stockMarketReturnDTO.setStockId(stockMarketReturn.getStockId());
        stockMarketReturnDTO.setRateOfReturn(stockMarketReturn.getRateOfReturn());
        stockMarketReturnDTO.setTotalDividends(stockMarketReturn.getTotalDividends());
        stockMarketReturnDTO.setQuantity(stockMarketReturn.getQuantity());
        return stockMarketReturnDTO;
    }

}
