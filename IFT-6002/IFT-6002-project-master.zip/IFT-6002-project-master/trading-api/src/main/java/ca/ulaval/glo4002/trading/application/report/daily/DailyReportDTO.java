package ca.ulaval.glo4002.trading.application.report.daily;

import ca.ulaval.glo4002.trading.application.transaction.TransactionDTO;
import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.commons.Money;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DailyReportDTO {

    private LocalDateTime date;
    private Balance balance;
    private Money portfolioValue;
    private List<TransactionDTO> transactionDTOs = new ArrayList<>();
    private List<DividendPayment> dividendPayments = new ArrayList<>();

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Balance getBalance() {
        return balance;
    }

    public void setBalance(Balance balance) {
        this.balance = balance;
    }

    public List<TransactionDTO> getTransactionDTOs() {
        return transactionDTOs;
    }

    public void setTransactionDTOs(List<TransactionDTO> transactionDTOs) {
        this.transactionDTOs = transactionDTOs;
    }

    public Money getPortfolioValue() {
        return portfolioValue;
    }

    public void setPortfolioValue(Money portfolioValue) {
        this.portfolioValue = portfolioValue;
    }

    public List<DividendPayment> getDividendPayments() {
        return dividendPayments;
    }

    public void setDividendPayments(List<DividendPayment> dividendPayments) {
        this.dividendPayments = dividendPayments;
    }

}
