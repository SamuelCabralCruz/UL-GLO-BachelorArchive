package ca.ulaval.glo4002.trading.rest.account;


import ca.ulaval.glo4002.trading.application.account.AccountDTO;
import ca.ulaval.glo4002.trading.rest.account.views.requests.AccountRequest;
import ca.ulaval.glo4002.trading.rest.account.views.responses.AccountResponse;
import ca.ulaval.glo4002.trading.rest.account.views.responses.InvestorProfileResponse;

public class AccountViewAssembler {

    public AccountDTO from(AccountRequest accountRequest) {
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setInvestorId(accountRequest.getInvestorId());
        accountDTO.setInvestorName(accountRequest.getInvestorName());
        accountDTO.setBalance(accountRequest.getCredits());
        return accountDTO;
    }

    public AccountResponse from(AccountDTO accountDTO) {
        AccountResponse accountResponse = new AccountResponse();
        accountResponse.setAccountNumber(accountDTO.getAccountNumber());
        accountResponse.setInvestorId(accountDTO.getInvestorId());
        accountResponse.setInvestorProfile(getInvestorProfileResponse(accountDTO));
        accountResponse.setCredits(accountDTO.getBalance());
        accountResponse.setTotal(accountDTO.getTotal());
        return accountResponse;
    }

    private InvestorProfileResponse getInvestorProfileResponse(AccountDTO accountDTO) {
        InvestorProfileResponse investorProfileResponse = new InvestorProfileResponse();
        investorProfileResponse.setType(accountDTO.getInvestorType().toString());
        investorProfileResponse.setFocusAreas(accountDTO.getFocusAreas());
        return investorProfileResponse;
    }

}
