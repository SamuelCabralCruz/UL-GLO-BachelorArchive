package ca.ulaval.glo4002.trading.application.report.quarterly;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;

import java.time.*;

public class Quarter extends ValueObject {

    private QuarterType quarterType;
    private LocalDateTime beginning;
    private LocalDateTime ending;

    public Quarter(LocalDateTime date) {
        this(Year.from(date), QuarterType.fromLocalDateTime(date));
    }

    public Quarter(Year year, QuarterType quarterType) {
        this.quarterType = quarterType;
        MonthDay quarterTypeStart = quarterType.getBeginning();
        int quarterStartMonth = quarterTypeStart.getMonth().getValue();
        int quarterStartDay = quarterTypeStart.getDayOfMonth();
        LocalDate quarterStartDate = LocalDate.of(year.getValue(), quarterStartMonth, quarterStartDay);
        this.beginning = LocalDateTime.of(quarterStartDate, LocalTime.MIN);
        MonthDay quarterTypeEnd = quarterType.getEnding();
        int quarterEndMonth = quarterTypeEnd.getMonth().getValue();
        int quarterEndDay = quarterTypeEnd.getDayOfMonth();
        LocalDate quarterEndDate = LocalDate.of(year.getValue(), quarterEndMonth, quarterEndDay);
        this.ending = LocalDateTime.of(quarterEndDate, LocalTime.MAX);
    }

    public QuarterType getQuarterType() {
        return quarterType;
    }

    public LocalDateTime getBeginning() {
        return beginning;
    }

    public LocalDateTime getEnding() {
        return ending;
    }

    public static Quarter getCurrentQuarter() {
        return new Quarter(Year.now(), QuarterType.getCurrentQuarterType());
    }

}
