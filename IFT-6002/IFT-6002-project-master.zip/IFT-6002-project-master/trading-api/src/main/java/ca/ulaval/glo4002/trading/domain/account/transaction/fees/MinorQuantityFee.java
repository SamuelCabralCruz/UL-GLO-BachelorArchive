package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class MinorQuantityFee implements Fee {

    private static final float MINOR_FEE_PER_SHARE = 0.25f;

    @Override
    public Money calculate(long quantity, Money amount) {
        return new Money(quantity * MINOR_FEE_PER_SHARE, amount.getCurrency());
    }

}
