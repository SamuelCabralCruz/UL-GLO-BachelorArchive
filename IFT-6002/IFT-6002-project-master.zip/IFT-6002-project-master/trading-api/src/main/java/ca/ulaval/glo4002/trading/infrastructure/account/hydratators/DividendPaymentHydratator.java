package ca.ulaval.glo4002.trading.infrastructure.account.hydratators;

import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedDividendPayment;

import java.time.LocalDateTime;

public class DividendPaymentHydratator {

    private StockIdHydratator stockIdHydratator;
    private MoneyHydratator moneyHydratator;

    DividendPaymentHydratator() {
        this.stockIdHydratator = new StockIdHydratator();
        this.moneyHydratator = new MoneyHydratator();
    }

    PersistedDividendPayment dehydrate(DividendPayment dividendPayment) {
        PersistedDividendPayment persistedDividendPayment = new PersistedDividendPayment();
        persistedDividendPayment.setTransactionNumber(dividendPayment.getTransactionNumber().getValue().toString());
        persistedDividendPayment.setStockId(stockIdHydratator.dehydrate(dividendPayment.getStockId()));
        persistedDividendPayment.setDate(dividendPayment.getDate().toString());
        persistedDividendPayment.setMarketPrice(moneyHydratator.dehydrate(dividendPayment.getMarketPrice()));
        persistedDividendPayment.setValue(moneyHydratator.dehydrate(dividendPayment.getValue()));
        return persistedDividendPayment;
    }

    DividendPayment hydrate(PersistedDividendPayment persistedDividendPayment) {
        DividendPayment dividendPayment = new DividendPayment();
        String transactionNumberString = persistedDividendPayment.getTransactionNumber();
        dividendPayment.setTransactionNumber(new TransactionNumber(transactionNumberString));
        StockId stockId = stockIdHydratator.hydrate(persistedDividendPayment.getStockId());
        dividendPayment.setStockId(stockId);
        dividendPayment.setDate(LocalDateTime.parse(persistedDividendPayment.getDate()));
        dividendPayment.setMarketPrice(moneyHydratator.hydrate(persistedDividendPayment.getMarketPrice()));
        dividendPayment.setValue(moneyHydratator.hydrate(persistedDividendPayment.getValue()));
        return dividendPayment;
    }

}
