package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class FeeFactory {

    private static final long MINOR_QUANTITY_UPPER_LIMIT = 100L;
    private static final float MINOR_AMOUNT_UPPER_LIMIT = 5000f;

    public Money create(long quantity, Money amount) {
        CompositeFee taxable = new CompositeFee();
        addQuantityFee(quantity, taxable);
        addAmountFee(amount, taxable);
        return taxable.calculate(quantity, amount);
    }

    private void addQuantityFee(long quantity, CompositeFee taxable) {
        if (quantity <= MINOR_QUANTITY_UPPER_LIMIT) {
            taxable.add(new MinorQuantityFee());
        } else {
            taxable.add(new MajorQuantityFee());
        }
    }

    private void addAmountFee(Money amount, CompositeFee taxable) {
        double amountValue = amount.doubleValue();
        if (amountValue <= MINOR_AMOUNT_UPPER_LIMIT) {
            taxable.add(new MinorAmountFee());
        } else {
            taxable.add(new MajorAmountFee());
        }
    }

}
