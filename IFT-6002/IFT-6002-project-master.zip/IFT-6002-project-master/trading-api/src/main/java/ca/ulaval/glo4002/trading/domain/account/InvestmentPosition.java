package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.commons.ValueObject;
import ca.ulaval.glo4002.trading.domain.stock.StockId;

public class InvestmentPosition extends ValueObject {

    private final TransactionNumber transactionNumber;
    private final StockId stockId;
    private final Long quantity;

    public InvestmentPosition(TransactionNumber transactionNumber, StockId stockId, long quantity) {
        this.transactionNumber = transactionNumber;
        this.stockId = stockId;
        this.quantity = quantity;
    }

    public TransactionNumber getTransactionNumber() {
        return transactionNumber;
    }

    public StockId getStockId() {
        return stockId;
    }

    public long getQuantity() {
        return quantity;
    }

}
