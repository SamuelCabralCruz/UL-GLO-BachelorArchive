package ca.ulaval.glo4002.trading.domain.market;

import ca.ulaval.glo4002.trading.domain.commons.Period;
import org.apache.commons.lang.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MarketFactory {

    public Market create(String symbol, String timezone, List<String> openHours) {
        ZoneOffset zoneOffset = parseZoneOffset(timezone);
        List<Period> periods = parseOpenHours(openHours);
        return new Market(symbol, zoneOffset, periods);
    }

    private ZoneOffset parseZoneOffset(String timezone) {
        String offset = timezone.replace("UTC", "");
        return ZoneOffset.of(offset);
    }

    private List<Period> parseOpenHours(List<String> openHoursDTO) {
        List<Period> openHours = new ArrayList<>();
        for (String stringPeriod : openHoursDTO) {
            Period period = parsePeriod(stringPeriod);
            openHours.add(period);
        }
        return openHours;
    }

    private Period parsePeriod(String period) {
        String[] slots = period.split("-");
        LocalDateTime openingDateTime = parseHour(slots[0]);
        LocalDateTime closingDateTime = parseHour(slots[1]);
        return new Period(openingDateTime, closingDateTime);
    }

    private LocalDateTime parseHour(String hour) {
        String formattedHour = StringUtils.leftPad(hour, 5, '0');
        DateTimeFormatter timeFormatter = DateTimeFormatter.ISO_LOCAL_TIME;
        LocalTime parsedHour = LocalTime.parse(formattedHour, timeFormatter);
        LocalDate today = LocalDate.now();
        return LocalDateTime.of(today, parsedHour);
    }

}
