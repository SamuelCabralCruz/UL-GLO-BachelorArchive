package ca.ulaval.glo4002.trading.domain.account.exceptions;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;

public class AccountException extends TradingApiException {
}
