package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

public class InvalidTransactionNumberException extends RejectedTransactionException {

    public InvalidTransactionNumberException(TransactionNumber transactionNumber) {
        super(transactionNumber);
    }

}
