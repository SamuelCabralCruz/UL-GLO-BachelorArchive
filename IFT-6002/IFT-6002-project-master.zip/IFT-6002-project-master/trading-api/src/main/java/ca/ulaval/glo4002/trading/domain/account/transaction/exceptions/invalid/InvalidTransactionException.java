package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid;

import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.TransactionException;

class InvalidTransactionException extends TransactionException {

}
