package ca.ulaval.glo4002.trading.rest.databind.deserializers;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.rest.databind.deserializers.exceptions.CurrencyAlreadyDefinedException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BalanceDeserializer extends JsonDeserializer<Balance> {

    @Override
    public Balance deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        ArrayNode nodes = jsonParser.getCodec().readTree(jsonParser);
        List<Currency> currencies = new ArrayList<>();
        List<Money> credits = new ArrayList<>();
        for (JsonNode node : nodes) {
            Currency currency = getCurrency(node);
            checkIfCurrencyAlreadyDefined(currencies, currency);
            currencies.add(currency);
            float creditsValue = node.get("amount").floatValue();
            Money money = new Money(creditsValue, currency);
            credits.add(money);
        }
        return new Balance(credits);
    }

    private Currency getCurrency(JsonNode node) {
        String textValue = node.get("currency").textValue();
        return new Currency(textValue);
    }

    private void checkIfCurrencyAlreadyDefined(List<Currency> currencies, Currency currency) throws CurrencyAlreadyDefinedException {
        if (currencies.contains(currency)) {
            throw new CurrencyAlreadyDefinedException(currency);
        }
    }

}
