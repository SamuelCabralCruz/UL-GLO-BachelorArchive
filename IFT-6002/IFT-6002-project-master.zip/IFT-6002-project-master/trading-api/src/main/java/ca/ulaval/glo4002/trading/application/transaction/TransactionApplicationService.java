package ca.ulaval.glo4002.trading.application.transaction;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.Account;
import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.AccountRepository;
import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionFactory;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionInvalidDateException;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;
import ca.ulaval.glo4002.trading.domain.market.Market;
import ca.ulaval.glo4002.trading.domain.market.MarketId;
import ca.ulaval.glo4002.trading.domain.market.MarketRepository;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.domain.stock.StockRepository;

import java.time.LocalDateTime;

public class TransactionApplicationService {

    private final AccountRepository accountRepository;
    private final StockRepository stockRepository;
    private final MarketRepository marketRepository;
    private final TransactionDomainAssembler transactionDomainAssembler;
    private final TransactionFactory transactionFactory;

    public TransactionApplicationService() {
        this(
                ServiceLocator.resolve(AccountRepository.class),
                ServiceLocator.resolve(StockRepository.class),
                ServiceLocator.resolve(MarketRepository.class),
                ServiceLocator.resolve(TransactionDomainAssembler.class),
                ServiceLocator.resolve(TransactionFactory.class)
        );
    }

    TransactionApplicationService(AccountRepository accountRepository,
                                  StockRepository stockRepository,
                                  MarketRepository marketRepository,
                                  TransactionDomainAssembler transactionDomainAssembler,
                                  TransactionFactory transactionFactory) {
        this.accountRepository = accountRepository;
        this.stockRepository = stockRepository;
        this.marketRepository = marketRepository;
        this.transactionDomainAssembler = transactionDomainAssembler;
        this.transactionFactory = transactionFactory;
    }

    public TransactionNumber purchaseTransaction(AccountNumber accountNumber, TransactionDTO transactionDTO) {
        return processTransaction(accountNumber, transactionDTO, Account::buy);
    }

    public TransactionNumber sellTransaction(AccountNumber accountNumber, TransactionDTO transactionDTO) {
        return processTransaction(accountNumber, transactionDTO, Account::sell);
    }

    private TransactionNumber processTransaction(AccountNumber accountNumber,
                                                 TransactionDTO transactionDTO,
                                                 AccountTransactionHandler accountTransactionHandler) {
        StockId stockId = transactionDTO.getStockId();
        LocalDateTime date = transactionDTO.getDate();
        Money price = getPrice(stockId, date);
        Transaction transaction = transactionFactory.create(transactionDTO.getReferencedTransactionNumber(),
                stockId, price, transactionDTO.getQuantity(), date, transactionDTO.getType());
        checkIfMarketIsClosed(transaction);
        Account account = accountRepository.findByAccountNumber(accountNumber);
        accountTransactionHandler.handle(account, transaction);
        accountRepository.update(account);
        return transaction.getTransactionNumber();
    }

    private Money getPrice(StockId stockId, LocalDateTime date) {
        try {
            Stock stock = stockRepository.findByStockIdAndDate(stockId, date);
            return stock.getPrice();
        } catch (InvalidDateException e) {
            throw new TransactionInvalidDateException();
        }
    }

    private void checkIfMarketIsClosed(Transaction transaction) {
        MarketId marketId = transaction.getStockId().getMarket();
        Market market = marketRepository.findByMarketId(marketId);
        market.checkIfMarketIsClosed(transaction);
    }

    private interface AccountTransactionHandler {
        void handle(Account account, Transaction transaction);
    }

    public TransactionDTO getByTransactionNumber(AccountNumber accountNumber, TransactionNumber transactionNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        Transaction transaction = account.getTransaction(transactionNumber);
        return transactionDomainAssembler.from(transaction);
    }

}
