package ca.ulaval.glo4002.trading.domain.currency;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;

public class Currency extends ValueObject {

    public static Currency DEFAULT_CURRENCY = new Currency("CAD");

    private String value;

    public Currency(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
