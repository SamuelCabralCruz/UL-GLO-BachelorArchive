package ca.ulaval.glo4002.trading.domain.report;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.*;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.Period;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;
import ca.ulaval.glo4002.trading.domain.currency.CurrencyExchanger;
import ca.ulaval.glo4002.trading.domain.report.historic.HistoricReport;
import ca.ulaval.glo4002.trading.domain.report.stockmarketreturn.StockMarketReturn;
import ca.ulaval.glo4002.trading.domain.report.stockmarketreturn.StockMarketReturnReport;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.domain.stock.StockRepository;
import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportInvalidDateException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Reporter {

    private final AccountRepository accountRepository;
    private final StockRepository stockRepository;
    private final CurrencyExchanger currencyExchanger;

    public Reporter() {
        this(
                ServiceLocator.resolve(AccountRepository.class),
                ServiceLocator.resolve(StockRepository.class),
                ServiceLocator.resolve(CurrencyExchanger.class)
        );
    }

    Reporter(AccountRepository accountRepository,
             StockRepository stockRepository,
             CurrencyExchanger currencyExchanger) {
        this.accountRepository = accountRepository;
        this.stockRepository = stockRepository;
        this.currencyExchanger = currencyExchanger;
    }

    public HistoricReport generateHistoricReport(AccountNumber accountNumber, Period period) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        LocalDateTime ending = period.getEnding();
        List<InvestmentPosition> investmentPositions = account.getInvestmentPositionsAsOf(ending);
        Money portfolioValue = computePortfolioValue(ending, investmentPositions);
        Balance balance = account.getBalanceAsOf(ending);
        List<Transaction> transactions = account.getTransactionsOver(period);
        List<DividendPayment> dividendPayments = account.getDividendPaymentsOver(period);
        return new HistoricReport(period, balance, portfolioValue, transactions, dividendPayments);
    }

    private Money computePortfolioValue(LocalDateTime date, List<InvestmentPosition> investmentPositions) {
        List<Money> stockValues = new ArrayList<>();
        for (InvestmentPosition investmentPosition : investmentPositions) {
            StockId stockId = investmentPosition.getStockId();
            Money price = getStockPriceAsOf(stockId, date);
            long quantity = investmentPosition.getQuantity();
            Money stockValue = price.multiply(quantity);
            stockValues.add(stockValue);
        }
        return currencyExchanger.getTotal(stockValues);
    }

    public StockMarketReturnReport generateStockMarketReport(AccountNumber accountNumber, Period period) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        Map<StockId, Map<Money, Long>> aggregatedInvestmentPositions = getAggregatedInvestmentPositions(account, period);
        Map<StockId, Map<Money, Money>> aggregatedDividendPayments = getAggregatedDividendPayments(account, period);
        List<StockMarketReturn> stockMarketReturns = getStockMarketReturns(period, aggregatedInvestmentPositions, aggregatedDividendPayments);
        return new StockMarketReturnReport(period, stockMarketReturns);
    }

    private Map<StockId, Map<Money, Long>> getAggregatedInvestmentPositions(Account account, Period period) {
        List<InvestmentPosition> investmentPositions = account.getInvestmentPositionsOver(period);
        return investmentPositions.stream().collect(
                Collectors.groupingBy(InvestmentPosition::getStockId,
                        Collectors.groupingBy(ip -> {
                            TransactionNumber transactionNumber = ip.getTransactionNumber();
                            Transaction transaction = account.getTransaction(transactionNumber);
                            return transaction.getPrice();
                        }, Collectors.summingLong(InvestmentPosition::getQuantity))));
    }

    private Map<StockId, Map<Money, Money>> getAggregatedDividendPayments(Account account, Period period) {
        List<DividendPayment> dividendPayments = account.getDividendPaymentsOver(period);
        return dividendPayments.stream().collect(
                Collectors.groupingBy(DividendPayment::getStockId,
                        Collectors.groupingBy((DividendPayment dp) -> {
                            TransactionNumber transactionNumber = dp.getTransactionNumber();
                            Transaction transaction = account.getTransaction(transactionNumber);
                            return transaction.getPrice();
                        }, Money.getSummingCollector())));
    }

    private List<StockMarketReturn> getStockMarketReturns(Period period,
                                                          Map<StockId, Map<Money, Long>> investmentPositions,
                                                          Map<StockId, Map<Money, Money>> dividendPayments) {
        List<StockMarketReturn> stockMarketReturns = new ArrayList<>();
        investmentPositions.forEach((stockId, value) -> {
            Function<Map.Entry<Money, Long>, StockMarketReturn> function = quantityMapEntry -> {
                float rateOfReturn = computeRateOfReturn(stockId, period);
                Money purchasePrice = quantityMapEntry.getKey();
                Money dividendValue = dividendPayments
                        .getOrDefault(stockId, new HashMap<>())
                        .getOrDefault(purchasePrice, new Money(0f));
                Long quantity = quantityMapEntry.getValue();
                return new StockMarketReturn(stockId, rateOfReturn, dividendValue, quantity);
            };
            value.entrySet().stream().map(function).forEach(stockMarketReturns::add);
        });
        return stockMarketReturns;
    }

    private float computeRateOfReturn(StockId stockId, Period period) {
        LocalDateTime beginning = period.getBeginning();
        LocalDateTime ending = period.getEnding();
        double stockPriceBegin = getStockPriceAsOf(stockId, beginning).doubleValue();
        double stockPriceEnd = getStockPriceAsOf(stockId, ending).doubleValue();
        double rateOfReturn = (stockPriceEnd - stockPriceBegin) / stockPriceBegin * 100;
        return BigDecimal.valueOf(rateOfReturn).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
    }

    private Money getStockPriceAsOf(StockId stockId, LocalDateTime date) {
        try {
            Stock stock = stockRepository.findByStockIdAndDate(stockId, date);
            return stock.getPrice();
        } catch (InvalidDateException e) {
            throw new ReportInvalidDateException(date.toLocalDate());
        }
    }

}
