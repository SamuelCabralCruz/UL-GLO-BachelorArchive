package ca.ulaval.glo4002.trading.application.dividend;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.Account;
import ca.ulaval.glo4002.trading.domain.account.AccountRepository;
import ca.ulaval.glo4002.trading.domain.account.dividend.Dividend;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendFactory;
import ca.ulaval.glo4002.trading.domain.account.dividend.exceptions.DividendException;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.domain.stock.StockRepository;

import java.time.LocalDateTime;
import java.util.List;

public class DividendApplicationService {

    private final AccountRepository accountRepository;
    private final StockRepository stockRepository;
    private final DividendFactory dividendFactory;

    public DividendApplicationService() {
        this(
                ServiceLocator.resolve(AccountRepository.class),
                ServiceLocator.resolve(StockRepository.class),
                ServiceLocator.resolve(DividendFactory.class)
        );
    }

    DividendApplicationService(AccountRepository accountRepository,
                               StockRepository stockRepository,
                               DividendFactory dividendFactory) {
        this.accountRepository = accountRepository;
        this.stockRepository = stockRepository;
        this.dividendFactory = dividendFactory;
    }

    public void createDividend(DividendDTO dividendDTO) {
        LocalDateTime date = dividendDTO.getDate();
        Stock stock = getInstantStock(dividendDTO.getStockId(), date);
        Dividend dividend = dividendFactory.create(stock, date, dividendDTO.getDividendPerShare());
        List<Account> accounts = accountRepository.getAll();
        accounts.forEach(account -> {
            account.applyDividend(dividend);
            accountRepository.update(account);
        });
    }

    private Stock getInstantStock(StockId stockId, LocalDateTime date) {
        try {
            return stockRepository.findByStockIdAndDate(stockId, date);
        } catch (InvalidDateException e) {
            throw new DividendException();
        }
    }

}
