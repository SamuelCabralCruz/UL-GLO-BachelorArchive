package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.StockNotFoundException;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class StockNotFoundResponse extends BadRequestResponse {

    private static final String ERROR = "STOCK_NOT_FOUND";
    private static final String DESCRIPTION = "stock '%s:%s' not found";
    private StockId stockId;

    public StockNotFoundResponse(StockNotFoundException e) {
        this.stockId = e.getStockId();
    }

    @Override
    public ExceptionMessage getMessage() {
        String symbol = stockId.getSymbol().getValue();
        String market = stockId.getMarket().getValue();
        return new ExceptionMessage(
                ERROR,
                String.format(DESCRIPTION, symbol, market)
        );
    }

}
