package ca.ulaval.glo4002.trading.application.report;

import ca.ulaval.glo4002.trading.application.report.daily.DailyReportDTO;
import ca.ulaval.glo4002.trading.application.report.quarterly.Quarter;
import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterlyReportDTO;
import ca.ulaval.glo4002.trading.application.report.quarterly.StockMarketReturnDTO;
import ca.ulaval.glo4002.trading.application.report.quarterly.StockMarketReturnDomainAssembler;
import ca.ulaval.glo4002.trading.application.transaction.TransactionDTO;
import ca.ulaval.glo4002.trading.application.transaction.TransactionDomainAssembler;
import ca.ulaval.glo4002.trading.domain.commons.Period;
import ca.ulaval.glo4002.trading.domain.report.historic.HistoricReport;
import ca.ulaval.glo4002.trading.domain.report.stockmarketreturn.StockMarketReturnReport;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class ReportDomainAssembler {

    private final TransactionDomainAssembler transactionDomainAssembler;
    private final StockMarketReturnDomainAssembler stockMarketReturnDomainAssembler;

    public ReportDomainAssembler() {
        this.transactionDomainAssembler = new TransactionDomainAssembler();
        this.stockMarketReturnDomainAssembler = new StockMarketReturnDomainAssembler();
    }

    public DailyReportDTO toDailyReportDTO(HistoricReport historicReport) {
        DailyReportDTO dailyReportDTO = new DailyReportDTO();
        dailyReportDTO.setDate(historicReport.getPeriod().getEnding());
        dailyReportDTO.setBalance(historicReport.getBalance());
        dailyReportDTO.setPortfolioValue(historicReport.getPortfolioValue());
        List<TransactionDTO> transactionDTOs = historicReport.getTransactions().stream()
                .map(transactionDomainAssembler::from).collect(Collectors.toList());
        dailyReportDTO.setTransactionDTOs(transactionDTOs);
        dailyReportDTO.setDividendPayments(historicReport.getStocks());
        return dailyReportDTO;
    }

    public QuarterlyReportDTO toQuarterlyReportDTO(StockMarketReturnReport stockMarketReturnReport) {
        QuarterlyReportDTO quarterlyReportDTO = new QuarterlyReportDTO();
        Period period = stockMarketReturnReport.getPeriod();
        LocalDateTime ending = period.getEnding();
        Quarter quarter = new Quarter(ending);
        quarterlyReportDTO.setQuarter(quarter);
        List<StockMarketReturnDTO> stocksAccountDTOs = stockMarketReturnReport.getStockMarketReturns().stream()
                .map(stockMarketReturnDomainAssembler::from).collect(Collectors.toList());
        quarterlyReportDTO.setStocksAccountDTOs(stocksAccountDTOs);
        return quarterlyReportDTO;
    }

}
