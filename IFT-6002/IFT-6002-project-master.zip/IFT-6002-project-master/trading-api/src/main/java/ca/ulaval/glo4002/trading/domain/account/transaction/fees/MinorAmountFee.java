package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class MinorAmountFee implements Fee {

    private static final float MINOR_AMOUNT_RATE = 0f;

    @Override
    public Money calculate(long quantity, Money amount) {
        return amount.multiply(MINOR_AMOUNT_RATE);
    }

}
