package ca.ulaval.glo4002.trading.domain.account.transaction;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.transaction.fees.FeeFactory;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.stock.StockId;

import java.time.LocalDateTime;

public class TransactionFactory {

    private FeeFactory feeFactory;

    public TransactionFactory() {
        this(ServiceLocator.resolve(FeeFactory.class));
    }

    TransactionFactory(FeeFactory feeFactory) {
        this.feeFactory = feeFactory;
    }

    public Transaction create(TransactionNumber referencedTransactionNumber, StockId stockId, Money price,
                              long quantity, LocalDateTime date, TransactionType type) {
        Money subTotal = price.multiply(quantity);
        Money fees = feeFactory.create(quantity, subTotal);
        return new Transaction(referencedTransactionNumber, stockId, price, quantity, date, type, subTotal, fees);
    }

}
