package ca.ulaval.glo4002.trading.infrastructure.account.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.List;

@Entity
public class PersistedBalance extends PersistedBaseEntity {

    @OneToMany(cascade = CascadeType.ALL)
    private List<PersistedMoney> credits;

    public List<PersistedMoney> getCredits() {
        return credits;
    }

    public void setCredits(List<PersistedMoney> credits) {
        this.credits = credits;
    }

}
