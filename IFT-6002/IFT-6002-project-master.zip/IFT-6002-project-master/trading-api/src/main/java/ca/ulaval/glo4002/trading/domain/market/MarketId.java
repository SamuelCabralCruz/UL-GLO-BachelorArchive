package ca.ulaval.glo4002.trading.domain.market;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;

public class MarketId extends ValueObject {

    private String value;

    public MarketId(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
