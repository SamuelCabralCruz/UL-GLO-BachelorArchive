package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.dividend.Dividend;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.account.investor.Investor;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorType;
import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.NotEnoughCreditsBuyException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.NotEnoughCreditsSellException;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.Period;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.NotEnoughCreditsException;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.stock.StockId;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;


public class Account {

    private AccountNumber accountNumber;
    private Investor investor;
    private Wallet wallet;
    private BalanceHistory balanceHistory;
    private List<DividendPayment> dividendPayments;

    public Account() {
        // For hibernate
    }

    public Account(AccountNumber accountNumber, InvestorId investorId, Balance initialBalance) {
        this.accountNumber = accountNumber;
        this.investor = new Investor(investorId);
        this.wallet = new Wallet();
        this.balanceHistory = new BalanceHistory(initialBalance);
        this.dividendPayments = new ArrayList<>();
    }

    public AccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(AccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Investor getInvestor() {
        return investor;
    }

    public void setInvestor(Investor investor) {
        this.investor = investor;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public void setWallet(Wallet wallet) {
        this.wallet = wallet;
    }

    public BalanceHistory getBalanceHistory() {
        return balanceHistory;
    }

    public void setBalanceHistory(BalanceHistory balanceHistory) {
        this.balanceHistory = balanceHistory;
    }

    public List<DividendPayment> getDividendPayments() {
        return dividendPayments;
    }

    public void setDividendPayments(List<DividendPayment> dividendPayments) {
        this.dividendPayments = dividendPayments;
    }

    public InvestorId getInvestorId() {
        return investor.getId();
    }

    public InvestorType getInvestorType() {
        return investor.getType();
    }

    public List<String> getFocusAreas() {
        return investor.getFocusAreas();
    }

    public Transaction getTransaction(TransactionNumber transactionNumber) {
        return wallet.getTransaction(transactionNumber);
    }

    public void buy(Transaction transactionBuy) {
        TransactionNumber transactionNumber = transactionBuy.getTransactionNumber();
        Money total = transactionBuy.getTotal();
        checkIfEnoughCreditsPurchase(transactionNumber, total);
        LocalDateTime transactionDate = transactionBuy.getDate();
        removeCredits(transactionDate, total);
        wallet.addPurchaseTransaction(transactionBuy);
    }

    private void checkIfEnoughCreditsPurchase(TransactionNumber transactionNumber, Money total) {
        try {
            checkIfEnoughCredits(total);
        } catch (NotEnoughCreditsException e) {
            throw new NotEnoughCreditsBuyException(transactionNumber);
        }
    }

    private void checkIfEnoughCredits(Money transactionCredits) throws NotEnoughCreditsException {
        Currency transactionCurrency = transactionCredits.getCurrency();
        Money accountCredits = getBalance().getCredits(transactionCurrency);
        Money expectedBalanceAfterTransaction = accountCredits.subtract(transactionCredits);
        if (expectedBalanceAfterTransaction.isNegativeAmount()) {
            throw new NotEnoughCreditsException();
        }
    }

    public void sell(Transaction transactionSell) {
        Transaction transactionBuy = wallet.getPurchaseTransaction(transactionSell);
        wallet.checkIfEnoughStocksToProceedSale(transactionBuy, transactionSell);
        Money total = transactionSell.getTotal();
        if (total.isNegativeAmount()) {
            handleNegativeSale(transactionSell, total);
        } else {
            handlePositiveSale(transactionSell, total);
        }
        wallet.addSaleTransaction(transactionBuy, transactionSell);
    }

    private void handleNegativeSale(Transaction transactionSell, Money total) {
        Money negatedTotal = total.negate();
        TransactionNumber transactionNumber = transactionSell.getTransactionNumber();
        checkIfEnoughCreditsSale(transactionNumber, negatedTotal);
        LocalDateTime transactionDate = transactionSell.getDate();
        removeCredits(transactionDate, negatedTotal);
    }

    private void handlePositiveSale(Transaction transactionSell, Money total) {
        LocalDateTime transactionDate = transactionSell.getDate();
        addCredits(transactionDate, total);
    }

    private void checkIfEnoughCreditsSale(TransactionNumber transactionNumber, Money total) {
        try {
            checkIfEnoughCredits(total);
        } catch (NotEnoughCreditsException e) {
            throw new NotEnoughCreditsSellException(transactionNumber);
        }
    }

    private void addCredits(LocalDateTime date, Money money) {
        balanceHistory.addCredits(date, money);
    }

    private void removeCredits(LocalDateTime date, Money money) {
        balanceHistory.removeCredits(date, money);
    }

    public Balance getBalance() {
        return balanceHistory.getBalance();
    }

    public Balance getBalanceAsOf(LocalDateTime date) {
        return balanceHistory.getBalance(date);
    }

    public List<Transaction> getTransactionsOver(Period period) {
        return wallet.getTransactionsOver(period);
    }

    public List<InvestmentPosition> getInvestmentPositionsAsOf(LocalDateTime date) {
        return wallet.getInvestmentPositionsAsOf(date);
    }

    public List<InvestmentPosition> getInvestmentPositionsOver(Period period) {
        return wallet.getInvestmentPositionsOver(period);
    }

    public void applyDividend(Dividend dividend) {
        List<InvestmentPosition> investmentPositions = getInvestmentPositionsAsOf(dividend.getDate());
        List<InvestmentPosition> filtered = filterInvestmentPositionsByStockId(dividend.getStockId(), investmentPositions);
        filtered.forEach(investmentPosition -> convertDividendToPayment(dividend, investmentPosition));
    }

    private List<InvestmentPosition> filterInvestmentPositionsByStockId(StockId stockId, List<InvestmentPosition> investmentPositions) {
        Predicate<InvestmentPosition> predicate = investmentPosition -> investmentPosition.getStockId().equals(stockId);
        return investmentPositions.stream().filter(predicate).collect(Collectors.toList());
    }

    private void convertDividendToPayment(Dividend dividend, InvestmentPosition investmentPosition) {
        DividendPayment dividendPayment = dividend.convertToPayment(investmentPosition);
        addCredits(dividendPayment.getDate(), dividendPayment.getValue());
        dividendPayments.add(dividendPayment);
    }

    public List<DividendPayment> getDividendPaymentsOver(Period period) {
        Predicate<DividendPayment> predicate = dividendPayment -> period.contains(dividendPayment.getDate());
        return dividendPayments.stream().filter(predicate).collect(Collectors.toList());
    }

}
