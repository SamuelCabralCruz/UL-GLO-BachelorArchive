package ca.ulaval.glo4002.trading.domain.report.historic;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendPayment;
import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.Period;

import java.util.List;

public class HistoricReport {

    private final Period period;
    private final Balance balance;
    private final Money portfolioValue;
    private final List<Transaction> transactions;
    private final List<DividendPayment> stocks;

    public HistoricReport(Period period, Balance balance, Money portfolioValue, List<Transaction> transactions, List<DividendPayment> stocks) {
        this.period = period;
        this.balance = balance;
        this.portfolioValue = portfolioValue;
        this.transactions = transactions;
        this.stocks = stocks;
    }

    public Period getPeriod() {
        return period;
    }

    public Balance getBalance() {
        return balance;
    }

    public Money getPortfolioValue() {
        return portfolioValue;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public List<DividendPayment> getStocks() {
        return stocks;
    }

}
