package ca.ulaval.glo4002.trading.domain.commons.exceptions;

public class TradingApiException extends RuntimeException {

    public TradingApiException() {
    }

    public TradingApiException(String message) {
        super(message);
    }

}
