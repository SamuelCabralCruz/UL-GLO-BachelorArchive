package ca.ulaval.glo4002.trading.domain.commons.exceptions;

class DomainException extends Exception {

}
