package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

class NotEnoughCreditsException extends RejectedTransactionException {

    NotEnoughCreditsException(TransactionNumber transactionNumber) {
        super(transactionNumber);
    }

}
