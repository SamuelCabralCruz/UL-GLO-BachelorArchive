package ca.ulaval.glo4002.trading.domain.stock;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;
import ca.ulaval.glo4002.trading.domain.market.MarketId;

public class StockId extends ValueObject {

    private MarketId market;
    private Symbol symbol;

    public StockId(String market, String symbol) {
        this.market = new MarketId(market);
        this.symbol = new Symbol(symbol);
    }

    public MarketId getMarket() {
        return market;
    }

    public Symbol getSymbol() {
        return symbol;
    }
}
