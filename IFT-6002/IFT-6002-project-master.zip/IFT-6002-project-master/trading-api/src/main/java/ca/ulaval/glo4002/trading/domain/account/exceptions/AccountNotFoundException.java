package ca.ulaval.glo4002.trading.domain.account.exceptions;

import ca.ulaval.glo4002.trading.domain.account.AccountNumber;

public class AccountNotFoundException extends AccountException {

    private final AccountNumber accountNumber;

    public AccountNotFoundException(AccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public AccountNumber getAccountNumber() {
        return accountNumber;
    }

}
