package ca.ulaval.glo4002.trading.application.transaction;

import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;

public class TransactionDomainAssembler {

    public TransactionDTO from(Transaction transaction) {
        TransactionDTO transactionDTO = new TransactionDTO();
        transactionDTO.setTransactionNumber(transaction.getTransactionNumber());
        transactionDTO.setType(transaction.getType());
        transactionDTO.setDate(transaction.getDate());
        transactionDTO.setFees(transaction.getFees());
        transactionDTO.setStockId(transaction.getStockId());
        transactionDTO.setPrice(transaction.getPrice());
        transactionDTO.setReferencedTransactionNumber(transaction.getReferencedTransactionNumber());
        transactionDTO.setQuantity(transaction.getQuantity());
        return transactionDTO;
    }

}
