package ca.ulaval.glo4002.trading.rest.report.parameters;

import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportInvalidYearException;

import java.time.DateTimeException;
import java.time.Year;

public class QueryYear {

    private static final int MIN_YEAR = 2015;
    private static final int MAX_YEAR = 2018;

    private Year year;

    public QueryYear(String value) {
        if (value.isEmpty()) {
            this.year = Year.now();
        } else {
            this.year = parseYear(value);
        }
    }

    private Year parseYear(String yearValue) {
        try {
            int yearNumber = Integer.parseInt(yearValue);
            checkIfValidYear(yearNumber);
            return Year.of(yearNumber);
        } catch (NumberFormatException | DateTimeException e) {
            throw new ReportInvalidYearException();
        }
    }

    private void checkIfValidYear(int yearNumber) {
        if (isInvalidYear(yearNumber)) {
            throw new ReportInvalidYearException();
        }
    }

    private boolean isInvalidYear(int yearNumber) {
        return isFutureYear(yearNumber) || isOutOfRangeYear(yearNumber);
    }

    private boolean isFutureYear(int yearNumber) {
        return yearNumber > Year.now().getValue();
    }

    private boolean isOutOfRangeYear(int yearNumber) {
        return yearNumber < MIN_YEAR || yearNumber > MAX_YEAR;
    }

    public Year getValue() {
        return year;
    }

}
