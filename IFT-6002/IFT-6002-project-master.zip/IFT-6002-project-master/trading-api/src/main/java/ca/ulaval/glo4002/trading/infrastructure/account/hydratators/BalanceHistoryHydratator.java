package ca.ulaval.glo4002.trading.infrastructure.account.hydratators;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.BalanceHistory;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedBalance;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedBalanceHistory;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class BalanceHistoryHydratator {

    private BalanceHydratator balanceHydratator;

    public BalanceHistoryHydratator() {
        this.balanceHydratator = new BalanceHydratator();
    }

    PersistedBalanceHistory dehydrate(BalanceHistory balanceHistory) {
        PersistedBalanceHistory persistedBalanceHistory = new PersistedBalanceHistory();
        Map<String, PersistedBalance> persistedBalanceHistoryMap = new HashMap<>();
        for (Map.Entry<LocalDateTime, Balance> entry : balanceHistory.getHistory().entrySet()) {
            String key = entry.getKey().toString();
            PersistedBalance value = balanceHydratator.dehydrate(entry.getValue());
            persistedBalanceHistoryMap.put(key, value);
        }
        persistedBalanceHistory.setHistory(persistedBalanceHistoryMap);
        return persistedBalanceHistory;
    }

    BalanceHistory hydrate(PersistedBalanceHistory persistedBalanceHistory) {
        BalanceHistory balanceHistory = new BalanceHistory();
        NavigableMap<LocalDateTime, Balance> balanceHistoryMap = new TreeMap<>();
        for (Map.Entry<String, PersistedBalance> entry : persistedBalanceHistory.getHistory().entrySet()) {
            LocalDateTime key = LocalDateTime.parse(entry.getKey());
            PersistedBalance value = entry.getValue();
            balanceHistoryMap.put(key, balanceHydratator.hydrate(value));
        }
        balanceHistory.setHistory(balanceHistoryMap);
        return balanceHistory;
    }

    public PersistedBalanceHistory update(BalanceHistory balanceHistory, PersistedBalanceHistory persistedBalanceHistory) {
        Map<String, PersistedBalance> persistedHistory = new HashMap<>();
        for (Map.Entry<LocalDateTime, Balance> historyEntry : balanceHistory.getHistory().entrySet()) {
            String dateString = historyEntry.getKey().toString();
            PersistedBalance persistedBalance = balanceHydratator.dehydrate(historyEntry.getValue());
            persistedHistory.put(dateString, persistedBalance);
        }
        persistedBalanceHistory.setHistory(persistedHistory);
        return persistedBalanceHistory;
    }
}
