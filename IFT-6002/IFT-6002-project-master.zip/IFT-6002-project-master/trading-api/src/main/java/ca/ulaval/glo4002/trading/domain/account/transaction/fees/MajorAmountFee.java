package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class MajorAmountFee implements Fee {

    private static final float MAJOR_AMOUNT_RATE = 0.03f;

    @Override
    public Money calculate(long quantity, Money amount) {
        return amount.multiply(MAJOR_AMOUNT_RATE);
    }

}
