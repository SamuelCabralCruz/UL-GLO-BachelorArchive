package ca.ulaval.glo4002.trading.infrastructure.account.entities;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class PersistedMoney extends PersistedBaseEntity {

    @Column
    private String currency;

    @Column
    private Double amount;

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
