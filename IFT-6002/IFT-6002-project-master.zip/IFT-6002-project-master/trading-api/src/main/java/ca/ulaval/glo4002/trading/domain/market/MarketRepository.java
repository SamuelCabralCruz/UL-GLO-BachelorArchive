package ca.ulaval.glo4002.trading.domain.market;

public interface MarketRepository {

    Market findByMarketId(MarketId marketId);

}
