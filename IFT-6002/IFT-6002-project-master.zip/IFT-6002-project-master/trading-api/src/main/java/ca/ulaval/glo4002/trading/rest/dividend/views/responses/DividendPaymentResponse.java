package ca.ulaval.glo4002.trading.rest.dividend.views.responses;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.market.MarketId;
import ca.ulaval.glo4002.trading.domain.stock.Symbol;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"market", "symbol", "marketprice", "dividends"})
public class DividendPaymentResponse {

    private MarketId market;
    private Symbol symbol;
    private Money marketprice;
    private Money dividends;

    public MarketId getMarket() {
        return market;
    }

    public void setMarket(MarketId market) {
        this.market = market;
    }

    public Symbol getSymbol() {
        return symbol;
    }

    public void setSymbol(Symbol symbol) {
        this.symbol = symbol;
    }

    public Money getMarketprice() {
        return marketprice;
    }

    public void setMarketprice(Money marketprice) {
        this.marketprice = marketprice;
    }

    public Money getDividends() {
        return dividends;
    }

    public void setDividends(Money dividends) {
        this.dividends = dividends;
    }

}
