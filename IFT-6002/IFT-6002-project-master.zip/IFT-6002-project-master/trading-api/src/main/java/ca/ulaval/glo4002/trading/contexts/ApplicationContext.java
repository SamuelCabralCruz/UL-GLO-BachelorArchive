package ca.ulaval.glo4002.trading.contexts;

public interface ApplicationContext {

    void execute();

}
