package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.pending;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.TransactionException;

public class PendingTransactionException extends TransactionException {

    private final TransactionNumber transactionNumber;

    PendingTransactionException(TransactionNumber transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public TransactionNumber getTransactionNumber() {
        return transactionNumber;
    }

}
