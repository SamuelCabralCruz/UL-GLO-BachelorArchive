package ca.ulaval.glo4002.trading.domain.currency.exceptions;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;

public class CurrencyException extends TradingApiException {
}
