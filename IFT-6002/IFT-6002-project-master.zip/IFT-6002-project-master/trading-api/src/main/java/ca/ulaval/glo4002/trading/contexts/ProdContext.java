package ca.ulaval.glo4002.trading.contexts;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.account.AccountApplicationService;
import ca.ulaval.glo4002.trading.application.account.AccountDomainAssembler;
import ca.ulaval.glo4002.trading.application.dividend.DividendApplicationService;
import ca.ulaval.glo4002.trading.application.report.ReportApplicationService;
import ca.ulaval.glo4002.trading.application.report.ReportDomainAssembler;
import ca.ulaval.glo4002.trading.application.report.quarterly.StockMarketReturnDomainAssembler;
import ca.ulaval.glo4002.trading.application.transaction.TransactionApplicationService;
import ca.ulaval.glo4002.trading.application.transaction.TransactionDomainAssembler;
import ca.ulaval.glo4002.trading.domain.account.AccountFactory;
import ca.ulaval.glo4002.trading.domain.account.AccountRepository;
import ca.ulaval.glo4002.trading.domain.account.dividend.DividendFactory;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionFactory;
import ca.ulaval.glo4002.trading.domain.account.transaction.fees.FeeFactory;
import ca.ulaval.glo4002.trading.domain.commons.PeriodFactory;
import ca.ulaval.glo4002.trading.domain.currency.CurrencyExchanger;
import ca.ulaval.glo4002.trading.domain.currency.ExchangeRateRepository;
import ca.ulaval.glo4002.trading.domain.market.MarketFactory;
import ca.ulaval.glo4002.trading.domain.market.MarketRepository;
import ca.ulaval.glo4002.trading.domain.report.Reporter;
import ca.ulaval.glo4002.trading.domain.stock.InstantStockFactory;
import ca.ulaval.glo4002.trading.domain.stock.StockRepository;
import ca.ulaval.glo4002.trading.infrastructure.account.HibernateAccountRepository;
import ca.ulaval.glo4002.trading.infrastructure.currency.InMemoryExchangeRateRepository;
import ca.ulaval.glo4002.trading.infrastructure.market.RestApiMarketRepository;
import ca.ulaval.glo4002.trading.infrastructure.stock.RestApiStockRepository;

public class ProdContext implements ApplicationContext {

    @Override
    public void execute() {
        registerAllClasses();
    }

    private void registerAllClasses() {
        registerFactories();
        registerRepositories();
        registerDomainAssemblers();
        registerServices();
    }

    private void registerFactories() {
        ServiceLocator.register(PeriodFactory.class, new PeriodFactory());
        ServiceLocator.register(MarketFactory.class, new MarketFactory());
        ServiceLocator.register(FeeFactory.class, new FeeFactory());
        ServiceLocator.register(AccountFactory.class, new AccountFactory());
        ServiceLocator.register(TransactionFactory.class, new TransactionFactory());
        ServiceLocator.register(DividendFactory.class, new DividendFactory());
        ServiceLocator.register(InstantStockFactory.class, new InstantStockFactory());
    }

    private void registerRepositories() {
        ServiceLocator.register(AccountRepository.class, new HibernateAccountRepository());
        ServiceLocator.register(StockRepository.class, new RestApiStockRepository());
        ServiceLocator.register(MarketRepository.class, new RestApiMarketRepository());
        ServiceLocator.register(ExchangeRateRepository.class, new InMemoryExchangeRateRepository());
    }

    private void registerDomainAssemblers() {
        ServiceLocator.register(StockMarketReturnDomainAssembler.class, new StockMarketReturnDomainAssembler());
        ServiceLocator.register(AccountDomainAssembler.class, new AccountDomainAssembler());
        ServiceLocator.register(TransactionDomainAssembler.class, new TransactionDomainAssembler());
        ServiceLocator.register(ReportDomainAssembler.class, new ReportDomainAssembler());
    }

    private void registerServices() {
        ServiceLocator.register(CurrencyExchanger.class, new CurrencyExchanger());
        ServiceLocator.register(Reporter.class, new Reporter());
        ServiceLocator.register(AccountApplicationService.class, new AccountApplicationService());
        ServiceLocator.register(TransactionApplicationService.class, new TransactionApplicationService());
        ServiceLocator.register(DividendApplicationService.class, new DividendApplicationService());
        ServiceLocator.register(ReportApplicationService.class, new ReportApplicationService());
    }

}
