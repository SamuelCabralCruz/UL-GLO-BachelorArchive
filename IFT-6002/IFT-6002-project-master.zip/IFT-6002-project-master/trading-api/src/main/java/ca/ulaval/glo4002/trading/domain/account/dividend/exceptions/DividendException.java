package ca.ulaval.glo4002.trading.domain.account.dividend.exceptions;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;

public class DividendException extends TradingApiException {
}
