package ca.ulaval.glo4002.trading.infrastructure.account.hydratators;

import ca.ulaval.glo4002.trading.domain.commons.Amount;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedMoney;

public class MoneyHydratator {

    PersistedMoney dehydrate(Money money) {
        PersistedMoney persistedMoney = new PersistedMoney();
        persistedMoney.setCurrency(money.getCurrency().toString());
        persistedMoney.setAmount(money.doubleValue());
        return persistedMoney;
    }

    Money hydrate(PersistedMoney persistedMoney) {
        double amountValue = persistedMoney.getAmount();
        Amount amount = new Amount(amountValue);
        String currencyValue = persistedMoney.getCurrency();
        Currency currency = new Currency(currencyValue);
        return new Money(amount, currency);
    }

}
