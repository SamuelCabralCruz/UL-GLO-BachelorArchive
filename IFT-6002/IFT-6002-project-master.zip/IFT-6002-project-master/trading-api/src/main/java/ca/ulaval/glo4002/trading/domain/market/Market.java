package ca.ulaval.glo4002.trading.domain.market;

import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.pending.MarketClosedException;
import ca.ulaval.glo4002.trading.domain.commons.Period;

import java.time.*;
import java.util.List;
import java.util.function.Predicate;

public class Market {

    private String marketSymbol;
    private List<Period> openHours;
    private ZoneOffset zoneOffset;

    public Market(String marketSymbol, ZoneOffset zoneOffset, List<Period> openHours) {
        this.marketSymbol = marketSymbol;
        this.openHours = openHours;
        this.zoneOffset = zoneOffset;
    }

    public void checkIfMarketIsClosed(Transaction transaction) {
        LocalDateTime date = transaction.getDate();
        OffsetDateTime transactionDate = date.atOffset(ZoneOffset.UTC);
        OffsetDateTime transactionAtMarketTime = transactionDate.withOffsetSameInstant(zoneOffset);
        if(isMarketClose(transactionAtMarketTime)){
            throw new MarketClosedException(marketSymbol, transaction.getTransactionNumber());
        }
    }

    private boolean isMarketClose(OffsetDateTime transactionAtMarketTime) {
        return isWeekEnd(transactionAtMarketTime) || isClosedHours(transactionAtMarketTime);
    }

    private boolean isWeekEnd(OffsetDateTime date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        return (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY);
    }

    private boolean isClosedHours(OffsetDateTime transactionAtMarketTime) {
        LocalTime localTime = transactionAtMarketTime.toLocalTime();
        Predicate<Period> predicate = p -> p.contains(LocalDateTime.of(LocalDate.now(), localTime));
        return openHours.stream().noneMatch(predicate);
    }

}
