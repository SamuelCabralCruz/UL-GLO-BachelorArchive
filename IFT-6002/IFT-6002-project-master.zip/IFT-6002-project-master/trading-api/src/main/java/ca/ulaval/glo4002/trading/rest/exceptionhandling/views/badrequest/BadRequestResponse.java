package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionResponse;

import javax.ws.rs.core.Response.Status;

abstract class BadRequestResponse implements ExceptionResponse {

    @Override
    public Status getStatus() {
        return Status.BAD_REQUEST;
    }

}
