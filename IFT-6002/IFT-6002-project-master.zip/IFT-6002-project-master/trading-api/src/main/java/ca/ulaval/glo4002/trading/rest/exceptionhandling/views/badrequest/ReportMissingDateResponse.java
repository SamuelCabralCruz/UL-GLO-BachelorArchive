package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class ReportMissingDateResponse extends BadRequestResponse {

    private static final String ERROR = "MISSING_DATE";
    private static final String DESCRIPTION = "date is missing";

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, DESCRIPTION);
    }

}
