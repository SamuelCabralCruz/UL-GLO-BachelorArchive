package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountAlreadyOpenException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class AccountAlreadyOpenResponse extends BadRequestResponse {

    private static final String ERROR = "ACCOUNT_ALREADY_OPEN";
    private static final String DESCRIPTION = "account already open for investor %s";
    private final InvestorId investorId;

    public AccountAlreadyOpenResponse(AccountAlreadyOpenException e) {
        this.investorId = e.getInvestorId();
    }

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, String.format(DESCRIPTION, investorId.getValue()));
    }

}
