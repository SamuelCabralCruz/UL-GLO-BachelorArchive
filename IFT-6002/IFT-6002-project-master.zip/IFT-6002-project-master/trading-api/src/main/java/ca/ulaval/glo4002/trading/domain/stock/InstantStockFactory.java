package ca.ulaval.glo4002.trading.domain.stock;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class InstantStockFactory {

    private static final double COMMON_DIVIDEND_RATE = 0.00d;
    private static final double PREFERRED_DIVIDEND_RATE = 0.10d;

    public Stock create(StockId stockId, Money price, StockType type) {
        double dividendRate = type == StockType.COMMON ? COMMON_DIVIDEND_RATE : PREFERRED_DIVIDEND_RATE;
        return new Stock(stockId, price, type, dividendRate);
    }

}
