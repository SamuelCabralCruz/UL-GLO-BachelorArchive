package ca.ulaval.glo4002.trading.domain.account.transaction;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.stock.StockId;

import java.time.LocalDateTime;

public class Transaction {

    private TransactionNumber transactionNumber;
    private TransactionNumber referencedTransactionNumber;
    private StockId stockId;
    private long quantity;
    private LocalDateTime date;
    private TransactionType type;
    private Money price;
    private Money subTotal;
    private Money fees;

    public Transaction() {
        // for hibernate
    }

    public Transaction(TransactionNumber referencedTransactionNumber, StockId stockId, Money price,
                       long quantity, LocalDateTime date, TransactionType type, Money subTotal, Money fees) {
        this.transactionNumber = new TransactionNumber();
        this.referencedTransactionNumber = referencedTransactionNumber;
        this.stockId = stockId;
        this.price = price;
        this.quantity = quantity;
        this.date = date;
        this.type = type;
        this.subTotal = subTotal;
        this.fees = fees;
    }

    public TransactionNumber getTransactionNumber() {
        return transactionNumber;
    }

    public void setTransactionNumber(TransactionNumber transactionNumber) {
        this.transactionNumber = transactionNumber;
    }

    public TransactionNumber getReferencedTransactionNumber() {
        return referencedTransactionNumber;
    }

    public void setReferencedTransactionNumber(TransactionNumber referencedTransactionNumber) {
        this.referencedTransactionNumber = referencedTransactionNumber;
    }

    public StockId getStockId() {
        return stockId;
    }

    public void setStockId(StockId stockId) {
        this.stockId = stockId;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public Money getPrice() {
        return price;
    }

    public void setPrice(Money price) {
        this.price = price;
    }

    public Money getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(Money subTotal) {
        this.subTotal = subTotal;
    }

    public Money getFees() {
        return fees;
    }

    public void setFees(Money fees) {
        this.fees = fees;
    }

    public Currency getCurrency() {
        return this.price.getCurrency();
    }

    public Money getTotal() {
        return type == TransactionType.BUY ? subTotal.add(fees) : subTotal.subtract(fees);
    }

}
