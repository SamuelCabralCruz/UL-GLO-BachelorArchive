package ca.ulaval.glo4002.trading.domain.currency;

public interface ExchangeRateRepository {

    boolean containsCurrency(Currency currency);

    double findByCurrencies(Currency from, Currency to);

}
