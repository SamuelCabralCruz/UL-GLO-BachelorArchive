package ca.ulaval.glo4002.trading.infrastructure.account.hydratators;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedBalance;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedMoney;

import java.util.ArrayList;
import java.util.List;

public class BalanceHydratator {

    private MoneyHydratator moneyHydratator;

    BalanceHydratator() {
        this.moneyHydratator = new MoneyHydratator();
    }

    PersistedBalance dehydrate(Balance balance) {
        PersistedBalance persistedBalance = new PersistedBalance();
        List<PersistedMoney> credits = new ArrayList<>();
        for (Money money : balance.getCredits()) {
            credits.add(moneyHydratator.dehydrate(money));
        }
        persistedBalance.setCredits(credits);
        return persistedBalance;
    }

    Balance hydrate(PersistedBalance persistedBalance) {
        List<Money> credits = new ArrayList<>();
        for (PersistedMoney persistedMoney : persistedBalance.getCredits()) {
            credits.add(moneyHydratator.hydrate(persistedMoney));
        }
        return new Balance(credits);
    }
}
