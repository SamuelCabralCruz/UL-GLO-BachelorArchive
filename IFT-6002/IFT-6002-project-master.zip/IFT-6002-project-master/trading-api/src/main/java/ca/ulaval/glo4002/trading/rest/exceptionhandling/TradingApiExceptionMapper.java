package ca.ulaval.glo4002.trading.rest.exceptionhandling;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class TradingApiExceptionMapper implements ExceptionMapper<TradingApiException> {

    private final ExceptionResponseFactory exceptionResponseFactory;

    public TradingApiExceptionMapper() {
        exceptionResponseFactory = new ExceptionResponseFactory();
    }

    @Override
    public Response toResponse(TradingApiException e) {
        ExceptionResponse exceptionResponse = exceptionResponseFactory.createExceptionView(e);
        return Response
                .status(exceptionResponse.getStatus())
                .entity(exceptionResponse.getMessage())
                .type(MediaType.APPLICATION_JSON_TYPE)
                .build();
    }

}
