package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

import java.util.HashSet;
import java.util.Set;

public class CompositeFee implements Fee {

    private Set<Fee> fees = new HashSet<>();

    public void add(Fee fee) {
        fees.add(fee);
    }

    @Override
    public Money calculate(long quantity, Money amount) {
        Money total = new Money(0, amount.getCurrency());
        for (Fee fee : fees) {
            total = total.add(fee.calculate(quantity, amount));
        }
        return total;
    }

}
