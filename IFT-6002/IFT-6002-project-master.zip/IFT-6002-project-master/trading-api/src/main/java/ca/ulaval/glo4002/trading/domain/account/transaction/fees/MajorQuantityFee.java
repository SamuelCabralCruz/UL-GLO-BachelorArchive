package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public class MajorQuantityFee implements Fee {

    private static final float MAJOR_FEE_PER_SHARE = 0.20f;

    @Override
    public Money calculate(long quantity, Money amount) {
        return new Money(quantity * MAJOR_FEE_PER_SHARE, amount.getCurrency());
    }

}
