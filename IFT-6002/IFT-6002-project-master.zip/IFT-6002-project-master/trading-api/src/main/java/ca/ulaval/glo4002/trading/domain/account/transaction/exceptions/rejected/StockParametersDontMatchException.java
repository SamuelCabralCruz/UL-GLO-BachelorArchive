package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

public class StockParametersDontMatchException extends RejectedTransactionException {

    public StockParametersDontMatchException(TransactionNumber transactionNumber) {
        super(transactionNumber);
    }

}
