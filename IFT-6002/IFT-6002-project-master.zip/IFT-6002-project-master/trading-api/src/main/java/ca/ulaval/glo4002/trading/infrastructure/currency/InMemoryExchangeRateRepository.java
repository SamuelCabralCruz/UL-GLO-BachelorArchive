package ca.ulaval.glo4002.trading.infrastructure.currency;

import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.currency.ExchangeRateRepository;
import ca.ulaval.glo4002.trading.domain.currency.exceptions.UnsupportedCurrencyException;

import java.util.HashMap;
import java.util.Map;

public class InMemoryExchangeRateRepository implements ExchangeRateRepository {

    private Map<String, Double> exchangeRates;

    public InMemoryExchangeRateRepository() {
        instantiateExchangeRates();
    }

    private void instantiateExchangeRates() {
        exchangeRates = new HashMap<>();
        exchangeRates.put("CAD", 1.00d);
        exchangeRates.put("USD", 1.31d);
        exchangeRates.put("JPY", 0.01d);
        exchangeRates.put("CHF", 1.45d);
    }

    @Override
    public double findByCurrencies(Currency from, Currency to) {
        return getExchangeRate(from) / getExchangeRate(to);
    }

    private Double getExchangeRate(Currency currency) {
        String currencyValue = currency.getValue();
        Double exchangeRate = exchangeRates.get(currencyValue);
        checkIfValidCurrency(currency, exchangeRate);
        return exchangeRate;
    }

    private void checkIfValidCurrency(Currency currency, Double exchangeRate) {
        if (exchangeRate == null) {
            throw new UnsupportedCurrencyException(currency);
        }
    }

    @Override
    public boolean containsCurrency(Currency currency) {
        return exchangeRates.containsKey(currency.getValue());
    }
}
