package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.exceptions.EmptyCreditsException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidAmountException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidInvestorNameException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.commons.Money;

import java.util.List;

public class AccountFactory {

    public Account create(PersistedId persistedId, InvestorId investorId, String investorName, Balance balance) {
        checkIfInvalidCredits(balance.getCredits());
        String accountNumberString = computeAccountNumber(investorName, persistedId.getValue());
        AccountNumber accountNumber = new AccountNumber(accountNumberString);
        return new Account(accountNumber, investorId, balance);
    }

    private String computeAccountNumber(String investorName, long accountNumber) {
        return String.format("%s-%d", findInitials(investorName), accountNumber);
    }

    private String findInitials(String investorName) {
        try {
            String[] partsOfName = investorName.split(" ");
            String firstInitial = partsOfName[0].substring(0, 1);
            String secondInitial = partsOfName[1].substring(0, 1);
            return String.format("%s%s", firstInitial, secondInitial);
        } catch (IndexOutOfBoundsException e) {
            throw new InvalidInvestorNameException(investorName);
        }
    }

    private void checkIfInvalidCredits(List<Money> credits) {
        checkIfEmptyCredits(credits);
        for (Money credit : credits) {
            checkIfInvalidAmount(credit);
        }
    }

    private void checkIfEmptyCredits(List<Money> credits) {
        if (credits.isEmpty()) {
            throw new EmptyCreditsException();
        }
    }

    private void checkIfInvalidAmount(Money money) {
        if (isInvalidAmount(money)) {
            throw new InvalidAmountException();
        }
    }

    private boolean isInvalidAmount(Money money) {
        return money.isNullAmount() || money.isNegativeAmount();
    }

}
