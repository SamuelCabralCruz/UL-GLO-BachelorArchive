package ca.ulaval.glo4002.trading.application.account;

import ca.ulaval.glo4002.trading.domain.account.Account;

public class AccountDomainAssembler {

    public AccountDTO from(Account account) {
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setAccountNumber(account.getAccountNumber());
        accountDTO.setInvestorId(account.getInvestorId());
        accountDTO.setInvestorType(account.getInvestorType());
        accountDTO.setFocusAreas(account.getFocusAreas());
        accountDTO.setBalance(account.getBalance());
        return accountDTO;
    }

}
