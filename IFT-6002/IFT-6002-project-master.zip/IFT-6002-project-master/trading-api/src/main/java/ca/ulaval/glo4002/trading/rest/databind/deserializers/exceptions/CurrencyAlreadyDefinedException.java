package ca.ulaval.glo4002.trading.rest.databind.deserializers.exceptions;

import ca.ulaval.glo4002.trading.domain.currency.Currency;

import javax.ws.rs.core.Response;

public class CurrencyAlreadyDefinedException extends DeserializationException {

    private static final String ERROR = "CURRENCY_ALREADY_DEFINED";
    private static final String DESCRIPTION = "currency '%s' already defined";

    public CurrencyAlreadyDefinedException(Currency currency) {
        super(Response.Status.BAD_REQUEST, ERROR, String.format(DESCRIPTION, currency.getValue()));
    }

}
