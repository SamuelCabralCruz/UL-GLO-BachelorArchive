package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid;

import ca.ulaval.glo4002.trading.domain.market.MarketId;

public class MarketNotFoundException extends InvalidTransactionException {

    private final MarketId marketId;

    public MarketNotFoundException(MarketId marketId) {
        this.marketId = marketId;
    }

    public MarketId getMarketId() {
        return marketId;
    }

}
