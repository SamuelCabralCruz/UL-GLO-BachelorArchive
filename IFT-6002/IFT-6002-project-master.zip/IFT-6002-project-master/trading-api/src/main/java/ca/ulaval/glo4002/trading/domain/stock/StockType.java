package ca.ulaval.glo4002.trading.domain.stock;

public enum StockType {COMMON, PREFERRED}
