package ca.ulaval.glo4002.trading.infrastructure.account.hydratators;

import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionType;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.infrastructure.account.entities.PersistedTransaction;

import java.time.LocalDateTime;

class TransactionHydratator {

    private StockIdHydratator stockIdHydratator;
    private MoneyHydratator moneyHydratator;

    TransactionHydratator() {
        this.stockIdHydratator = new StockIdHydratator();
        this.moneyHydratator = new MoneyHydratator();
    }

    PersistedTransaction dehydrate(Transaction transaction) {
        PersistedTransaction persistedTransaction = new PersistedTransaction();
        persistedTransaction.setDate(transaction.getDate().toString());
        persistedTransaction.setPrice(moneyHydratator.dehydrate(transaction.getPrice()));
        persistedTransaction.setQuantity(transaction.getQuantity());
        if (transaction.getReferencedTransactionNumber() != null) {
            persistedTransaction.setReferencedTransactionNumber(transaction.getReferencedTransactionNumber().toString());
        }
        persistedTransaction.setStockId(stockIdHydratator.dehydrate(transaction.getStockId()));
        persistedTransaction.setSubTotal(moneyHydratator.dehydrate(transaction.getSubTotal()));
        persistedTransaction.setFees(moneyHydratator.dehydrate(transaction.getFees()));
        persistedTransaction.setType(transaction.getType().toString());
        persistedTransaction.setTransactionNumber(transaction.getTransactionNumber().toString());
        return persistedTransaction;
    }

    Transaction hydrate(PersistedTransaction persistedTransaction) {
        Transaction transaction = new Transaction();
        transaction.setDate(LocalDateTime.parse(persistedTransaction.getDate()));
        StockId stockId = stockIdHydratator.hydrate(persistedTransaction.getStockId());
        transaction.setPrice(moneyHydratator.hydrate(persistedTransaction.getPrice()));
        transaction.setQuantity(persistedTransaction.getQuantity());
        if (persistedTransaction.getReferencedTransactionNumber() != null) {
            transaction.setReferencedTransactionNumber(new TransactionNumber(persistedTransaction.getReferencedTransactionNumber()));
        }
        transaction.setStockId(stockId);
        transaction.setTransactionNumber(new TransactionNumber(persistedTransaction.getTransactionNumber()));
        transaction.setType(TransactionType.valueOf(persistedTransaction.getType()));
        transaction.setSubTotal(moneyHydratator.hydrate(persistedTransaction.getSubTotal()));
        transaction.setFees(moneyHydratator.hydrate(persistedTransaction.getFees()));
        return transaction;
    }

}
