package ca.ulaval.glo4002.trading.rest.report.views.responses;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.market.MarketId;
import ca.ulaval.glo4002.trading.domain.stock.Symbol;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"market", "symbol", "rateOfReturn", "totalDividends", "quantity"})
public class StockMarketReturnResponse {

    private MarketId market;
    private Symbol symbol;
    private float rateOfReturn;
    private Money totalDividends;
    private long quantity;

    public MarketId getMarket() {
        return market;
    }

    public void setMarket(MarketId market) {
        this.market = market;
    }

    public Symbol getSymbol() {
        return symbol;
    }

    public void setSymbol(Symbol symbol) {
        this.symbol = symbol;
    }

    public float getRateOfReturn() {
        return rateOfReturn;
    }

    public void setRateOfReturn(float rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
    }

    public Money getTotalDividends() {
        return totalDividends;
    }

    public void setTotalDividends(Money totalDividends) {
        this.totalDividends = totalDividends;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

}
