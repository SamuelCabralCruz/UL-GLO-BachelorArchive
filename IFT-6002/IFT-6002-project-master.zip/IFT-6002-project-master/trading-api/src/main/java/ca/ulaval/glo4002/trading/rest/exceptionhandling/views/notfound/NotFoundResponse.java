package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.notfound;

import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionResponse;

import javax.ws.rs.core.Response;

abstract class NotFoundResponse implements ExceptionResponse {

    @Override
    public Response.Status getStatus() {
        return Response.Status.NOT_FOUND;
    }

}
