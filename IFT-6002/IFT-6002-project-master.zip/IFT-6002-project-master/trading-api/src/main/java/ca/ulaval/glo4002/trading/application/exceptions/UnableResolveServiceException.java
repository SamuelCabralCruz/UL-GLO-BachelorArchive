package ca.ulaval.glo4002.trading.application.exceptions;

public class UnableResolveServiceException extends ServiceLocatorException {

    private static final long serialVersionUID = 1L;

    public UnableResolveServiceException(Class<?> contract) {
        super(String.format("Unable to resolve a service for '%s'.", contract.getCanonicalName()));
    }

}