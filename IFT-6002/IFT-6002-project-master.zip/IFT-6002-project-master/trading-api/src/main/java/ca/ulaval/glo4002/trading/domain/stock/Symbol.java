package ca.ulaval.glo4002.trading.domain.stock;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;

public class Symbol extends ValueObject {

    private String value;

    public Symbol(String symbol) {
        this.value = symbol;
    }

    public String getValue() {
        return value;
    }

}
