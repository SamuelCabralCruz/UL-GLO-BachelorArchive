package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.commons.Money;

import java.time.LocalDateTime;
import java.util.NavigableMap;
import java.util.TreeMap;

public class BalanceHistory {

    private NavigableMap<LocalDateTime, Balance> history = new TreeMap<>();

    public BalanceHistory() {
        // For hibernate
    }

    public BalanceHistory(Balance initialBalance) {
        this();
        history.put(LocalDateTime.MIN, initialBalance);
    }

    public NavigableMap<LocalDateTime, Balance> getHistory() {
        return history;
    }

    public void setHistory(NavigableMap<LocalDateTime, Balance> history) {
        this.history = history;
    }

    public Balance getBalance() {
        return history.lastEntry().getValue();
    }

    public Balance getBalance(LocalDateTime date) {
        return history.floorEntry(date).getValue();
    }

    public void addCredits(LocalDateTime date, Money money) {
        Balance balance = getBalance();
        Balance newBalance = balance.addCredits(money);
        history.put(date, newBalance);
    }

    public void removeCredits(LocalDateTime date, Money money) {
        Balance newBalance = getBalance().removeCredits(money);
        history.put(date, newBalance);
    }

}
