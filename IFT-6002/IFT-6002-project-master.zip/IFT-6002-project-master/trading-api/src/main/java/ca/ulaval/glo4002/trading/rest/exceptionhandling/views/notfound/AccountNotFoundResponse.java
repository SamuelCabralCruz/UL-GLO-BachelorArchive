package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.notfound;

import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountNotFoundException;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class AccountNotFoundResponse extends NotFoundResponse {

    private static final String DESCRIPTION = "account with number %s not found";
    private static final String ERROR = "ACCOUNT_NOT_FOUND";
    private final AccountNumber accountNumber;

    public AccountNotFoundResponse(AccountNotFoundException e) {
        this.accountNumber = e.getAccountNumber();
    }

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, String.format(DESCRIPTION, accountNumber.getValue()));
    }

}
