package ca.ulaval.glo4002.trading.domain.account.exceptions;

public class InvalidAmountException extends AccountException {

}
