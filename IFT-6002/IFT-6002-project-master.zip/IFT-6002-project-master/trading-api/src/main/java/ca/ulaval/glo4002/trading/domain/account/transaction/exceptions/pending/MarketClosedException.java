package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.pending;

import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;

public class MarketClosedException extends PendingTransactionException {

    private final String market;

    public MarketClosedException(String market, TransactionNumber transactionNumber) {
        super(transactionNumber);
        this.market = market;
    }

    public String getMarket() {
        return market;
    }

}
