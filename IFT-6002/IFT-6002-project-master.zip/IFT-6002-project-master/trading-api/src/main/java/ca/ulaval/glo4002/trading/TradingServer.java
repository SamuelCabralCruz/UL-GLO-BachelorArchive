package ca.ulaval.glo4002.trading;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.contexts.ApplicationContext;
import ca.ulaval.glo4002.trading.contexts.ProdContext;
import ca.ulaval.glo4002.trading.rest.databind.JacksonFeature;
import ca.ulaval.glo4002.trading.rest.filters.EntityManagerContextFilter;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

import javax.servlet.DispatcherType;
import java.util.EnumSet;

public class TradingServer implements Runnable {

    private static final int DEFAULT_PORT = 8181;
    private static final ProdContext DEFAULT_CONTEXT = new ProdContext();

    public static void main(String[] args) {
        new TradingServer().run();
    }

    private Server server;

    @Override
    public void run() {
        TradingServer server = new TradingServer();
        server.start();
        server.join();
    }

    public void start() {
        start(DEFAULT_PORT, DEFAULT_CONTEXT, true);
    }

    public void start(int httpPort) {
        start(httpPort, new ProdContext(), true);
    }

    public void start(int httpPort, ApplicationContext context, boolean registerEntityManagerFilter) {
        ServiceLocator.reset();
        context.execute();
        server = new Server(httpPort);
        ServletContextHandler servletContextHandler = new ServletContextHandler(server, "/");
        configureJersey(servletContextHandler, registerEntityManagerFilter);
        try {
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            tryStopServer();
        }
    }

    public void join() {
        try {
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            tryStopServer();
        }
    }

    private void tryStopServer() {
        try {
            server.destroy();
        } catch (Exception e) {
            return;
        }
    }

    public void stop() {
        try {
            server.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configureJersey(ServletContextHandler servletContextHandler, boolean registerEntityManagerFilter) {
        ResourceConfig resourceConfig = new ResourceConfig();
        resourceConfig.packages("ca.ulaval.glo4002.trading.rest");
        resourceConfig.register(JacksonFeature.class);
        ServletContainer container = new ServletContainer(resourceConfig);
        ServletHolder jerseyServletHolder = new ServletHolder(container);
        servletContextHandler.addServlet(jerseyServletHolder, "/*");
        if (registerEntityManagerFilter) {
            servletContextHandler.addFilter(EntityManagerContextFilter.class, "/*", EnumSet.of(DispatcherType.REQUEST));
        }
    }

}
