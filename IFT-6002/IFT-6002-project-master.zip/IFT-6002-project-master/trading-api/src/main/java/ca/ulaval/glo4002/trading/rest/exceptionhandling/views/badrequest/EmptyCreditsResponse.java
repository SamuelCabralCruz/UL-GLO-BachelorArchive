package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class EmptyCreditsResponse extends BadRequestResponse {

    private static final String ERROR = "EMPTY_CREDITS";
    private static final String DESCRIPTION = "an account cannot be opened without credits";

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, DESCRIPTION);
    }

}

