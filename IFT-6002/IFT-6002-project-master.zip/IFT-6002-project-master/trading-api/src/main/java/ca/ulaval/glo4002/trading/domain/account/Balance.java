package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.ValueObject;
import ca.ulaval.glo4002.trading.domain.currency.Currency;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Balance extends ValueObject {

    private Map<Currency, Money> allCredits;

    public Balance(List<Money> allCredits) {
        this.allCredits = new HashMap<>();
        for (Money credits : allCredits) {
            Currency currency = credits.getCurrency();
            this.allCredits.put(currency, credits);
        }
    }

    public List<Money> getCredits() {
        return new ArrayList<>(allCredits.values());
    }

    public Money getCredits(Currency currency) {
        return allCredits.getOrDefault(currency, new Money(0f, currency));
    }

    Balance addCredits(Money money) {
        Currency currency = money.getCurrency();
        Map<Currency, Money> updatedCredits = new HashMap<>(this.allCredits);
        Money updatedAmount = updatedCredits.get(currency).add(money);
        updatedCredits.put(currency, updatedAmount);
        return new Balance(new ArrayList(updatedCredits.values()));
    }

    Balance removeCredits(Money money) {
        Currency currency = money.getCurrency();
        Map<Currency, Money> updatedCredits = new HashMap<>(this.allCredits);
        Money updatedAmount = updatedCredits.get(currency).subtract(money);
        updatedCredits.put(currency, updatedAmount);
        return new Balance(new ArrayList(updatedCredits.values()));
    }

}
