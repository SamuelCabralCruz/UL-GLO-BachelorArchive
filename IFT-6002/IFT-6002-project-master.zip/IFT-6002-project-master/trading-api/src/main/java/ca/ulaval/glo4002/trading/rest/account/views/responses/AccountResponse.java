package ca.ulaval.glo4002.trading.rest.account.views.responses;

import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"accountNumber", "investorId", "investorProfile", "credits", "total"})
public class AccountResponse {

    private AccountNumber accountNumber;
    private InvestorId investorId;
    private InvestorProfileResponse investorProfile;
    private Balance credits;
    private Money total;

    public AccountNumber getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(AccountNumber accountNumber) {
        this.accountNumber = accountNumber;
    }

    public InvestorId getInvestorId() {
        return investorId;
    }

    public void setInvestorId(InvestorId investorId) {
        this.investorId = investorId;
    }

    public InvestorProfileResponse getInvestorProfile() {
        return investorProfile;
    }

    public void setInvestorProfile(InvestorProfileResponse investorProfile) {
        this.investorProfile = investorProfile;
    }

    public Balance getCredits() {
        return credits;
    }

    public void setCredits(Balance credits) {
        this.credits = credits;
    }

    public Money getTotal() {
        return total;
    }

    public void setTotal(Money total) {
        this.total = total;
    }

}