package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;

import java.util.List;

public interface AccountRepository {

    PersistedId create();

    void save(PersistedId persistedId, Account account);

    void update(Account account);

    void delete(PersistedId persistedId);

    List<Account> getAll();

    Account findByAccountNumber(AccountNumber accountNumber);

    boolean isExistingInvestor(InvestorId investorId);
}
