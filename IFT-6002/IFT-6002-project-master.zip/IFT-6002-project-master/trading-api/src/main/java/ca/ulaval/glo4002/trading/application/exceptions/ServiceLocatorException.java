package ca.ulaval.glo4002.trading.application.exceptions;

class ServiceLocatorException extends RuntimeException {

    ServiceLocatorException(String message) {
        super(message);
    }

}
