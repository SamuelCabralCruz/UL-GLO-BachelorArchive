package ca.ulaval.glo4002.trading.domain.account.dividend.exceptions;

public class DividendInvalidDateException extends DividendException {
}
