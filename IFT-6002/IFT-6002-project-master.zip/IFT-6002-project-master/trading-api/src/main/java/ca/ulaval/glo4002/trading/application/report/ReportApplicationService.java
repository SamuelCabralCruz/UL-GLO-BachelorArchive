package ca.ulaval.glo4002.trading.application.report;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.application.report.daily.DailyReportDTO;
import ca.ulaval.glo4002.trading.application.report.quarterly.Quarter;
import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterlyReportDTO;
import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.commons.Period;
import ca.ulaval.glo4002.trading.domain.commons.PeriodFactory;
import ca.ulaval.glo4002.trading.domain.report.Reporter;
import ca.ulaval.glo4002.trading.domain.report.historic.HistoricReport;
import ca.ulaval.glo4002.trading.domain.report.stockmarketreturn.StockMarketReturnReport;

import java.time.LocalDate;


public class ReportApplicationService {

    private final Reporter reporter;
    private final ReportDomainAssembler reportDomainAssembler;
    private final PeriodFactory periodFactory;

    public ReportApplicationService() {
        this(
                ServiceLocator.resolve(Reporter.class),
                ServiceLocator.resolve(ReportDomainAssembler.class),
                ServiceLocator.resolve(PeriodFactory.class)
        );
    }

    ReportApplicationService(Reporter reporter,
                             ReportDomainAssembler reportDomainAssembler,
                             PeriodFactory periodFactory) {
        this.reporter = reporter;
        this.reportDomainAssembler = reportDomainAssembler;
        this.periodFactory = periodFactory;
    }

    public DailyReportDTO generateDailyReport(AccountNumber accountNumber, LocalDate date) {
        Period period = periodFactory.create(date);
        HistoricReport historicReport = reporter.generateHistoricReport(accountNumber, period);
        return reportDomainAssembler.toDailyReportDTO(historicReport);
    }

    public QuarterlyReportDTO generateQuarterlyReport(AccountNumber accountNumber, Quarter quarter) {
        Period period = periodFactory.create(quarter);
        StockMarketReturnReport stockMarketReturnReport = reporter.generateStockMarketReport(accountNumber, period);
        return reportDomainAssembler.toQuarterlyReportDTO(stockMarketReturnReport);
    }

}
