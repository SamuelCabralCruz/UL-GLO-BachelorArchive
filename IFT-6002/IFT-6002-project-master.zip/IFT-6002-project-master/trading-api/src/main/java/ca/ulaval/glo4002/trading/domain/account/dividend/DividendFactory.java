package ca.ulaval.glo4002.trading.domain.account.dividend;

import ca.ulaval.glo4002.trading.domain.stock.Stock;

import java.time.LocalDateTime;

public class DividendFactory {

    public Dividend create(Stock stock, LocalDateTime date, double dividendPerShare) {
        return new Dividend(stock, date, dividendPerShare);
    }

}
