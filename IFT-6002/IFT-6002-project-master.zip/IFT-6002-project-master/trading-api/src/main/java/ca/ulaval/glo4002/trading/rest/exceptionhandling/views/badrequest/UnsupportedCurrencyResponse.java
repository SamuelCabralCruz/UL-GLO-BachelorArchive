package ca.ulaval.glo4002.trading.rest.exceptionhandling.views.badrequest;

import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.currency.exceptions.UnsupportedCurrencyException;
import ca.ulaval.glo4002.trading.rest.exceptionhandling.ExceptionMessage;

public class UnsupportedCurrencyResponse extends BadRequestResponse {

    private static final String ERROR = "UNSUPPORTED_CURRENCY";
    private static final String DESCRIPTION = "currency '%s' is not supported";
    private final Currency currency;

    public UnsupportedCurrencyResponse(UnsupportedCurrencyException e) {
        this.currency = e.getCurrency();
    }

    @Override
    public ExceptionMessage getMessage() {
        return new ExceptionMessage(ERROR, String.format(DESCRIPTION, currency.getValue()));
    }

}
