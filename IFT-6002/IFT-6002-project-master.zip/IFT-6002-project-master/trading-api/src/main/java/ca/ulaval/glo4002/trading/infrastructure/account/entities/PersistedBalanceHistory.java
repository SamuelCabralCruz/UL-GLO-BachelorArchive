package ca.ulaval.glo4002.trading.infrastructure.account.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import java.util.Map;

@Entity
public class PersistedBalanceHistory extends PersistedBaseEntity {
    @OneToMany(cascade = CascadeType.ALL)
    private Map<String, PersistedBalance> history;

    public Map<String, PersistedBalance> getHistory() {
        return history;
    }

    public void setHistory(Map<String, PersistedBalance> history) {
        this.history = history;
    }
}
