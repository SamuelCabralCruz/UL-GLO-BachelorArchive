package ca.ulaval.glo4002.trading.domain.currency;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.commons.Money;

import java.util.ArrayList;
import java.util.List;

public class CurrencyExchanger {

    private ExchangeRateRepository exchangeRateRepository;

    public CurrencyExchanger() {
        this(
                ServiceLocator.resolve(ExchangeRateRepository.class)
        );
    }

    CurrencyExchanger(ExchangeRateRepository exchangeRateRepository) {
        this.exchangeRateRepository = exchangeRateRepository;
    }

    public Money getTotal(List<Money> monies) {
        return getTotal(monies, Currency.DEFAULT_CURRENCY);
    }

    public Money getTotal(List<Money> monies, Currency to) {
        //monies.stream().collect(Money.getSummingCollector())

        List<Money> convertedMonies = convert(monies, to);
        Money total = new Money(0f);
        for (Money money : convertedMonies) {
            total = total.add(money);
        }
        return total;
    }

    public List<Money> convert(List<Money> monies, Currency to) {
        List<Money> convertedMonies = new ArrayList<>();
        for (Money money : monies) {
            convertedMonies.add(convert(money, to));
        }
        return convertedMonies;
    }

    public Money convert(Money money, Currency to) {
        double exchangeRate = exchangeRateRepository.findByCurrencies(money.getCurrency(), to);
        return money.multiply(exchangeRate);
    }

}
