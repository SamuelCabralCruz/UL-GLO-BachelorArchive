package ca.ulaval.glo4002.trading.rest.databind.serializers;

import ca.ulaval.glo4002.trading.domain.account.Balance;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.rest.account.views.responses.CreditResponse;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;

public class BalanceSerializer extends JsonSerializer<Balance> {

    @Override
    public void serialize(Balance balance, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeStartArray();
        for (Money credit : balance.getCredits()) {
            Currency currency = credit.getCurrency();
            CreditResponse creditResponse = new CreditResponse();
            creditResponse.setCurrency(currency.getValue());
            creditResponse.setAmount(credit);
            jsonGenerator.writeObject(creditResponse);
        }
        jsonGenerator.writeEndArray();
    }

}
