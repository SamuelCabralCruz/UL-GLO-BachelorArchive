package ca.ulaval.glo4002.trading.domain.commons.exceptions;

public class InvalidDateException extends DomainException {

}

