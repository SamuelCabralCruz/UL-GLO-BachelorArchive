package ca.ulaval.glo4002.trading.infrastructure.stock;

import ca.ulaval.glo4002.trading.application.ServiceLocator;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.StockNotFoundException;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.stock.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RestApiStockRepository implements StockRepository {

    private static final String URI = "http://localhost:8080";
    private static final String PATH = "stocks";
    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    private Map<String, String> currencies;
    private InstantStockFactory instantStockFactory;
    private WebTarget target;

    public RestApiStockRepository() {
        this(ServiceLocator.resolve(InstantStockFactory.class));
    }

    RestApiStockRepository(InstantStockFactory instantStockFactory) {
        instantiateCurrencies();
        this.instantStockFactory = instantStockFactory;
        this.target = ClientBuilder.newClient()
                .target(URI)
                .path(PATH);
    }

    private void instantiateCurrencies() {
        currencies = new HashMap<>();
        currencies.put("NASDAQ", "USD");
        currencies.put("NYSE", "USD");
        currencies.put("XTKS", "JPY");
        currencies.put("XSWX", "CHF");
    }

    @Override
    public Stock findByStockIdAndDate(StockId stockId, LocalDateTime date) throws InvalidDateException {
        String response = getResponse(stockId);
        ObjectMapper mapper = new ObjectMapper();
        try {
            RestApiStockDTO restApiStockDTO = mapper.readValue(response, RestApiStockDTO.class);
            StockType type = StockType.valueOf(restApiStockDTO.getType().toUpperCase());
            Currency currency = new Currency(currencies.get(stockId.getMarket().getValue()));
            Money price = getPrice(restApiStockDTO, currency, date);
            return instantStockFactory.create(stockId, price, type);
        } catch (IOException e) {
            throw new StockNotFoundException(stockId);
        }
    }

    private String getResponse(StockId stockId) {
        String market = stockId.getMarket().getValue();
        String symbol = stockId.getSymbol().getValue();
        return target.path(market).path(symbol).request().get(String.class);
    }

    private Money getPrice(RestApiStockDTO restApiStockDTO, Currency currency, LocalDateTime date) throws InvalidDateException {
        Map<LocalDate, Money> prices = getConvertedPrices(currency, restApiStockDTO);
        Money price = prices.get(date.toLocalDate());
        if (price == null) {
            throw new InvalidDateException();
        }
        return price;
    }

    private Map<LocalDate, Money> getConvertedPrices(Currency currency, RestApiStockDTO restApiStockDTO) {
        List<RestApiPriceDTO> rawPrices = restApiStockDTO.getPrices();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        return rawPrices.stream()
                .collect(Collectors.toMap(
                        priceDTO -> LocalDate.parse(priceDTO.getDate(), dateFormatter),
                        priceDTO -> new Money(priceDTO.getPrice(), currency)));
    }

}
