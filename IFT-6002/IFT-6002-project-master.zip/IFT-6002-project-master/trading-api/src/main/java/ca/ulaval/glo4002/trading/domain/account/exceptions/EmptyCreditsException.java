package ca.ulaval.glo4002.trading.domain.account.exceptions;

public class EmptyCreditsException extends AccountException {

}
