package ca.ulaval.glo4002.trading.infrastructure.account.entities;

import ca.ulaval.glo4002.trading.domain.account.PersistedId;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
public class PersistedBaseEntity implements Serializable {

    @Id
    @GeneratedValue
    private Long persistedId;

    public PersistedId getPersistedId() {
        return new PersistedId(persistedId);
    }

    public void setPersistedId(PersistedId persistedId) {
        this.persistedId = persistedId.getValue();
    }

}