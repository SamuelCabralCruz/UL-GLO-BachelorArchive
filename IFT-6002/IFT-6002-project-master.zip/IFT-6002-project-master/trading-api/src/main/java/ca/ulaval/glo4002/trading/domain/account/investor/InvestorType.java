package ca.ulaval.glo4002.trading.domain.account.investor;

public enum InvestorType {
    CONSERVATIVE
}
