package ca.ulaval.glo4002.trading.domain.commons;

import ca.ulaval.glo4002.trading.application.report.quarterly.Quarter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class PeriodFactory {

    public Period create(LocalDate date) {
        LocalDateTime beginningOfDay = makeBeginningOfTheDay(date);
        LocalDateTime endOfDay = makeEndOfTheDay(date);
        return new Period(beginningOfDay, endOfDay);
    }

    public Period create(Quarter quarter) {
        LocalDateTime quarterBeginning = quarter.getBeginning();
        LocalDateTime quarterEnding = quarter.getEnding();
        LocalDate today = LocalDate.now();
        if (quarterEnding.toLocalDate().isEqual(today) || quarterEnding.toLocalDate().isAfter(today)) {
            LocalDate yesterday = today.minusDays(1);
            quarterEnding = makeEndOfTheDay(yesterday);
        }
        return new Period(quarterBeginning, quarterEnding);
    }

    private LocalDateTime makeBeginningOfTheDay(LocalDate date) {
        return LocalDateTime.of(date, LocalTime.MIN);
    }

    private LocalDateTime makeEndOfTheDay(LocalDate date) {
        return LocalDateTime.of(date, LocalTime.MAX);
    }

}
