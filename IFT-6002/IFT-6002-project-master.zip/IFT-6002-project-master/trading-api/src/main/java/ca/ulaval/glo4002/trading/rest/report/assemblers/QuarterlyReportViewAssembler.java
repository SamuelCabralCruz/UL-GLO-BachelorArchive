package ca.ulaval.glo4002.trading.rest.report.assemblers;

import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterlyReportDTO;
import ca.ulaval.glo4002.trading.rest.report.views.responses.QuarterlyReportResponse;
import ca.ulaval.glo4002.trading.rest.report.views.responses.StockMarketReturnResponse;

import java.util.List;
import java.util.stream.Collectors;

public class QuarterlyReportViewAssembler {

    private StockMarketReturnViewAssembler stockMarketReturnViewAssembler;

    public QuarterlyReportViewAssembler() {
        this.stockMarketReturnViewAssembler = new StockMarketReturnViewAssembler();
    }

    public QuarterlyReportResponse from(QuarterlyReportDTO quarterlyReportDTO) {
        QuarterlyReportResponse quarterlyReportResponse = new QuarterlyReportResponse();
        quarterlyReportResponse.setPeriod(quarterlyReportDTO.getQuarter());
        List<StockMarketReturnResponse> stockMarketReturnResponses = quarterlyReportDTO.getStocksAccountDTOs()
                .stream().map(stockMarketReturnViewAssembler::from).collect(Collectors.toList());
        quarterlyReportResponse.setStocksAccount(stockMarketReturnResponses);
        return quarterlyReportResponse;
    }

}
