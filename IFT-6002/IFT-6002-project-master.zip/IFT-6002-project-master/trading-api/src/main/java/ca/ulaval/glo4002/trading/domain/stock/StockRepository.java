package ca.ulaval.glo4002.trading.domain.stock;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;

import java.time.LocalDateTime;

public interface StockRepository {

    Stock findByStockIdAndDate(StockId stockId, LocalDateTime date) throws InvalidDateException;

}
