package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.commons.ValueObject;

public class PersistedId extends ValueObject {

    private Long value;

    public PersistedId(Long persistedId) {
        this.value = persistedId;
    }

    public long getValue() {
        return value;
    }

}
