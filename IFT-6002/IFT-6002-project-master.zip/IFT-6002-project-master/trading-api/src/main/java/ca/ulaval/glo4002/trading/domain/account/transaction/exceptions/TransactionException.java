package ca.ulaval.glo4002.trading.domain.account.transaction.exceptions;

import ca.ulaval.glo4002.trading.domain.commons.exceptions.TradingApiException;

public class TransactionException extends TradingApiException {
}
