package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;

public interface Fee {

    Money calculate(long quantity, Money amount);

}
