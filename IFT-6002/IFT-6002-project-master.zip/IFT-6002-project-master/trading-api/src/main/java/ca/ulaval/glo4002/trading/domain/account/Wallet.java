package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumbers;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.InvalidTransactionNumberException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.NotEnoughStockException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.rejected.StockParametersDontMatchException;
import ca.ulaval.glo4002.trading.domain.commons.Period;
import ca.ulaval.glo4002.trading.domain.stock.StockId;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToLongFunction;
import java.util.stream.Collectors;


public class Wallet {

    private Map<TransactionNumber, Transaction> transactions = new HashMap<>();
    private Map<TransactionNumber, TransactionNumbers> history = new HashMap<>();

    public Wallet() {
        // For hibernate
    }

    public Map<TransactionNumber, Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(Map<TransactionNumber, Transaction> transactions) {
        this.transactions = transactions;
    }

    public Map<TransactionNumber, TransactionNumbers> getHistory() {
        return history;
    }

    public void setHistory(Map<TransactionNumber, TransactionNumbers> history) {
        this.history = history;
    }

    Transaction getPurchaseTransaction(Transaction transactionSell) {
        try {
            TransactionNumber referencedTransactionNumber = transactionSell.getReferencedTransactionNumber();
            return getTransaction(referencedTransactionNumber);
        } catch (TransactionNotFoundException e) {
            TransactionNumber transactionNumber = transactionSell.getTransactionNumber();
            throw new InvalidTransactionNumberException(transactionNumber);
        }
    }

    Transaction getTransaction(TransactionNumber transactionNumber) {
        Transaction transaction = transactions.get(transactionNumber);
        if (transaction == null) {
            throw new TransactionNotFoundException(transactionNumber);
        }
        return transaction;
    }

    void checkIfEnoughStocksToProceedSale(Transaction transactionBuy, Transaction transactionSell) {
        checkIfStocksMatch(transactionBuy, transactionSell);
        checkIfEnoughStocks(transactionSell, transactionBuy);
    }

    private void checkIfStocksMatch(Transaction transactionBuy, Transaction transactionSell) {
        StockId stockPurchase = transactionBuy.getStockId();
        StockId stockSale = transactionSell.getStockId();
        if (!stockPurchase.equals(stockSale)) {
            TransactionNumber transactionNumber = transactionBuy.getTransactionNumber();
            throw new StockParametersDontMatchException(transactionNumber);
        }
    }

    private void checkIfEnoughStocks(Transaction transactionSell, Transaction transactionBuy) {
        long remainingQuantity = getRemainingQuantity(transactionBuy);
        if (remainingQuantity < transactionSell.getQuantity()) {
            StockId stockId = transactionSell.getStockId();
            TransactionNumber transactionNumber = transactionSell.getTransactionNumber();
            throw new NotEnoughStockException(transactionNumber, stockId);
        }
    }

    private long getRemainingQuantity(Transaction referencedTransaction) {
        TransactionNumber referencedTransactionNumber = referencedTransaction.getTransactionNumber();
        TransactionNumbers transactionHistory = history.get(referencedTransactionNumber);
        long remainingQuantity = referencedTransaction.getQuantity();
        for (TransactionNumber transactionNumber : transactionHistory.getTransactionNumberList()) {
            Transaction transaction = transactions.get(transactionNumber);
            remainingQuantity -= transaction.getQuantity();
        }
        return remainingQuantity;
    }

    void addPurchaseTransaction(Transaction transactionBuy) {
        recordTransaction(transactionBuy);
        registerTransactionHistory(transactionBuy);
    }

    private void recordTransaction(Transaction transaction) {
        TransactionNumber transactionNumber = transaction.getTransactionNumber();
        transactions.put(transactionNumber, transaction);
    }

    private void registerTransactionHistory(Transaction transaction) {
        TransactionNumber transactionNumber = transaction.getTransactionNumber();
        history.put(transactionNumber, new TransactionNumbers());
    }

    void addSaleTransaction(Transaction transactionBuy, Transaction transactionSell) {
        recordTransaction(transactionSell);
        updateTransactionHistory(transactionBuy, transactionSell);
    }

    private void updateTransactionHistory(Transaction referencedTransaction, Transaction transaction) {
        TransactionNumber referencedTransactionTransactionNumber = referencedTransaction.getTransactionNumber();
        TransactionNumbers transactionHistory = history.get(referencedTransactionTransactionNumber);
        TransactionNumber transactionNumber = transaction.getTransactionNumber();
        transactionHistory.getTransactionNumberList().add(transactionNumber);
        history.put(referencedTransactionTransactionNumber, transactionHistory);
    }

    List<Transaction> getTransactionsOver(Period period) {
        List<Transaction> filteredTransactions = new ArrayList<>();
        for (Map.Entry<TransactionNumber, Transaction> entry : this.transactions.entrySet()) {
            Transaction transaction = entry.getValue();
            LocalDateTime transactionDate = transaction.getDate();
            if (period.contains(transactionDate)) {
                filteredTransactions.add(transaction);
            }
        }
        return filteredTransactions;
    }

    List<InvestmentPosition> getInvestmentPositionsAsOf(LocalDateTime date) {
        Period period = new Period(LocalDateTime.MIN, date);
        Predicate<TransactionNumber> predicate = transactionNumber -> {
            Transaction transaction = transactions.get(transactionNumber);
            boolean isInPeriod = period.contains(transaction.getDate());
            boolean hasRemainingStocks = getRemainingQuantityAsOf(transaction, date) > 0;
            return isInPeriod && hasRemainingStocks;
        };
        Function<TransactionNumber, InvestmentPosition> function = transactionNumber -> {
            Transaction transaction = transactions.get(transactionNumber);
            return new InvestmentPosition(transactionNumber, transaction.getStockId(),
                    getRemainingQuantityAsOf(transaction, date));
        };
        return history.keySet().stream().filter(predicate).map(function).collect(Collectors.toList());
    }

    private long getRemainingQuantityAsOf(Transaction referencedTransaction, LocalDateTime date) {
        LocalDateTime referencedTransactionDate = referencedTransaction.getDate();
        if (referencedTransactionDate.isAfter(date)) {
            return 0;
        }
        long remainingQuantity = referencedTransaction.getQuantity();
        long soldQuantity = getSoldQuantityAsOf(referencedTransaction, date);
        return remainingQuantity - soldQuantity;
    }

    private long getSoldQuantityAsOf(Transaction referencedTransaction, LocalDateTime date) {
        Predicate<TransactionNumber> predicate = transactionNumber -> {
            Transaction transaction = transactions.get(transactionNumber);
            return new Period(LocalDateTime.MIN, date).contains(transaction.getDate());
        };
        ToLongFunction<TransactionNumber> function = transactionNumber -> {
            Transaction transaction = transactions.get(transactionNumber);
            return transaction.getQuantity();
        };
        TransactionNumber transactionNumber = referencedTransaction.getTransactionNumber();
        return history.get(transactionNumber).getTransactionNumberList().stream()
                .filter(predicate).mapToLong(function).sum();
    }

    List<InvestmentPosition> getInvestmentPositionsOver(Period period) {
        List<InvestmentPosition> marketPositionBeginning = getInvestmentPositionsAsOf(period.getBeginning());
        List<InvestmentPosition> marketPositionEnding = getInvestmentPositionsAsOf(period.getEnding());
        return retainAll(marketPositionEnding, marketPositionBeginning);
    }

    private List<InvestmentPosition> retainAll(List<InvestmentPosition> source, List<InvestmentPosition> filter) {
        Set<StockId> stockIdsFilter = new HashSet<>();
        Set<TransactionNumber> transactionNumbersFilter = new HashSet<>();
        filter.forEach(investmentPosition -> {
            stockIdsFilter.add(investmentPosition.getStockId());
            transactionNumbersFilter.add(investmentPosition.getTransactionNumber());
        });
        Predicate<InvestmentPosition> predicate = investmentPosition -> {
            TransactionNumber transactionNumber = investmentPosition.getTransactionNumber();
            StockId stockId = investmentPosition.getStockId();
            boolean isContainedTransactionNumber = transactionNumbersFilter.contains(transactionNumber);
            boolean isContainedStockId = stockIdsFilter.contains(stockId);
            return isContainedTransactionNumber && isContainedStockId;
        };
        return source.stream().filter(predicate).collect(Collectors.toList());
    }

}


