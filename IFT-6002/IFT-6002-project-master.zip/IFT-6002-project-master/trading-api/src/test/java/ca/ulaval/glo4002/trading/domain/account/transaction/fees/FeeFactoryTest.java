package ca.ulaval.glo4002.trading.domain.account.transaction.fees;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class FeeFactoryTest {

    private static final float MINOR_FEE_PER_SHARE = 0.25f;
    private static final float MAJOR_FEE_PER_SHARE = 0.20f;
    private static final float MINOR_AMOUNT_RATE = 0.00f;
    private static final float MAJOR_AMOUNT_RATE = 0.03f;

    private FeeFactory feeFactory;

    @Before
    public void setUp() {
        feeFactory = new FeeFactory();
    }

    @Test
    public void givenTransactionWithMinorQtyAndMinorAmt_whenComputeFees_thenMinorFeePerShareAndMinorRateApplied() {
        long shareQuantity = 100L;
        Money subTotal = new Money(1);
        Money appliedFee = feeFactory.create(shareQuantity, subTotal);
        Money expectedFee = computeTotalFees(shareQuantity, subTotal, MINOR_FEE_PER_SHARE, MINOR_AMOUNT_RATE);
        assertEquals(expectedFee, appliedFee);
    }

    @Test
    public void givenTransactionWithMajorQtyAndMinorAmt_whenComputeFees_thenMajorFeePerShareAndMinorRateApplied() {
        long shareQuantity = 101L;
        Money subTotal = new Money(1);
        Money appliedFee = feeFactory.create(shareQuantity, subTotal);
        Money expectedFee = computeTotalFees(shareQuantity, subTotal, MAJOR_FEE_PER_SHARE, MINOR_AMOUNT_RATE);
        assertEquals(expectedFee, appliedFee);
    }

    @Test
    public void givenTransactionWithMinorQtyAndMajorAmt_whenComputeFees_thenMinorFeePerShareAndMajorRateApplied() {
        long shareQuantity = 100L;
        Money subTotal = new Money(5001);
        Money appliedFee = feeFactory.create(shareQuantity, subTotal);
        Money expectedFee = computeTotalFees(shareQuantity, subTotal, MINOR_FEE_PER_SHARE, MAJOR_AMOUNT_RATE);
        assertEquals(expectedFee, appliedFee);
    }

    @Test
    public void givenTransactionWithMajorQtyAndMajorAmt_whenComputeFees_thenMajorFeePerShareAndMajorRateApplied() {
        long shareQuantity = 101L;
        Money subTotal = new Money(5001);
        Money appliedFee = feeFactory.create(shareQuantity, subTotal);
        Money expectedFee = computeTotalFees(shareQuantity, subTotal, MAJOR_FEE_PER_SHARE, MAJOR_AMOUNT_RATE);
        assertEquals(expectedFee, appliedFee);
    }

    private Money computeTotalFees(long quantity, Money amount, float feePerShare, float feeAmountRate) {
        Money feesSubAmount = amount.multiply(feeAmountRate);
        Money feesPerShare = new Money(feePerShare * quantity);
        return feesSubAmount.add(feesPerShare);
    }

}