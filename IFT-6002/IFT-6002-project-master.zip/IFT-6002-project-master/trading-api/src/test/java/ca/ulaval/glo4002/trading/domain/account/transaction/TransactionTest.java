package ca.ulaval.glo4002.trading.domain.account.transaction;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;

public class TransactionTest {

    private static final StockId STOCK_ID = new StockId("NASDAQ", "MSFT");
    private static final Money PRICE = new Money(10f);
    private static final int QUANTITY = 10;
    private static final LocalDateTime DATE = LocalDateTime.now();
    private static final Money SUBTOTAL = new Money(100f);
    private static final Money FEES = new Money(5);

    private Transaction transaction;

    @Test
    public void givenBuyTransaction_whenGetTotal_thenFeesAddedToSubTotal() {
        transaction = new Transaction(null, STOCK_ID, PRICE, QUANTITY, DATE,
                TransactionType.BUY, SUBTOTAL, FEES);
        Money expectedTotal = SUBTOTAL.add(FEES);
        assertEquals(expectedTotal, transaction.getTotal());
    }

    @Test
    public void givenSellTransaction_whenGetTotal_thenFeesSubtractedToSubTotal() {
        transaction = new Transaction(null, STOCK_ID, PRICE, QUANTITY, DATE,
                TransactionType.SELL, SUBTOTAL, FEES);
        Money expectedTotal = SUBTOTAL.subtract(FEES);
        assertEquals(expectedTotal, transaction.getTotal());
    }

}