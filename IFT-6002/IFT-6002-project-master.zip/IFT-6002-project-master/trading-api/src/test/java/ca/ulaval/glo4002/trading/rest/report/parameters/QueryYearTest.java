package ca.ulaval.glo4002.trading.rest.report.parameters;

import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportInvalidYearException;
import org.junit.Test;

import java.time.Year;

import static org.junit.Assert.*;

public class QueryYearTest {

    @Test
    public void givenValidYear_whenCreate_thenQueryYearCreated() {
        Year year = Year.of(2017);
        QueryYear queryYear = new QueryYear(year.toString());
        assertEquals(year, queryYear.getValue());
    }

    @Test
    public void givenEmptyYear_whenCreate_thenCurrentYear() {
        Year year = Year.now();
        QueryYear queryYear = new QueryYear("");
        assertEquals(year, queryYear.getValue());
    }

    @Test(expected = ReportInvalidYearException.class)
    public void givenFutureYear_whenCreate_thenThrows() {
        new QueryYear(Year.now().plusYears(1).toString());
    }

    @Test(expected = ReportInvalidYearException.class)
    public void givenInvalidYear_whenCreate_thenThrows() {
        new QueryYear("invalid");
    }

    @Test(expected = ReportInvalidYearException.class)
    public void givenYearOutOfRange_whenCreate_thenThrows() {
        new QueryYear("2012");
    }

}