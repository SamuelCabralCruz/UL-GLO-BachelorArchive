package ca.ulaval.glo4002.trading.domain.account.transaction;

import ca.ulaval.glo4002.trading.domain.account.transaction.fees.FeeFactory;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class TransactionFactoryTest {

    private static final long QUANTITY = 10L;
    private static final Money PRICE = new Money(15f);
    private static final Money SUBTOTAL = PRICE.multiply(QUANTITY);
    private static final LocalDateTime DATE = LocalDateTime.now();
    private static final StockId STOCK_ID = new StockId("NASDAQ", "MSFT");

    @Mock
    private FeeFactory feeFactory;

    private TransactionFactory transactionFactory;

    @Before
    public void setUp() {
        transactionFactory = new TransactionFactory(feeFactory);
    }

    @Test
    public void whenCreate_thenSubTotalProperlyComputed() {
        Transaction transaction = transactionFactory.create(null, STOCK_ID, PRICE, QUANTITY, DATE, TransactionType.BUY);
        assertEquals(SUBTOTAL, transaction.getSubTotal());
    }

    @Test
    public void whenCreate_thenFeeFactoryCalculateFees() {
        transactionFactory.create(null, STOCK_ID, PRICE, QUANTITY, DATE, TransactionType.BUY);
        verify(feeFactory).create(QUANTITY, SUBTOTAL);
    }

}