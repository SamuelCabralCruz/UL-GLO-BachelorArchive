package ca.ulaval.glo4002.trading.application.account;

import ca.ulaval.glo4002.trading.domain.account.*;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountAlreadyOpenException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.AccountNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorType;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import ca.ulaval.glo4002.trading.domain.currency.CurrencyExchanger;
import ca.ulaval.glo4002.trading.domain.currency.ExchangeRateRepository;
import ca.ulaval.glo4002.trading.domain.currency.exceptions.UnsupportedCurrencyException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class AccountApplicationServiceTest {

    private static final PersistedId PERSISTED_ID = new PersistedId(0L);
    private static final AccountNumber ACCOUNT_NUMBER = new AccountNumber("JG-12");
    private static final Money VALID_MONEY = new Money(5f);
    private static final Balance BALANCE = new Balance(Arrays.asList(VALID_MONEY));
    private static final InvestorId INVESTOR_ID = new InvestorId(87L);
    private static final String INVESTOR_NAME = "Chesnaught Tynamo";
    private static final InvestorType INVESTOR_TYPE = InvestorType.CONSERVATIVE;
    private static final ArrayList INVESTOR_FOCUS_AREAS = new ArrayList();

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private AccountFactory accountFactory;

    @Mock
    private ExchangeRateRepository exchangeRateRepository;

    @Mock
    private CurrencyExchanger currencyExchanger;

    @Mock
    private Account account;

    private AccountApplicationService accountApplicationService;
    private AccountDTO accountDTO = new AccountDTO();
    private AccountDomainAssembler accountDomainAssembler = new AccountDomainAssembler();

    @Before
    public void setUp() {
        setUpAccount();
        setUpAccountDTO();
        accountApplicationService = new AccountApplicationService(
                accountRepository,
                accountFactory,
                accountDomainAssembler,
                exchangeRateRepository,
                currencyExchanger);
        willReturn(PERSISTED_ID).given(accountRepository).create();
        willReturn(false).given(accountRepository).isExistingInvestor(INVESTOR_ID);
        willReturn(account).given(accountFactory).create(PERSISTED_ID, INVESTOR_ID, INVESTOR_NAME, BALANCE);
        willReturn(account).given(accountRepository).findByAccountNumber(ACCOUNT_NUMBER);
        willReturn(true).given(exchangeRateRepository).containsCurrency(Currency.DEFAULT_CURRENCY);
    }

    @Test
    public void givenAnAccountRepositoryContainingAnAccount_whenRetrievingIt_thenDTOIsReturned() {
        willReturn(account).given(accountRepository).findByAccountNumber(ACCOUNT_NUMBER);
        AccountDTO accountReturned = accountApplicationService.getByAccountNumber(ACCOUNT_NUMBER);
        assertEquals(ACCOUNT_NUMBER, accountReturned.getAccountNumber());
    }

    @Test(expected = AccountNotFoundException.class)
    public void givenAnUnexistingAccountId_whenRetrievingTheAccount_thenThrows() {
        AccountNotFoundException exception = new AccountNotFoundException(ACCOUNT_NUMBER);
        willThrow(exception).given(accountRepository).findByAccountNumber(ACCOUNT_NUMBER);
        accountApplicationService.getByAccountNumber(ACCOUNT_NUMBER);
    }

    @Test
    public void whenCreatingAccount_thenAccountIsCreatedIntoRepository() {
        accountApplicationService.createAccount(accountDTO);
        verify(accountRepository).create();
    }

    @Test
    public void whenCreatingAccount_thenAccountIsSavedIntoRepository() {
        accountApplicationService.createAccount(accountDTO);
        verify(accountRepository).save(PERSISTED_ID, account);
    }

    @Test
    public void givenErrorOnCreation_whenCreatingAccount_thenAccountIsDeletedFromRepository() {
        willThrow(Exception.class).given(accountFactory).create(any(), any(), any(), any());
        try {
            accountApplicationService.createAccount(accountDTO);
        } catch (Exception ignored) {
        } finally {
            verify(accountRepository).delete(PERSISTED_ID);
        }
    }

    @Test(expected = AccountAlreadyOpenException.class)
    public void givenAnExistingInvestor_whenCreatingAnAccountForThatInvestor_thenThrows() {
        willReturn(true).given(accountRepository).isExistingInvestor(INVESTOR_ID);
        accountApplicationService.createAccount(accountDTO);
    }

    @Test(expected = UnsupportedCurrencyException.class)
    public void givenAnUnsupportedCurrency_whenCreatingAccount_thenThrows() {
        willReturn(false).given(exchangeRateRepository).containsCurrency(Currency.DEFAULT_CURRENCY);
        accountApplicationService.createAccount(accountDTO);
    }

    private void setUpAccount() {
        willReturn(ACCOUNT_NUMBER).given(account).getAccountNumber();
        willReturn(INVESTOR_ID).given(account).getInvestorId();
        willReturn(INVESTOR_TYPE).given(account).getInvestorType();
        willReturn(INVESTOR_FOCUS_AREAS).given(account).getFocusAreas();
        willReturn(new Balance(Arrays.asList(VALID_MONEY))).given(account).getBalance();
    }

    private void setUpAccountDTO() {
        accountDTO.setAccountNumber(ACCOUNT_NUMBER);
        accountDTO.setInvestorId(INVESTOR_ID);
        accountDTO.setInvestorName(INVESTOR_NAME);
        accountDTO.setBalance(BALANCE);
    }

}