package ca.ulaval.glo4002.trading.domain.account;

import ca.ulaval.glo4002.trading.domain.account.exceptions.EmptyCreditsException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidAmountException;
import ca.ulaval.glo4002.trading.domain.account.exceptions.InvalidInvestorNameException;
import ca.ulaval.glo4002.trading.domain.account.investor.InvestorId;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.currency.Currency;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;

public class AccountFactoryTest {

    private static final PersistedId PERSISTED_ID = new PersistedId(0L);
    private static final InvestorId INVESTOR_ID = new InvestorId(1L);
    private static final String INVESTOR_NAME = "Farfetch'd Quagsire";
    private static final AccountNumber ACCOUNT_NUMBER = new AccountNumber("FQ-0");
    private static final Money ACCOUNT_MONEY = new Money(100f);
    private static final Balance BALANCE = new Balance(Arrays.asList(ACCOUNT_MONEY));

    private AccountFactory accountFactory;

    @Before
    public void setUp() {
        accountFactory = new AccountFactory();
    }

    @Test
    public void whenCreate_thenAccountCreated() {
        Account account = accountFactory.create(PERSISTED_ID, INVESTOR_ID, INVESTOR_NAME, BALANCE);
        assertEquals(ACCOUNT_NUMBER, account.getAccountNumber());
        assertEquals(ACCOUNT_MONEY, account.getBalance().getCredits(Currency.DEFAULT_CURRENCY));
        assertEquals(INVESTOR_ID, account.getInvestorId());
    }

    @Test(expected = EmptyCreditsException.class)
    public void givenNoCredits_whenCreate_thenThrows() {
        Balance emptyBalance = new Balance(new ArrayList<>());
        accountFactory.create(PERSISTED_ID, INVESTOR_ID, INVESTOR_NAME, emptyBalance);
    }

    @Test(expected = InvalidAmountException.class)
    public void givenAnInvalidAmountOfCredits_whenCreate_thenThrows() {
        Balance nullBalance = new Balance(Arrays.asList(new Money(0f)));
        accountFactory.create(PERSISTED_ID, INVESTOR_ID, INVESTOR_NAME, nullBalance);
    }

    @Test(expected = InvalidAmountException.class)
    public void givenNegativeCredits_whenCreate_thenThrows() {
        Balance negativeBalance = new Balance(Arrays.asList(new Money(-324f)));
        accountFactory.create(PERSISTED_ID, INVESTOR_ID, INVESTOR_NAME, negativeBalance);
    }

    @Test(expected = InvalidInvestorNameException.class)
    public void givenInvalidInvestorName_whenCreate_thenThrows() {
        accountFactory.create(PERSISTED_ID, INVESTOR_ID, "INVALID", BALANCE);
    }

}