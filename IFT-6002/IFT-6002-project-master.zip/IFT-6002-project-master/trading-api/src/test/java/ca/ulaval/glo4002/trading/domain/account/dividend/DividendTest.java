package ca.ulaval.glo4002.trading.domain.account.dividend;

import ca.ulaval.glo4002.trading.domain.account.InvestmentPosition;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.willReturn;


@RunWith(MockitoJUnitRunner.class)
public class DividendTest {

    private static final LocalDateTime DATE = LocalDateTime.now();
    private static final float DIVIDEND_PER_SHARE = 4f;
    private static final int QUANTITY = 10;
    private static final StockId STOCK_ID = new StockId("NASDAQ", "MSFT");
    private static final TransactionNumber TRANSACTION_NUMBER = new TransactionNumber();
    private static final Money PRICE = new Money(5f);
    private static final double DIVIDEND_RATE = 0.14d;

    @Mock
    private Stock stock;

    private Dividend dividend;

    @Before
    public void setUp() {
        willReturn(PRICE).given(stock).getPrice();
        willReturn(DIVIDEND_RATE).given(stock).getDividendRate();
        dividend = new Dividend(stock, DATE, DIVIDEND_PER_SHARE);
    }

    @Test
    public void whenConvertToPayment_thenDividendValueCalculated() {
        InvestmentPosition investmentPosition = new InvestmentPosition(TRANSACTION_NUMBER, STOCK_ID, QUANTITY);
        DividendPayment dividendPayment = dividend.convertToPayment(investmentPosition);
        Money expectedValue = new Money(QUANTITY * DIVIDEND_PER_SHARE).add(PRICE.multiply(QUANTITY * DIVIDEND_RATE));
        assertEquals(expectedValue, dividendPayment.getValue());
    }

}