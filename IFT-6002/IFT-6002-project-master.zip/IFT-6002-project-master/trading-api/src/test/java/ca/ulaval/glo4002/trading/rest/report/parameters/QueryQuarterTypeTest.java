package ca.ulaval.glo4002.trading.rest.report.parameters;

import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterType;
import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportInvalidQuarterException;
import org.junit.Test;

import static org.junit.Assert.*;

public class QueryQuarterTypeTest {

    @Test
    public void givenValidQuarterType_whenCreate_thenQueryQuarterTypeCreated() {
        QuarterType quarterType = QuarterType.Q1;
        QueryQuarterType queryQuarterType = new QueryQuarterType(quarterType.toString());
        assertEquals(quarterType, queryQuarterType.getValue());
    }

    @Test
    public void givenEmptyQuarterType_whenCreate_thenCurrentQuarterType(){
        QuarterType quarterType = QuarterType.getCurrentQuarterType();
        QueryQuarterType queryQuarterType = new QueryQuarterType("");
        assertEquals(quarterType, queryQuarterType.getValue());
    }

    @Test(expected = ReportInvalidQuarterException.class)
    public void givenInvalidQuarterType_whenCreate_thenThrows() {
        new QueryQuarterType("INVALID");
    }

}