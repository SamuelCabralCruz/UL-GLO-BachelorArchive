package ca.ulaval.glo4002.trading.rest.report.parameters;

import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportInvalidDateException;
import org.junit.Test;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class QueryDateTest {

    @Test
    public void givenValidDate_whenCreate_thenQueryDateCreated() {
        LocalDate validDate = LocalDate.now().minusDays(1);
        QueryDate queryDate = new QueryDate(validDate.toString());
        assertEquals(validDate, queryDate.getValue());
    }

    @Test(expected = ReportInvalidDateException.class)
    public void givenPresentDate_whenCreate_thenThrows() {
        LocalDate presentDate = LocalDate.now();
        new QueryDate(presentDate.toString());
    }

    @Test(expected = ReportInvalidDateException.class)
    public void givenFutureDate_whenCreate_thenThrows() {
        LocalDate futureDate = LocalDate.now().plusDays(5);
        new QueryDate(futureDate.toString());
    }

    @Test
    public void givenEmptyDate_whenCreate_thenReturnsNull() {
        assertNull(new QueryDate("").getValue());
    }

    @Test(expected = ReportInvalidDateException.class)
    public void givenInvalidDate_whenCreate_thenThrows() {
        new QueryDate("invalid");
    }

}