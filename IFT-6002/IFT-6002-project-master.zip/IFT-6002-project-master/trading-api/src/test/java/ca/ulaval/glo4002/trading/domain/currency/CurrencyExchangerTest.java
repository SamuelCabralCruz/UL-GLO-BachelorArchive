package ca.ulaval.glo4002.trading.domain.currency;

import ca.ulaval.glo4002.trading.domain.commons.Money;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.willReturn;

@RunWith(MockitoJUnitRunner.class)
public class CurrencyExchangerTest {

    private static final double EXCHANGE_RATE_CAD_CAD = 1d;
    private static final double EXCHANGE_RATE_USD_CAD = 1.31d;
    private static final double EXCHANGE_RATE_CHF_CAD = 1.45d;
    private static final double EXCHANGE_RATE_JPY_CAD = 0.01d;
    private static final Currency CAD = new Currency("CAD");
    private static final Currency USD = new Currency("USD");
    private static final Currency CHF = new Currency("CHF");
    private static final Currency JPY = new Currency("JPY");

    private CurrencyExchanger currencyExchanger;

    @Mock
    private ExchangeRateRepository exchangeRateRepository;

    @Before
    public void setUp() {
        willReturn(EXCHANGE_RATE_CAD_CAD).given(exchangeRateRepository).findByCurrencies(CAD, CAD);
        willReturn(EXCHANGE_RATE_USD_CAD).given(exchangeRateRepository).findByCurrencies(USD, CAD);
        willReturn(EXCHANGE_RATE_CHF_CAD).given(exchangeRateRepository).findByCurrencies(CHF, CAD);
        willReturn(EXCHANGE_RATE_JPY_CAD).given(exchangeRateRepository).findByCurrencies(JPY, CAD);
        currencyExchanger = new CurrencyExchanger(exchangeRateRepository);
    }

    @Test
    public void whenGetTotal_thenTotalIsComputedInCAD() {
        int amountCAD = 2;
        Money moneyCAD = new Money(amountCAD, CAD);
        int amountUSD = 3;
        Money moneyUSD = new Money(amountUSD, USD);
        int amountCHF = 4;
        Money moneyCHF = new Money(amountCHF, CHF);
        int amountJPY = 5;
        Money moneyJPY = new Money(amountJPY, JPY);
        List<Money> allCredits = Arrays.asList(moneyCAD, moneyUSD, moneyCHF, moneyJPY);
        double amountTotal = amountCAD * EXCHANGE_RATE_CAD_CAD +
                amountUSD * EXCHANGE_RATE_USD_CAD +
                amountCHF * EXCHANGE_RATE_CHF_CAD +
                amountJPY * EXCHANGE_RATE_JPY_CAD;
        Money expectedTotal = new Money(amountTotal);
        assertEquals(expectedTotal, currencyExchanger.getTotal(allCredits));
    }
}