package ca.ulaval.glo4002.trading.rest.report.parameters;

import ca.ulaval.glo4002.trading.application.report.ReportType;
import ca.ulaval.glo4002.trading.rest.report.exceptions.ReportUnsupportedTypeException;
import org.junit.Test;

import static org.junit.Assert.*;

public class QueryReportTypeTest {

    @Test
    public void givenValidReportType_whenCreate_thenQueryReportTypeCreated() {
        ReportType reportType = ReportType.DAILY;
        QueryReportType queryReportType = new QueryReportType(reportType.toString());
        assertEquals(reportType, queryReportType.getValue());
    }

    @Test(expected = ReportUnsupportedTypeException.class)
    public void givenInvalidReportType_whenCreate_thenThrows() {
        new QueryReportType("invalid");

    }
}