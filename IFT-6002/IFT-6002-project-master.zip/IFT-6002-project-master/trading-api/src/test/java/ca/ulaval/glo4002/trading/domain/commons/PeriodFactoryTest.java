package ca.ulaval.glo4002.trading.domain.commons;

import ca.ulaval.glo4002.trading.application.report.quarterly.Quarter;
import ca.ulaval.glo4002.trading.application.report.quarterly.QuarterType;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Year;

import static org.junit.Assert.*;

public class PeriodFactoryTest {

    private PeriodFactory periodFactory;

    @Before
    public void setUp() {
        periodFactory = new PeriodFactory();
    }

    @Test
    public void givenLocalDate_whenCreate_thenPeriodCreated() {
        LocalDate today = LocalDate.now();
        Period period = periodFactory.create(today);
        assertEquals(LocalDateTime.of(today, LocalTime.MIN), period.getBeginning());
        assertEquals(LocalDateTime.of(today, LocalTime.MAX), period.getEnding());
    }

    @Test
    public void givenQuarter_whenCreate_thenPeriodCreated() {
        Quarter quarter = new Quarter(Year.now(), QuarterType.Q1);
        Period period = periodFactory.create(quarter);
        assertEquals(LocalDateTime.of(quarter.getBeginning().toLocalDate(), LocalTime.MIN), period.getBeginning());
        assertEquals(LocalDateTime.of(quarter.getEnding().toLocalDate(), LocalTime.MAX), period.getEnding());
    }

    @Test
    public void givenUnfinishedQuarter_whenCreate_thenPeriodTruncated() {
        Quarter quarter = new Quarter(LocalDateTime.now());
        Period period = periodFactory.create(quarter);
        assertEquals(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX), period.getEnding());
    }

}