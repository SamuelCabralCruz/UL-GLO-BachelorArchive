package ca.ulaval.glo4002.trading.application.transaction;

import ca.ulaval.glo4002.trading.domain.account.Account;
import ca.ulaval.glo4002.trading.domain.account.AccountNumber;
import ca.ulaval.glo4002.trading.domain.account.AccountRepository;
import ca.ulaval.glo4002.trading.domain.account.transaction.Transaction;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionFactory;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionNumber;
import ca.ulaval.glo4002.trading.domain.account.transaction.TransactionType;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.StockNotFoundException;
import ca.ulaval.glo4002.trading.domain.account.transaction.exceptions.invalid.TransactionInvalidDateException;
import ca.ulaval.glo4002.trading.domain.commons.Money;
import ca.ulaval.glo4002.trading.domain.commons.exceptions.InvalidDateException;
import ca.ulaval.glo4002.trading.domain.market.Market;
import ca.ulaval.glo4002.trading.domain.market.MarketId;
import ca.ulaval.glo4002.trading.domain.market.MarketRepository;
import ca.ulaval.glo4002.trading.domain.stock.Stock;
import ca.ulaval.glo4002.trading.domain.stock.StockId;
import ca.ulaval.glo4002.trading.domain.stock.StockRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.mockito.BDDMockito.willReturn;
import static org.mockito.BDDMockito.willThrow;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class TransactionApplicationServiceTest {

    private static final UUID TRANSACTION_NUMBER_VALUE = UUID.randomUUID();
    private static final TransactionNumber TRANSACTION_NUMBER = new TransactionNumber(TRANSACTION_NUMBER_VALUE);
    private static final AccountNumber ACCOUNT_NUMBER = new AccountNumber("SN-909090");
    private static final Money FEES = new Money(0f);
    private static final Money PRICE = new Money(3453.2345f);
    private static final long QUANTITY = 223L;
    private static final String INVALID_MARKET = "INVALID_MARKET";
    private static final String INVALID_SYMBOL = "INVALID_SYMBOL";
    private static final String SYMBOL = "MSFT";
    private static final String MARKET_STRING = "NASDAQ";
    private static final MarketId MARKET_ID = new MarketId(MARKET_STRING);
    private static final LocalDateTime DATE = LocalDateTime.of(2018, 8, 10, 2, 18, 20, 142000000);
    private static final LocalDateTime INVALID_DATE = LocalDateTime.of(2020, 8, 10, 2, 18, 20, 142000000);
    private static final StockId STOCK_ID = new StockId(MARKET_STRING, SYMBOL);
    private static final StockId INVALID_STOCK_ID = new StockId(INVALID_MARKET, INVALID_SYMBOL);

    @Mock
    private TransactionDomainAssembler transactionDomainAssembler;

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private StockRepository stockRepository;

    @Mock
    private MarketRepository marketRepository;

    @Mock
    private TransactionFactory transactionFactory;

    @Mock
    private Account account;

    @Mock
    private Transaction transaction;

    @Mock
    private Stock stock;

    @Mock
    private Market market;

    private TransactionDTO transactionDTO = new TransactionDTO();
    private TransactionApplicationService transactionApplicationService;

    @Before
    public void setUp() throws InvalidDateException {
        transactionApplicationService = new TransactionApplicationService(
                accountRepository,
                stockRepository,
                marketRepository,
                transactionDomainAssembler,
                transactionFactory);
        willReturn(account).given(accountRepository).findByAccountNumber(ACCOUNT_NUMBER);
        willReturn(stock).given(stockRepository).findByStockIdAndDate(STOCK_ID, DATE);
        willThrow(new StockNotFoundException(INVALID_STOCK_ID)).given(stockRepository).findByStockIdAndDate(INVALID_STOCK_ID, DATE);
        willThrow(new InvalidDateException()).given(stockRepository).findByStockIdAndDate(STOCK_ID, INVALID_DATE);
        willReturn(PRICE).given(stock).getPrice();
        willReturn(STOCK_ID).given(transaction).getStockId();
        willReturn(transaction).given(transactionFactory).create(null, STOCK_ID, PRICE, QUANTITY,
                DATE, TransactionType.BUY);
        willReturn(transaction).given(transactionFactory).create(TRANSACTION_NUMBER, STOCK_ID, PRICE, QUANTITY,
                DATE, TransactionType.SELL);
        willReturn(market).given(marketRepository).findByMarketId(MARKET_ID);
        transactionDTO.setStockId(STOCK_ID);
        transactionDTO.setFees(FEES);
        transactionDTO.setQuantity(QUANTITY);
        transactionDTO.setDate(DATE);
        transactionDTO.setTransactionNumber(TRANSACTION_NUMBER);
        transactionDTO.setType(TransactionType.BUY);
        transactionDTO.setPrice(PRICE);
    }

    @Test(expected = StockNotFoundException.class)
    public void givenInvalidStock_whenPurchaseTransaction_thenThrows() {
        transactionDTO.setStockId(INVALID_STOCK_ID);
        transactionApplicationService.purchaseTransaction(ACCOUNT_NUMBER, transactionDTO);
    }

    @Test(expected = TransactionInvalidDateException.class)
    public void givenInvalidDate_whenCreatingTransaction_thenThrows() {
        transactionDTO.setDate(INVALID_DATE);
        transactionApplicationService.purchaseTransaction(ACCOUNT_NUMBER, transactionDTO);
    }

    @Test
    public void whenRetrievingTransaction_thenFindTransactionInAccount() {
        willReturn(transaction).given(account).getTransaction(TRANSACTION_NUMBER);
        transactionApplicationService.getByTransactionNumber(ACCOUNT_NUMBER, TRANSACTION_NUMBER);
        verify(account).getTransaction(TRANSACTION_NUMBER);
    }

    @Test
    public void whenPurchaseTransaction_thenAccountBuy() {
        transactionApplicationService.purchaseTransaction(ACCOUNT_NUMBER, transactionDTO);
        verify(account).buy(transaction);
    }

    @Test
    public void whenSellTransaction_thenAccountSell() {
        transactionDTO.setReferencedTransactionNumber(TRANSACTION_NUMBER);
        transactionDTO.setType(TransactionType.SELL);
        transactionApplicationService.sellTransaction(ACCOUNT_NUMBER, transactionDTO);
        verify(account).sell(transaction);
    }

    @Test
    public void whenPurchasingTransaction_thenCheckIfMarketIsClosed() {
        transactionApplicationService.purchaseTransaction(ACCOUNT_NUMBER, transactionDTO);
        verify(market).checkIfMarketIsClosed(transaction);
    }

    @Test
    public void whenSellingTransaction_thenCheckIfMarketIsClosed() {
        transactionApplicationService.sellTransaction(ACCOUNT_NUMBER, transactionDTO);
        verify(market).checkIfMarketIsClosed(transaction);
    }

}
