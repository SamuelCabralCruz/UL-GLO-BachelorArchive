# (c) Samuel Cabral Cruz 2018

# Usage:
# python3 generateWebSite.py -n 4 -o index.html

import os
import sys
import getopt
import random

CWD = os.getcwd()
PWD = os.path.join(CWD, "..")
EXTRACT_PATH = os.path.join(PWD, "extract")
TEXT_DATASET_PATH = os.path.join(EXTRACT_PATH, "descriptions.txt")
IMAGE_DATASET_PATH = os.path.join(EXTRACT_PATH, "images.txt")
DEV_PATH = os.path.join(PWD, "dev")
TEMPLATE_PATH = os.path.join(DEV_PATH, "index_template.html")
PLACEHOLDER = "[INSERT_CONTENT_HERE]"

def main(argv):
   nb_items, output_file = extractArgs(argv)
   print("Creating the content")
   items = createItems(nb_items)
   save(items, output_file)
   print("Output file is", output_file)

def extractArgs(argv):
    nb_items = ''
    output_file = 'index.html'
    try:
       opts, args = getopt.getopt(argv,"hn:o:",["nb_items=","output="])
    except getopt.GetoptError:
       print("generateWebSite.py -n <nb_items> -o <outputfile>")
       sys.exit(2)
    for opt, arg in opts:
       if opt == '-h':
           print("generateWebSite.py -n <nb_items> -o <outputfile>")
           sys.exit()
       elif opt in ("-n", "--nb-items"):
           nb_items = arg
       elif opt in ("-o", "--output"):
           output_file = arg
    return nb_items, output_file

def createItems(nb_items):
    texts, images = loadDatasets()
    len_texts = len(texts)
    len_images = len(images)
    items = list()
    for i in range(int(nb_items)):
        rand_nums = runIteration(len_texts, len_images)
        title = extractFrom(texts, rand_nums[0])
        source = extractFrom(images, rand_nums[1])
        description = extractFrom(texts, rand_nums[2])
        new_item = Item(title, source, description)
        items.append(new_item)
    return items

def loadDatasets():
    with open(TEXT_DATASET_PATH, 'r') as text_file:
        texts = [line.rstrip() for line in text_file]
    with open(IMAGE_DATASET_PATH, 'r') as image_file:
        images = [line.rstrip() for line in image_file]
    return texts, images

def runIteration(len_texts, len_images):
    title = random.randint(0, len_texts-1)
    source = random.randint(0, len_images-1)
    description_length = random.randint(1, 5)
    description = [random.randint(0, len_texts-1) for i in range(description_length)]
    return title, source, description

def extractFrom(source, index):
    if not isinstance(index, list):
        index = list([index])
    return " ".join([source[i] for i in index])

class Item:
    REPRESENTATION = '<div class="item">\n\t<h4>{}</h4>\n\t<img src={}>\n\t<p>{}</p>\n</div>'

    def __init__(self, title, source, description):
        self.title = title
        self.source = source
        self.description = description

    def __str__(self):
        return Item.REPRESENTATION.format(self.title, self.source, self.description)

def save(items, output_file):
    content = "\n".join([i.__str__() for i in items])
    indented_content = "\t\t\t\t" + '\t\t\t\t'.join(content.splitlines(True))
    with open(TEMPLATE_PATH, "r") as infile:
        original_html = infile.read()
    output_path = os.path.join(DEV_PATH, output_file)
    modified_html = original_html.replace(PLACEHOLDER, indented_content)
    with open(output_path, "w") as outfile:
        outfile.write(modified_html)

if __name__ == "__main__":
   main(sys.argv[1:])
