# GLO-3102
## Laboratoire 1
### Génération et extraction des descriptions
1. J'ai utilisé le résultat d'un [catipsum](http://www.catipsum.com/) aléatoire que j'ai copié/collé dans le ficheir catipsum.txt.
1. J'ai séparé le texte en phrases avec `sed`.
```{bash}
tr '\n' ' ' <  catipsum.txt | sed -e 's/[.] \s*/. \n/g' > descriptions.txt
```

### Extraction des images de chats
1. J'ai trouvé un [site](https://www.buzzfeed.com/expresident/best-cat-pictures) de photos de chats
1. Extrait l'ensemble des liens pointant vers des images avec un [script](./extract/extractImageDataSource.py) python à l'aide de BeautifulSoup.

### Générer un nouveau site web
- Lancer le [script](./generate/generateWebSite.py) python en spécifiant le nombre d'items
- Le script construira une liste d'items
- La représentation en format string d'un item sera la suivante:
    ```{html}
    <div class="item">
        <h4>{title}</h4>
        <img src={source}>
        <p>{text}</p>
    </div>
    ```
    > Dans cette représentation, les placeholders {title}, {source} et {text} seront remplacés par des valeurs choisies aléatoirement dans les banques de contenu.

- Enfin, le script produire une copie du fichier index_template.html dans lequel il ira remplacer [INSERT_CONTENT_HERE] par la combinaison des représentations textuelles de la liste d'items générés
