# (c) Samuel Cabral Cruz 2018

# References:
# https://docs.python.org/3.1/library/getopt.html
# https://www.tutorialspoint.com/python/python_command_line_arguments.htm
# https://stackoverflow.com/questions/24153519/
# https://www.crummy.com/software/BeautifulSoup/bs4/doc/
# https://stackoverflow.com/questions/40284002/
# https://stackoverflow.com/questions/899103/

# Usage:
# python3 extractImageDataSource.py -u https://www.buzzfeed.com/expresident/best-cat-pictures -c subbuzz__media-image -o images.txt

import os
import sys
import getopt

from bs4 import BeautifulSoup
import urllib.request

def main(argv):
   url, image_class_name, output_file = extractArgs(argv)
   print("Beginning of the Extraction")
   print("URL is", url)
   print("Image class name is", image_class_name)
   data_sources = extract(url, image_class_name)
   print("Output file is", output_file)
   save(data_sources, output_file)

def extractArgs(argv):
    url = ''
    image_class_name = ''
    output_file = ''
    try:
       opts, args = getopt.getopt(argv,"hu:c:o:",["url=","class=","output="])
    except getopt.GetoptError:
       print("extractImageDataSource.py -u <url> -c <image_class_name> -o <outputfile>")
       sys.exit(2)
    for opt, arg in opts:
       if opt == '-h':
           print("extractImageDataSource.py -u <url> -c <image_class_name> -o <outputfile>")
           sys.exit()
       elif opt in ("-u", "--url"):
           url = arg
       elif opt in ("-c", "--class"):
           image_class_name = arg
       elif opt in ("-o", "--output"):
           output_file = arg
    return url, image_class_name, output_file

def extract(url, image_class_name):
    soup = createSoup(url)
    images = soup.find_all('img', class_=image_class_name)
    data_sources = list()
    for i in images:
        data_sources.append((i["data-src"]))
    return data_sources

def createSoup(url):
    html_doc = extractHTML(url)
    soup = BeautifulSoup(html_doc, 'html.parser')
    return soup

def extractHTML(url):
    fp = urllib.request.urlopen(url)
    html_bytes = fp.read()
    html = html_bytes.decode('utf8')
    fp.close()
    return html

def save(data_sources, output_file):
    with open(output_file, 'w') as f:
        for item in data_sources:
            f.write("{}\n".format(item))

if __name__ == "__main__":
   main(sys.argv[1:])
