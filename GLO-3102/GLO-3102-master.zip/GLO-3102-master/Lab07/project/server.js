let express = require('express');
let bodyParser = require('body-parser');
let cors = require('cors');

users = require('./routes/users');
tasks = require('./routes/tasks');

let app = express();

const port = 8080;

let corsOptions = {
    origin: '*',
    methods: ['GET', 'PUT', 'POST', 'PATCH', 'DELETE', 'UPDATE'],
    credentials: true
};

app.use(bodyParser());
app.use(cors(corsOptions));

//post user
app.post('/users', users.createNewUser);

//post task
app.post('/:userId/tasks', tasks.createNewTask);

//get user tasks
app.get('/:userId/tasks', tasks.getAllTasks);

//put task
app.put('/:userId/tasks/:id', tasks.editTask);

//delete task
app.delete('/:userId/tasks/:id', tasks.deleteTask);

app.listen(port);
console.log('Listening on port '+ port +'...');
