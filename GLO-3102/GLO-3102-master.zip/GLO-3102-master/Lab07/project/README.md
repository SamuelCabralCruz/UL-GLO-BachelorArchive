## Build Setup

``` bash
# Installer les dépendances
npm install

# Lancer le serveur à l'adresse localhost:8080
npm start
```