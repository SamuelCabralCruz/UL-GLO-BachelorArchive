exports.usersList = [];
exports.userId = 0;