let taskId = 0;
let usersData = require('../data');

exports.createNewTask = function (req, res) {
    let taskName = req.body.name;
    let requestedUserId = req.params.userId;

    if (usersData.usersList[requestedUserId] === undefined) {
        res.send("User with id '" + requestedUserId + "' doesn't exist.");
    }

    usersData.usersList[req.params.userId].tasks.push({id: taskId, name: taskName});

    res.send({id: taskId, name: taskName});

    taskId++;
};

exports.getAllTasks = function (req, res) {
    let requestedUserId = req.params.userId;

    if (usersData.usersList[requestedUserId] === undefined) {
        res.send("User with id '" + requestedUserId + "' doesn't exist.");
    }

    res.send({tasks: usersData.usersList[requestedUserId].tasks});
};

exports.editTask = function (req, res) {
    let newTaskName = req.body.name;
    let currentTaskId = req.params.id;
    let requestedUserId = req.params.userId;

    if (usersData.usersList[requestedUserId] === undefined) {
        res.send("User with id '" + requestedUserId + "' doesn't exist.");
    }

    if (usersData.usersList[requestedUserId].tasks[currentTaskId] === undefined) {
        res.send("Task with id '" + requestedUserId + "' doesn't exist.");
    }

    usersData.usersList[requestedUserId].tasks[currentTaskId].name = newTaskName;
    res.send({id: currentTaskId, name: newTaskName});
};

exports.deleteTask = function (req, res) {
    let currentTaskId = req.params.id;
    let requestedUserId = req.params.userId;

    if (usersData.usersList[requestedUserId] === undefined) {
        res.send("User with id '" + requestedUserId + "' doesn't exist.");
    }

    if (usersData.usersList[requestedUserId].tasks[currentTaskId] === undefined) {
        res.send("Task with id '" + requestedUserId + "' doesn't exist.");
    }

    for (let i = 0; i < usersData.usersList[requestedUserId].tasks.length; i++) {
        if (Number(usersData.usersList[requestedUserId].tasks[i].id) === Number(currentTaskId)) {
            usersData.usersList[requestedUserId].tasks.splice(i, 1);
            res.send();
        }
    }
};