let usersData = require('../data');

exports.createNewUser = function (req, res) {
    usersData.usersList.push({id: usersData.userId, tasks: []});

    res.send({id: usersData.userId});

    usersData.userId++;
};