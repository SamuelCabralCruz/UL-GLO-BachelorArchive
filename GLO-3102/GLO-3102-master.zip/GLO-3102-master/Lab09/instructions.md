# GLO-3102, Laboratoire 9

## Build Setup

## Installer les dépendances

`npm install`

## Lancer le serveur à l'adresse localhost:8080

`npm build && npm run start`

## Ouvrir une premiere fenetre à l'adresse localhost:8080

## Ouvrir une seconde fenetre à l'adresse localhost:8080

## Entrer son unsername et un message dans n'importe quelle fenetres pour communiquer avec l'autre utilisateur



