# GLO-3102, Laboratoire 8

## Build Setup

## Installer les dépendances

`npm install`

## Lancer le serveur à l'adresse localhost:8080

`npm build && npm run start`

## Workflow

Un user//password existe par défaut:
- User: admin-default
- Password: admin

Il est possible de créer un nouveau user en suivant les liens indiqués depuis la page de login. L'application est plutôt intuitive et les liens sont faits, simplement naviguer à l'addresse suivante:
- [http://localhost:8080](http://localhost:8080)
