let express = require('express');
let bodyParser = require('body-parser');
let cors = require('cors');

auth = require('./routes/auth');

let app = express();

const port = 8080;

let corsOptions = {
    origin: '*',
    methods: ['GET', 'PUT', 'POST', 'PATCH', 'DELETE', 'UPDATE'],
    credentials: true
};
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(cors(corsOptions));

app.get('/', function (req, res) {
    res.redirect('/login', 301);
});

app.get('/login', function (req, res) {
    res.sendfile('./login.html');
});
app.post('/login', auth.login);

app.get('/users', function (req, res) {
    res.sendfile('./users.html');
});
app.post('/users', auth.createNewUser);

app.get('/userprofile', auth.userprofile);

app.listen(port);
console.log('Listening on port ' + port + '...');
