let usersData = require('../data');
const uuidv4 = require('uuid/v4');
const Cookies = require('js-cookie');

let cookie_token_name = 'tokannnnnnn';

exports.login = function (req, res) {
    const name = req.body.name;
    const password = req.body.password;

    const idx1 = usersData.names.indexOf(name);
    const idx2 = usersData.passwords.indexOf(password);
    if (idx1 === idx2 && idx1 !== -1) {  // si existe, redirect et token savé en cookie

        res.cookie(
            cookie_token_name,
            usersData.tokens[idx1],
            {maxAge: 900000}
        ).redirect(200, '/userprofile');

    } else {
        res.redirect(401, '/login');
    }
};

exports.userprofile = function (req, res) {
    const re = /(?<==).*$/;
    const token = re.exec(req.headers['cookie']);

    // check si cookie présent
    const idx3 = usersData.tokens.indexOf(token);

    if (idx3 === -1) {
        // oui: envoyer au server pour être validé et avoir profil
        res.status(200).sendfile('./userprofile.html');
    } else {
        // non: redirect vers login
        res.status(401).sendfile('./login.html');
    }
};

exports.createNewUser = function (req, res) {
    const newToken = uuidv4();
    usersData.tokens.push(newToken);
    usersData.names.push(req.body.name);
    usersData.passwords.push(req.body.password);

    res.redirect(201, '/login');
};
