# GLO-3102, Laboratoire 10

## Build Setup

## Installer les dépendances

`npm install`

## Lancer le serveur à l'adresse localhost:8080

`npm build && npm run start`



