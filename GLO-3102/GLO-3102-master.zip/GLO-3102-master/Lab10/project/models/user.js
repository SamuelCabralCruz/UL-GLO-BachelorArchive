const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    tasks: []
});

const User = mongoose.model('User', userSchema);

exports.schema = userSchema;
exports.model = User;
