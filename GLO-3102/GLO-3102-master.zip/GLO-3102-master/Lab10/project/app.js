const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const corsOptions = {
    origin: '*',
    methods: ['GET', 'PUT', 'POST', 'PATCH', 'DELETE', 'UPDATE'],
    credentials: true
};
const uuidv4 = require('uuid/v4');

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log("we're connected!");
});

const User = require('./models/user.js').model;

const port = process.env.PORT || 8080;
const app = express();

app.use(bodyParser.json());
app.use(cors(corsOptions));


app.use(function (error, req, res, next) {
    if (error instanceof SyntaxError) {
        res.status(400).send({
            errorCode: 'PARSE_ERROR',
            message: 'Arguments could not be parsed, make sure request is valid.'
        });
    } else {
        res.status(500).send('Something broke server-side.', error);
    }
});

app.get('/', function (req, res) {
    res.send('Welcome to Lab 10 API.');
});

app.post('/users', function (req, res) {
    const userId = addUser();

    return res.status(200).send(JSON.stringify({'id': userId, 'tasks': []}));
});

app.get('/:userId/tasks', function (req, res) {
    const userId = req.params.userId;

    userExists(userId, res, function () {
        getUserTasks(userId, res);
    });
});

app.post('/:userId/tasks', function (req, res) {
    const userId = req.params.userId;
    const taskName = req.body.name;

    userExists(userId, res, function () {
        addTask(userId, taskName, res);
    });
});

app.put('/:userId/tasks/:taskId', function (req, res) {
    const taskId = req.params.taskId;
    const userId = req.params.userId;
    const newTaskName = req.body.name;

    userExists(userId, res, function () {
        console.log("User Exists!");
        taskExists(userId, taskId, res, function () {
            console.log("Task Exists!");
            editTask(userId, taskId, newTaskName, res);
        });
    });
});

app.delete('/:userId/tasks/:taskId', function (req, res) {
    const taskId = req.params.taskId;
    const userId = req.params.userId;

    userExists(userId, res, function () {
        taskExists(userId, taskId, res, function () {
            deleteTask(userId, taskId, res);
        });
    });
});

app.listen(port, function () {
    console.log('Server listening.');
});

function userExists(userId, res, callback) {
    User.findById(userId, function (err, user) {
        if (!err) {
            if (!user) {
                return res.status(400).send('User with id \'' + userId + '\' doesn\'t exist.');
            }
        } else {
            return res.status(500);
        }
    });

    callback();
}

function taskExists(userId, taskId, res, callback) {
    User.findById(userId, function (err, user) {
        if (!err) {
            if (user) {
                // let isTaskInArray = false;
                //
                // user.tasks.forEach(function (task) {
                //     if (task.id === taskId) {
                //         isTaskInArray = true;
                //     }
                // });

                let isTaskInArray = false;
                for (let i = 0; i < user.tasks.length; i++) {
                    const task = user.tasks[i];
                    if (task.id === taskId) {
                        isTaskInArray = true;
                    }
                }

                if (!isTaskInArray) {
                    return res.status(400).send('Task with id \'' + taskId + '\' doesn\'t exist.');
                }
            }
        } else {
            return res.status(500);
        }
    });

    callback();
}

function addUser() {
    // Instanciation du modèle en question.
    const newUser = new User({tasks: []});
    newUser.save(function (err) {
        if (err) {
            console.log('Save error');
        }
    });

    return newUser._id;
}

function getUserTasks(userId, res) {
    //On trouve le bon user
    User.findById(userId, function (err, user) {
        if (!err) {
            if (user) {
                const tasks = user.tasks;
                return res.status(200).send(JSON.stringify({'tasks': tasks}));
            }
        }
        return [];
    });
}

function addTask(userId, taskName, res) {
    //On trouve le bon user
    User.findById(userId, function (err, user) {
        if (!err) {
            if (user) {
                const taskId = uuidv4();
                const newTask = {id: taskId, name: taskName};

                user.tasks.push(newTask);

                user.save(function (err) {
                    if (err) {
                        console.log('Save error');
                    }
                });

                return res.status(200).send(JSON.stringify(newTask));
            }
        }
    });
}

function editTask(userId, taskId, newTaskName, res) {
    let newTasksArray = [];
    //On trouve le bon user
    User.findById(userId, function (err, user) {
        if (!err) {
            if (user) {
                let taskIndex = -1;
                user.tasks.forEach(function (task, index) {
                    if (task.id === taskId) {
                        taskIndex = index;
                        user.tasks[index].name = newTaskName;
                        newTasksArray = user.tasks;
                    }
                });

                User.updateOne({_id: user._id}, {
                    tasks: newTasksArray
                }, function (err) {
                    if (err) {
                        console.log('Update error');
                    }
                });

                return res.status(200).send(JSON.stringify(user.tasks[taskIndex]));
            }
        }
    });
}

function deleteTask(userId, taskId, res) {
    //On trouve le bon user
    User.findById(userId, function (err, user) {
        if (!err) {
            if (user) {
                user.tasks.forEach(function (task, index) {
                    if (task.id === taskId) {
                        user.tasks.splice(index, 1);
                    }
                });

                user.save(function (err) {
                    if (err) {
                        console.log('Save error');
                    }
                });

                return res.sendStatus(204);
            }
        }
    });
}