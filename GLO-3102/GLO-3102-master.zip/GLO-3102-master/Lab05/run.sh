cd project
npm install
npm run build
npm run dev
