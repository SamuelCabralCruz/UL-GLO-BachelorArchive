<template>
  <div class="message-body">
    <div class="field">
      <div class="field">
        <p class="control has-icons-left">
          <textarea class="input textArea" placeholder="Task" v-model="taskDescription"></textarea>
          <span class="icon is-small is-left"><i class="fa fa-sticky-note"></i></span>
        </p>
      </div>
    </div>
    <a v-on:click="saveEdit" class="button is-primary btn-save-task">Save Changes</a>
    <a v-on:click="deleteTask" class="button btn-delete-task">Delete</a>
  </div>
</template>

<script>
  export default {
    name: "Task",
    props: {
      "taskIndex": {
        type: Number,
      },
      "userId": {
        type: String,
      },
      "taskId": {
        type: String,
      },
      "taskName": {
        type: String,
      }
    },
    data() {
      return {
        taskDescription: this.taskName,
      }
    },
    methods: {
      saveEdit() {
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks/' + this.taskId, {
          method: 'put',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({"name": this.taskDescription})
        })
          .then(response => response.json());
        console.log("Task Saved - Task Id: " + this.taskId);
      },
      deleteTask() {
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks/' + this.taskId, {method: 'delete'})
          .then(response =>
            setTimeout(this.emitDeletionEvent, 100)
          );
      },
      emitDeletionEvent() {
        this.$emit("task-deleted", this.taskId);
        console.log("Task Deleted - Task Id: " + this.taskId);
      }
    }
  }
</script>
