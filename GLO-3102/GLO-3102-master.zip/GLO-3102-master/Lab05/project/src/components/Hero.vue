<template>
  <section class="hero is-primary">
    <div class="hero-head">
      <nav class="main-nav navbar">
        <div class="container">
          <div class="navbar-start">
            <p class="navbar-item">&lbrace;</p>
            <p class="navbar-item">Authors:</p>
            <a class="navbar-item" href="https://github.com/guillaume-chevalier">Guillaume Chevalier</a>
            <a class="navbar-item" href="https://github.com/SamuelCabralCruz">Samuel Cabral Cruz</a>
            <p class="navbar-item">&rbrace;</p>
          </div>
          <div class="navbar-end navbar-menu">
            <p class="navbar-item">&lbrace;</p>
            <p class="navbar-item">Resources:</p>
            <a class="navbar-item" href="http://bulma.io">Bulma</a>
            <a class="navbar-item" href="https://jenil.github.io/bulmaswatch/">Bulmaswatch</a>
            <a class="navbar-item" href="http://fontawesome.io/">Font Awesome</a>
            <a class="navbar-item" href="https://fonts.google.com/">Google Fonts</a>
            <p class="navbar-item">&rbrace;</p>
          </div>
        </div>
      </nav>
    </div>
    <div class="hero-body">
      <div class="container">
        <h1 class="title">!Not Google Keep.</h1>
        <p class="subtitle">Def your fav TODO app by now.</p>
      </div>
    </div>
  </section>
</template>

<script>
  export default {
    name: "Hero"
  }
</script>
