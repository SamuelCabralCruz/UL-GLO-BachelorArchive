<template>
  <div class="field" @user-id-changed="updateDisplay">
    <div class="control has-icons-left">
      <button v-on:click="loadUserTasks" id="btn-load-user"
              class="button is-primary is-fullwidth is-outlined">
        Load user tasks
      </button>
      <span class="icon is-small is-left"><i class="fa fa-download"></i></span>
    </div>
    <user-tasks v-bind:userId="userId" v-bind:tasks="tasks" v-bind:style="{ display: displayUserTasks}"></user-tasks>
  </div>
</template>

<script>
  import UserTasks from './UserTasks'

  export default {
    name: "LoadTasksButton",
    props: {
      userId: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        displayUserTasks: "none",
        tasks: null,
        isValidId: false,
      }
    },
    components: {
      "user-tasks": UserTasks,
    },
    methods: {
      loadUserTasks() {
        if (this.isValidId) {
          this.$emit("load-user-tasks", "");
        }
        this.updateDisplay();
      },
      updateDisplay() {
        if (this.isValidId) {
          this.displayUserTasks = "block";
        } else {
          this.displayUserTasks = "none";
        }
      }
    },
    watch: {
      userId(newValue) {
        this.isValidId = newValue !== "";
        this.displayUserTasks = "none";
      }
    }
  }
</script>
