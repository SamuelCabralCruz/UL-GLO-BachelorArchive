<template>
  <footer class="footer">
    <div class="container">
      <div class="content">
        <p class="subtitle">
          2018 ©
          <a href="https://github.com/guillaume-chevalier">Guillaume Chevalier</a>
          and
          <a href="https://github.com/SamuelCabralCruz">Samuel Cabral Cruz</a>
          and
          <a href="https://github.com/Emile05">Émile Bernard</a>
        </p>
        <p>
          CSS Style from <a href="http://bulma.io">Bulma</a>.<br>
          CSS Bulma theme from <a href="https://jenil.github.io/bulmaswatch/">Bulmaswatch</a>.<br>
          Icons from <a href="http://fontawesome.io/">Font Awesome</a>.<br>
          Web Fonts from <a href="https://fonts.google.com/">Google Fonts</a>.<br>
        </p>
        <p>
          Dricker du kaffe?
        </p>
      </div>
    </div>
  </footer>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>
