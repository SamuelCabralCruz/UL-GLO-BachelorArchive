<template>
  <div id="user-tasks-container" @load-user-tasks="retrieveUserTasks">
    <hr>
    <h2 class="subtitle">Edit them notes.</h2>
    <div class="control has-icons-left">
      <button v-on:click="createNewTask" id="btn-create-task" class="button is-primary is-fullwidth">
        Create new task
      </button>
      <span class="icon is-small is-left"><i class="fa fa-plus"></i></span>
    </div>
    <nav class="panel">
      <task v-for="(item, index) in tasks"
            v-bind:key=index
            v-bind:userId="userId"
            v-bind:taskId="item.id"
            v-bind:taskName="item.name" @task-deleted="deleteById">
      </task>
    </nav>
  </div>
</template>

<script>
  import Task from './Task'

  export default {
    name: "UserTasks",
    components: {
      "task": Task,
    },
    props: {
      "userId": {
        type: String,
      },
    },
    data() {
      return {
        tasks: [],
      };
    },
    methods: {
      retrieveUserTasks() {
        console.log("Loading User Tasks for UserId: " + this.userId);
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks', {method: 'get'})
          .then(response => response.json())
          .then(response => this.setUserTasks(response.tasks));
      },
      setUserTasks(tasks) {
        console.log("User Tasks Retrieved");
        this.tasks = tasks;
      },
      createNewTask() {
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks', {
          method: 'post',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({"name": "A new task."})
        })
          .then(response =>
            setTimeout(this.retrieveUserTasks, 250))
          .then(
            this.retrieveUserTasks()
          );
        console.log("Created a new task");
      },
      deleteById(taskId) {
        let index = 0;
        for (index in this.tasks) {
          let task = this.tasks[index];
          if (task.id === taskId) {
            this.deleteByIndex(index);
            break;
          }
          index++;
        }
      },
      deleteByIndex(index) {
        this.tasks.splice(index);
        this.retrieveUserTasks();
      }
    },
    watch: {
      userId(newValue) {
        this.retrieveUserTasks();
      }
    }
  }
</script>
