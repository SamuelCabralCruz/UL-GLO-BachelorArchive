<template>
  <section class="section">
    <div class="container">
      <section class="section">
        <h2 class="subtitle">Create a new user or use an ID</h2>
        <p>Creating a new user will fill the ID field. You can directly change the ID field to use a (or another)
          user if you already created one.</p>
        <br>
        <div class="columns">
          <div class="column">
            <create-user-button></create-user-button>
          </div>
        </div>
        <hr>
      </section>
    </div>
  </section>
</template>

<script>
  import CreateUserButton from './CreateUserButton'

  export default {
    name: "MainContainer",
    components: {
      "create-user-button": CreateUserButton,
    },
  }
</script>
