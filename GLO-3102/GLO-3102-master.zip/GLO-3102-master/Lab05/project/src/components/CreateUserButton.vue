<template>
  <div class="field">
    <div class="control has-icons-left">
      <button v-on:click="createUser" id="btn-create-user" class="button is-primary is-fullwidth is-outlined">
        Create new user
      </button>
      <span class="icon is-small is-left"><i class="fa fa-plus"></i></span>
    </div>
    <br>
    <user-id-field v-bind:userId="userId"></user-id-field>
  </div>
</template>

<script>
  import UserIdField from './UserIdField'

  export default {
    name: "CreateUserButton",
    components: {
      "user-id-field": UserIdField,
    },
    data() {
      return {
        userId: "",
      };
    },
    methods: {
      createUser() {
        fetch('https://glo3102lab4.herokuapp.com/users', {method: 'post'})
          .then(response => response.json())
          .then(response => this.setUserId(response.id))
      },
      setUserId(userId) {
        this.userId = userId;
        console.log("Creating New User:" + userId);
      },
    },
  }
</script>
