<template>
  <div class="field">
    <p class="control has-icons-left">
      <input id="load-user" class="input" type="text" placeholder="ID" v-model="userIdData">
      <span class="icon is-small is-left"><i class="fa fa-id-badge"></i></span>
    </p>
    <br>
    <load-tasks-button v-bind:userId="userIdData"></load-tasks-button>
  </div>
</template>

<script>
  import LoadTasksButton from './LoadTasksButton'

  export default {
    name: "UserIdField",
    components: {
      "load-tasks-button": LoadTasksButton,
    },
    props: {
      userId: {
        type: String,
        required: true
      }
    },
    data(){
      return{
        userIdData: ""
      }
    },
    watch: {
      userId(newValue) {
        this.userIdData = newValue;
      }
    }
  }
</script>
