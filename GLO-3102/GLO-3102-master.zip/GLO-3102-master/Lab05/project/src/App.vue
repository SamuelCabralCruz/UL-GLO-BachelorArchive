<template>
  <div id="app">
    <hero></hero>
    <main-container></main-container>
    <footer-content></footer-content>
  </div>
</template>

<style>
  html, body {
    height: 100%;
    width: 100%;
    font-family: "Share Tech", Helvetica, sans-serif;
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: "Share Tech Mono", Helvetica, sans-serif;
  }
</style>

<script>
  import Hero from './components/Hero';
  import MainContainer from './components/MainContainer'
  import Footer from './components/Footer'

  export default {
    name: 'app',
    components: {
      'hero': Hero,
      'main-container': MainContainer,
      'footer-content': Footer,
    },
  };
</script>
