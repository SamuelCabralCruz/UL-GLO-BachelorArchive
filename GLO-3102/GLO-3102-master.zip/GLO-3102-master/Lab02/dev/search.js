const MAXIMUM_NUMBER_OF_ITEMS_DISPLAYED = 10;
const NUMBER_OF_POKEMONS = POKEMONS.length;

window.addEventListener("keydown", keyDownSearchBar, false);
window.addEventListener("click", clearSearchOnBlur, false);

function keyDownSearchBar(e) {
    let active_element_id = document.activeElement.id;
    let search_bar_active = false;
    let pokemon_preview_active = false;
    if (active_element_id === "search-bar") {
        search_bar_active = true;
    } else if (active_element_id.indexOf("pokemon_info") > -1) {
        pokemon_preview_active = true;
    }
    if (search_bar_active || pokemon_preview_active) {
        let key = e.key;
        let shift_key = e.shiftKey;
        if (key === "Tab") {
            e.preventDefault();
            e.stopPropagation();
            if (shift_key) {
                autoCompletePrevious();
            } else {
                autoCompleteNext();
            }
        } else if (key === "ArrowDown") {
            e.preventDefault();
            e.stopPropagation();
            autoCompleteNext();
        } else if (key === "ArrowUp") {
            e.preventDefault();
            e.stopPropagation();
            autoCompletePrevious();
        } else if (key === "Enter") {
            if (pokemon_preview_active) {
                let no = active_element_id.replace("pokemon_info_", "");
                selectCurrentPokemon(no);
            } else {
                selectCurrentPokemon(null);
            }
        } else if (key === "Escape") {
            e.preventDefault();
            clearSearch();
        }
    }
}

var loaded = new Set([]);
var visible = new Set([]);

function inSearch() {
    resetPreview();
    let searched_value = document.getElementById("search-bar").value;
    let search_section = document.getElementById("search-preview");
    if (searched_value === "") {
        for (let i = 0; i < MAXIMUM_NUMBER_OF_ITEMS_DISPLAYED; i++) {
            displayPreviewPokemon(POKEMONS[i], search_section);
        }
        if (MAXIMUM_NUMBER_OF_ITEMS_DISPLAYED < NUMBER_OF_POKEMONS) {
            addEllipsis(search_section);
        }
    } else {
        for (let i = 0; i < NUMBER_OF_POKEMONS; i++) {
            let pokemon_data = POKEMONS[i];
            if (matchPokemon(pokemon_data, searched_value)) {
                if (visible.size === MAXIMUM_NUMBER_OF_ITEMS_DISPLAYED) {
                    addEllipsis(search_section);
                    break;
                }
                displayPreviewPokemon(pokemon_data, search_section);
            }
        }
        if (visible.size === 0) {
            addNoMatch(search_section);
        }
    }
}

function resetPreview() {
    function hide(pokemon_id) {
        document.getElementById("pokemon_" + pokemon_id).style.display = "none";
    }

    visible.forEach(hide);
    visible.clear();
    hideEllipsis();
    hideNoMatch();
    iterator = undefined;
}

function displayPreviewPokemon(pokemon_data, search_section) {
    let no = pokemon_data.no;
    if (!loaded.has(no)) {
        let pokemon = document.createElement("div");
        pokemon.className = "pokemon";
        loaded.add(no);
        pokemon.id = 'pokemon_' + no;
        pokemon.innerHTML = "<a href='javascript:selectCurrentPokemon(" + no + ")' " +
            "id='pokemon_info_" + no + "'>" +
            pokemonToString(pokemon_data) + "</a>";
        search_section.appendChild(pokemon);
    } else {
        let loaded_div = document.getElementById("pokemon_" + no);
        if (loaded_div) {
            loaded_div.style.display = "block";
        }
    }
    visible.add(no);
}

function pokemonToString(pokemon_data) {
    return pokemon_data.name + " #" + pokemon_data.no;
}

var add_more_created = false;

function addEllipsis(parent) {
    if (!add_more_created) {
        let add_more = document.createElement("div");
        add_more.className = "pokemon";
        add_more.id = "addEllipsis";
        add_more.innerHTML = "<a href='javascript:void(0)'> ... </a>";
        parent.appendChild(add_more);
        add_more_created = true;
    } else {
        let add_more = document.getElementById("addEllipsis");
        add_more.parentNode.removeChild(add_more);
        parent.appendChild(add_more);
        document.getElementById("addEllipsis").style.display = "block";
    }
}

function hideEllipsis() {
    if (add_more_created) {
        document.getElementById("addEllipsis").style.display = "none";
    }
}

var no_match_created = false;

function addNoMatch(parent) {
    if (!no_match_created) {
        let no_match = document.createElement("div");
        no_match.className = "pokemon";
        no_match.id = "noMatch";
        no_match.innerHTML = "<a href='javascript:void(0)'> Sorry, No Match Found </a>";
        parent.appendChild(no_match);
        no_match_created = true;
    } else {
        let no_match = document.getElementById("noMatch");
        no_match.parentNode.removeChild(no_match);
        parent.appendChild(no_match);
        document.getElementById("noMatch").style.display = "block";
    }
}

function hideNoMatch() {
    if (no_match_created) {
        document.getElementById("noMatch").style.display = "none";
    }
}

function matchPokemon(pokemon_data, searched_value) {
    let searchable_content_lower = getSearchableContent(pokemon_data).toLowerCase();
    let index = searchable_content_lower.indexOf(
        searched_value.toLowerCase()
    );
    return index !== -1;
}

function getSearchableContent(pokemon_data) {
    let no = pokemon_data.no;
    let name = pokemon_data.name;
    let cases = [];
    cases.push("#" + no);
    cases.push("#" + no + " " + name);
    cases.push(name + " #" + no);
    cases.push(no + "#");
    cases.push(no + "# " + name);
    cases.push(name + " " + no + "#");
    cases.push(name + "#" + no);
    cases.push("#no" + name);
    cases.push(name + no + "#");
    cases.push(no + "#" + name);
    return cases.join(" ");
}

function selectCurrentPokemon(id) {
    if (id == null) {
        id = Array.from(visible.values())[0];
    }
    showSelectedPokemon(id);
}

var iterator = undefined;
var last_operation = "";

function autoCompleteNext() {
    if (typeof(iterator) === "undefined") {
        iterator = -1;
    }
    if (iterator < MAXIMUM_NUMBER_OF_ITEMS_DISPLAYED - 1) {
        iterator++;
        let selected_pokemon = Array.from(visible.values())[iterator];
        let pokemon_data = POKEMONS[selected_pokemon - 1];
        let search_bar = document.getElementById("search-bar");
        search_bar.value = pokemonToString(pokemon_data);
        let pokemon_preview_element = document.getElementById("pokemon_info_" + selected_pokemon);
        pokemon_preview_element.focus();
        last_operation = "next";
    } else {
        iterator = undefined;
    }
}

function autoCompletePrevious() {
    if (typeof(iterator) === "undefined") {
        iterator = 10;
    }
    if (iterator > 0) {
        iterator--;
        let selected_pokemon = Array.from(visible.values())[iterator];
        let pokemon_data = POKEMONS[selected_pokemon - 1];
        let search_bar = document.getElementById("search-bar");
        search_bar.value = pokemonToString(pokemon_data);
        let pokemon_preview_element = document.getElementById("pokemon_info_" + selected_pokemon);
        pokemon_preview_element.focus();
        last_operation = "previous";
    } else {
        iterator = undefined;
    }
}

function showSelectedPokemon(no) {
    clearResult();
    if (no !== null) {
        let pokemon_data = POKEMONS[no - 1];
        showResult(pokemonToString(pokemon_data),
            pokemon_data.picture,
            pokemon_data.info);
    } else {
        showNoMatch();
    }
    clearSearch();
}

function showNoMatch() {
    showResult("Sorry, No Match Found",
        "https://wallpaper-gallery.net/images/sad-face-images/sad-face-images-17.png",
        "github.com");
}

function showResult(title_content, picture_content, info_content) {
    let title = document.createElement("h3");
    title.innerText = title_content;
    title.id = "the-selected-pokemon-title";

    let picture = document.createElement("img");
    picture.setAttribute("src", picture_content);
    picture.id = "the-selected-pokemon-picture";

    let source = document.createElement("p");
    source.innerHTML = "Source: <u>" + info_content + "</u>";
    source.id = "the-selected-pokemon-source";

    let container = document.createElement("div");
    container.id = "the-selected-pokemon-container";
    container.appendChild(title);
    container.appendChild(picture);
    container.appendChild(source);

    let wrapper_href = document.createElement("a");
    wrapper_href.id = "the-selected-pokemon-href";
    wrapper_href.href = info_content;
    wrapper_href.rel = "noopener noreferrer";
    wrapper_href.target = "_blank";
    wrapper_href.appendChild(container);

    let search_results = document.getElementById("search-results");
    search_results.appendChild(wrapper_href);
}

function clearResult() {
    let wrapper_href = document.getElementById("the-selected-pokemon-href");
    if (wrapper_href !== null) {
        wrapper_href.parentNode.removeChild(wrapper_href);
    }
}

function clearSearch() {
    let search_bar = document.getElementById("search-bar");
    search_bar.value = "";
    resetPreview();
    search_bar.blur();
}

function clearSearchOnBlur() {
    let active_element_id = document.activeElement.id;
    if (active_element_id !== "search-bar" && visible.size > 0) {
        clearSearch();
    }
}