# (c) Samuel Cabral Cruz 2018

# References:
# https://docs.python.org/3.1/library/getopt.html
# https://www.tutorialspoint.com/python/python_command_line_arguments.htm
# https://stackoverflow.com/questions/24153519/
# https://www.crummy.com/software/BeautifulSoup/bs4/doc/
# https://stackoverflow.com/questions/40284002/
# https://stackoverflow.com/questions/899103/

# Usage:
# python3 extractListOfPokemons.py -u https://en.wikipedia.org/wiki/List_of_Pok%C3%A9mon

import os
import sys
import json
import getopt

from bs4 import BeautifulSoup
import urllib.request

def main(argv):
   url = 'https://en.wikipedia.org/wiki/List_of_Pok%C3%A9mon'
   output_file = 'pokemons.json'
   print("Beginning of the Extraction")
   print("URL is", url)
   pokemons = extract(url)
   print("OUTPUT_FILE is", output_file)
   save(pokemons, output_file)

def extract(url):
    soup = createSoup(url)
    tables = soup.find_all('table')
    myTable = ''
    for tab in tables:
        for children in tab.contents:
            if children.name == "caption":
                #and children.string == "List of Pokémon species names by generation":
                for string in children.strings:
                    if string.find("List of Pokémon species names by generation"):
                        myTable = tab
    pokemons = list()
    trs = myTable.find_all('tr')
    for tr in trs:
        tds = tr.find_all('td')
        no = None
        name = None
        for td in tds:
            try:
                no = int(td.string)
            except:
                pass
            if td.contents[0].name == "a":
                name = td.contents[0].string
            if no and name:
                pokemons.append(Pokemon(no, name))
                no = None
                name = None
    return pokemons

def createSoup(url):
    html_doc = extractHTML(url)
    soup = BeautifulSoup(html_doc, 'html.parser')
    return soup

def extractHTML(url):
    fp = urllib.request.urlopen(url)
    html_bytes = fp.read()
    html = html_bytes.decode('utf8')
    fp.close()
    return html

class Pokemon:
    def __init__(self, no, name):
        self.no = no
        if name[-1] == '\u2642':
            name = name[:-1] + "-male"
        elif name[-1] == '\u2640':
            name = name[:-1] + "-female"
        self.name = name
        self.info = "https://www.pokemon.com/us/pokedex/{}".format(name.lower())
        self.picture = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/{num:03d}.png".format(num=no)

    def __str__(self):
        return "Pokemon no {0:>3}: {1:>15} \t Pokedex: {2:>50} \t Picture: {3}".format(self.no, self.name, self.info, self.picture)

    def getData(self):
        data = {}
        data["no"] = self.no
        data["name"] = self.name
        data["info"] = self.info
        data["picture"] = self.picture
        return data

    def __lt__(self, other):
        return self.no < other.no

    def __eq__(self, other):
        return self.no == other.no

def save(pokemons, output_file):
    pokemons_data = list()
    for pokemon in sorted(pokemons):
        pokemons_data.append(pokemon.getData())
    output_path = os.path.join(os.getcwd(), "..", "dev", output_file)
    with open(output_path, 'w') as f:
        f.write(json.dumps(pokemons_data, indent=4,  ensure_ascii=False))

if __name__ == "__main__":
   main(sys.argv[1:])
