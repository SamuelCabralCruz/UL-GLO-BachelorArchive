let tasks = [];

function createUser() {
    // do everything.
    fetch('https://glo3102lab4.herokuapp.com/users', {method: 'post'})
        .then(response => response.json())
        .then(response => setUser(response.id))
        .then(loadUserTasks);
}

function setUser(userId) {
    console.log(userId);

    // set id in textbox
    let loadUser = document.getElementById("load-user");
    loadUser.value = userId;
}

function loadUserTasks() {
    clearPanel();

    btnCreateTask.style.visibility = "visible";

    // get user id from box
    let userId = document.getElementById("load-user").value;
    console.log(userId);

    // now really fetch and create all user's tasks
    fetch('https://glo3102lab4.herokuapp.com/' + userId + '/tasks', {method: 'get'})
        .then(res => res.json())
        //.then(res => console.log(res))
        .then(res => createTasksObjects(res.tasks, userId))
}

function createTasksObjects(restasks, userId) {
    for (let i in restasks) {
        let taskk = new Task(userId, restasks[i].id, restasks[i].name);
    }
}

function clearPanel() {
    let panel = document.getElementsByClassName("panel")[0];
    panel.innerHTML = '';
}

class Task {
    constructor(userId, taskId, name) {
        this.userId = userId;
        this.taskId = taskId;
        this.name = name;
        this.create();
    }

    create() {

        let divField = document.createElement("div");
        divField.className = "field";
        divField.innerHTML = '   <div class="field">\n' +
            '                        <p class="control has-icons-left">\n' +
            '                            <textArea id="text-' + this.taskId + '" class="input textArea" placeholder="Task"></textArea>\n' +
            '                            <span class="icon is-small is-left"><i class="fa fa-sticky-note"></i></span>\n' +
            '                        </p>\n' +
            '                    </div>\n';


        let btnSaveTask = document.createElement("a");
        btnSaveTask.className = "button is-primary btn-save-task";
        btnSaveTask.innerText = "Save Changes";
        btnSaveTask.taskId = this.taskId;
        btnSaveTask.userId = this.userId;
        btnSaveTask.addEventListener("click", this.saveEdit);

        let btnDeleteTask = document.createElement("a");
        btnDeleteTask.className = "button btn-delete-task";
        btnDeleteTask.innerText = "Delete";
        btnDeleteTask.taskId = this.taskId;
        btnDeleteTask.userId = this.userId;
        btnDeleteTask.addEventListener("click", this.delete);


        let thisTaskDiv = document.createElement("div");
        thisTaskDiv.className = "message-body";
        thisTaskDiv.id = this.taskId;
        thisTaskDiv.append(divField);
        thisTaskDiv.append(btnSaveTask);
        thisTaskDiv.append(btnDeleteTask);

        let panel = document.getElementsByClassName("panel")[0];
        panel.appendChild(thisTaskDiv);

        // This is for having the right value set and getting saveEdit() to work:
        let textArea = document.getElementById('text-' + this.taskId);
        textArea.value = this.name;
    }

    saveEdit() {
        let textArea = document.getElementById('text-' + this.taskId);
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks/' + this.taskId, {
            method: 'put',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({"name": textArea.value})
        })
            .then(res => res.json());
    }

    delete() {
        fetch('https://glo3102lab4.herokuapp.com/' + this.userId + '/tasks/' + this.taskId, {method: 'delete'});
        console.log("Removing taskId:", this.taskId, this);
        document.getElementById(this.taskId).remove();
    }

}

function createNewTask() {
    let userId = document.getElementById("load-user").value;
    fetch('https://glo3102lab4.herokuapp.com/' + userId + '/tasks', {
        method: 'post',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({"name": "A new task."})
    })
        .then(
            setTimeout(loadUserTasks, 100)
        );
}

let btnCreateUser = document.getElementById("btn-create-user");
btnCreateUser.addEventListener("click", createUser);

let btnLoadUser = document.getElementById("btn-load-user");
btnLoadUser.addEventListener("click", loadUserTasks);

let btnCreateTask = document.getElementById("btn-create-task");
btnCreateTask.addEventListener("click", createNewTask);
btnCreateTask.style.visibility = "hidden";
