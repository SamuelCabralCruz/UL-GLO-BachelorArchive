export {ToastTypes, Toaster}

const toastTypeImplementation = (name, background, iconName) => Object.freeze({
    getName: () => name,
    getIconName: () => iconName,
    getBackgroundColor: () => background
});

const ToastTypes = Object.freeze({
    ERROR: toastTypeImplementation("Error", "rgba(205, 92, 92, 0.7)", "fas fa-times fa-lg"),
    SUCCESS: toastTypeImplementation("Success", "rgba(0, 128, 0, 0.7)", "fa fa-check fa-lg"),
    INFO: toastTypeImplementation("Info", "rgba(71, 153, 183, 0.7)", "fas fa-info-circle")
});

class Toaster {
    createToast(type, title, message) {
        Toaster.id = (Toaster.id || 0) + 1;
        new Toast(Toaster.id, type, title, message);
    }
}

class Toast {
    constructor(id, type, title, message) {
        this.id = "toast-" + id;
        this.type = type;
        this.title = title;
        this.message = message;
        this.timer = this.add();
    }

    add() {
        function isChildOf(child, parent) {
            return Array.from(parent.childNodes).includes(child);
        }

        let divNotification = document.createElement("div");
        divNotification.id = this.id;
        divNotification.className = "toast-notification";
        divNotification.style.backgroundColor = this.type.getBackgroundColor();
        divNotification.onclick = this.kill;

        let titleNotification = document.createElement("p");

        let iconNotification = document.createElement("i");
        iconNotification.className = this.type.getIconName();
        titleNotification.appendChild(iconNotification);

        let titleTextNotification = document.createElement("span");
        titleTextNotification.innerText = " " + this.type.getName() + ": " + this.title;
        titleTextNotification.style.fontWeight = "bold";
        titleTextNotification.style.color = "white";
        titleNotification.appendChild(titleTextNotification);
        divNotification.appendChild(titleNotification);

        let messageNotification = document.createElement("p");
        messageNotification.innerText = this.message;
        messageNotification.style.color = "white";
        divNotification.appendChild(messageNotification);

        let divNotifications = document.getElementById("toast-notifications");
        divNotifications.insertBefore(divNotification, divNotifications.firstChild);

        return setTimeout(function () {
            if (isChildOf(divNotification, divNotifications)) {
                divNotifications.removeChild(divNotification);
            }
        }, 3000);
    }

    kill() {
        clearTimeout(this.timer);
        let divNotifications = document.getElementById("toast-notifications");
        let divNotification = document.getElementById(this.id);
        divNotifications.removeChild(divNotification);
    }
}
