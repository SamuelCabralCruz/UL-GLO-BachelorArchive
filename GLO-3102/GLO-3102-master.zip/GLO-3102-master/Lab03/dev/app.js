import {Toaster, ToastTypes} from "./toaster.js";

let toaster = new Toaster();

let buttons = document.getElementsByClassName("toast-button");

for(let i=0; i < buttons.length; i++) {
    let button = buttons[i];
    button.onclick = function() {createToastEventHandler(this)};
}

function createToastEventHandler(button) {
    let buttonType = ToastTypes[button.getAttribute("data-type").toUpperCase()];
    let title = document.getElementById("toast-text-title").value;
    let description = document.getElementById("toast-text-description").value;
    toaster.createToast(buttonType, title, description);
}
