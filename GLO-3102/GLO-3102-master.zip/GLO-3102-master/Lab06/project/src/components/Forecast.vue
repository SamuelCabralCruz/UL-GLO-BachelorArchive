<template>
  <div class="tile is-parent is-vertical">
    <article class="tile is-child notification is-link">
      <p class="title">{{ forecastWeekDay }}</p>
      <p class="subtitle">{{ forecastDateTime }}</p>
      <p class="subtitle">{{ forecastTempMin }}&#8451 / {{ forecastTempMax }}&#8451</p>
      <p class="subtitle">{{ forecastWeatherMain }}</p>
      <p class="subtitle">{{ forecastWeatherDescription }}</p>
      <p class="title" v-if="forecastWeatherMain === 'Rain'"><i class="fas fa-tint"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Drizzle'"><i class="fas fa-tint"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Clear'"><i class="fas fa-sun"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Clouds'"><i class="fas fa-cloud"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Thunderstorm'"><i class="fas fa-sun"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Snow'"><i class="fas fa-snowflake"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Mist'"><i class="fas fa-wind"></i></p>
      <p class="title" v-if="forecastWeatherMain === 'Atmosphere'"><i class="fas fa-wind"></i></p>
    </article>
  </div>
</template>

<script>
  export default {
    name: "Forecast",
    props: {
      "forecastIndex": {
        type: Number,
      },
      "forecastWeekDay": {
        type: String,
      },
      "forecastDateTime": {
        type: String,
      },
      "forecastTempMin": {
        type: Number,
      },
      "forecastTempMax": {
        type: Number,
      },
      "forecastWeatherMain": {
        type: String,
      },
      "forecastWeatherDescription": {
        type: String,
      },
    },
    data() {
      return {
        forecastDescription: this.forecastName,
      }
    },
    methods: {}
  }
</script>
