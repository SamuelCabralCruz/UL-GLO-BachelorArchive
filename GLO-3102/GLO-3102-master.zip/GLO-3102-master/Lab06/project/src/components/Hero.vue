<template>
  <section class="hero is-primary">
    <div class="hero-head">
      <nav class="main-nav navbar">
        <div class="container">
          <div class="navbar-start">
            <a class="navbar-item" href="https://github.com/guillaume-chevalier">Guillaume Chevalier</a>
            <a class="navbar-item" href="https://github.com/SamuelCabralCruz">Samuel Cabral Cruz</a>
            <a class="navbar-item" href="https://github.com/Emile05">Emile Bernard</a>
          </div>
          <div class="navbar-end navbar-menu">
            <a class="navbar-item" href="https://openweathermap.org">Open Weather Map</a>
            <a class="navbar-item" href="http://bulma.io">Bulma</a>
            <a class="navbar-item" href="https://jenil.github.io/bulmaswatch/">Bulmaswatch</a>
            <a class="navbar-item" href="http://fontawesome.io/">Font Awesome</a>
            <a class="navbar-item" href="https://fonts.google.com/">Google Fonts</a>
          </div>
        </div>
      </nav>
    </div>
    <div class="hero-body">
      <div class="container">
        <h1 class="title">Weather App.</h1>
        <p class="subtitle">Def your fav Weather app by now.</p>
      </div>
    </div>
  </section>
</template>

<script>
  export default {
    name: "Hero"
  }
</script>
