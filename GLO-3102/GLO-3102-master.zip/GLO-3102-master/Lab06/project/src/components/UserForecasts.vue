<template>
  <div id="user-forecasts-container">
    <hr>
    <h2 class="subtitle">Your local forecast.</h2>
    <nav class="panel">
      <div class="tile">
        <div class="tile is-parent is-vertical">
          <article class="tile is-child notification is-info">
            <p id="city" class="title">Nothing to show here.</p>
          </article>
        </div>
      </div>
      <div class="tile">
        <forecast v-for="(item, index) in forecasts"
                  v-bind:key=index
                  v-bind:forecastDateTime="item.forecastDateTime"
                  v-bind:forecastWeekDay="item.forecastWeekDay"
                  v-bind:forecastTempMin="item.forecastTempMin"
                  v-bind:forecastTempMax="item.forecastTempMax"
                  v-bind:forecastWeatherMain="item.forecastWeatherMain"
                  v-bind:forecastWeatherDescription="item.forecastWeatherDescription">
        </forecast>

      </div>
    </nav>
  </div>
</template>

<script>
  import Forecast from './Forecast'

  export default {
    name: "UserForecasts",
    components: {
      "forecast": Forecast,
    },
    props: {
      userLocation: "",
    },
    data() {
      return {
        forecasts: [],
      };
    },
    methods: {
      retrieveUserForecasts() {
        let userKey = '82e7d0ecfa749255523e4fd099f46cb5';
        let unitType = 'metric';
        let long = this.userLocation.long;
        let lat = this.userLocation.lat;

        console.log("Long: " + long + " " + "Lat: " + lat);

        fetch('https://api.openweathermap.org/data/2.5/forecast?lat=' + lat + '&lon=' + long + '&APPID=' + userKey +
          '&units=' + unitType, {method: 'get'})
          .then(response => response.json())
          .then(
            response => {
              let fiveDaysSampleArray = [];

              for (let i = 0; i < 5; i++) {
                let minTemp = 0;
                let maxTemp = 0;

                let minTempArray = [];
                let maxTempArray = [];

                let weatherConditionArray = [];
                let weatherDescriptionArray = [];

                for (let j = 0; j < 8; j++) {
                  weatherConditionArray.push(response.list[(i * 8) + j].weather[0].main);
                  weatherDescriptionArray.push(response.list[(i * 8) + j].weather[0].description);

                  minTempArray.push(response.list[(i * 8) + j]['main']['temp_min']);
                  maxTempArray.push(response.list[(i * 8) + j]['main']['temp_max']);
                }

                minTemp = Math.min(...minTempArray);
                maxTemp = Math.max(...maxTempArray);

                fiveDaysSampleArray.push(
                  {
                    forecastDateTime: this.getDateWithoutTime(response.list[i * 8].dt_txt),
                    forecastWeekDay: this.getDayOfWeek(response.list[i * 8].dt_txt),
                    forecastTempMin: minTemp,
                    forecastTempMax: maxTemp,
                    forecastWeatherMain: this.getTopWeatherCondition(weatherConditionArray),
                    forecastWeatherDescription: this.getTopWeatherCondition(weatherDescriptionArray),
                  }
                );
              }
              this.setUserForecasts(fiveDaysSampleArray);
              this.setUserCity(response.city.name);
            }
          );
      },
      setUserForecasts(forecasts) {
        console.log("User Forecasts Retrieved");
        this.forecasts = forecasts;
      },
      setUserCity(cityName) {
        document.getElementById('city').textContent = cityName;
      },
      getDayOfWeek(date) {
        let dateObj = new Date(date);
        const dayOfTheWeekArray = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return dayOfTheWeekArray[dateObj.getDay()];
      },
      getDateWithoutTime(date) {
        let dateObj = new Date(date);
        return dateObj.getDay() + '/' + dateObj.getMonth() + '/' + dateObj.getFullYear();
      },
      getTopWeatherCondition(tempArray) {
        let maxCount = tempArray.reduce(
          (accumulatedMaxCount, currentValue) => {
            if (currentValue in accumulatedMaxCount) {
              accumulatedMaxCount[currentValue] += 1;
            } else {
              accumulatedMaxCount[currentValue] = 1;
            }
            return accumulatedMaxCount;
          }, {});
        return this.getValueArgMax(maxCount);
      },
      getValueArgMax(countList) {
        return Object.keys(countList).reduce(
          (x, y) => countList[x] > countList[y] ? x : y);
      },
    },
    watch: {
      userLocation(newValue) {
        this.retrieveUserForecasts();
      }
    }
  }
</script>
