<template>
  <section class="section">
    <div class="container">
      <section class="section">
        <h2 class="subtitle">Get the location of the current user or use an other one</h2>
        <p>Getting a user location will fill the Location field. You can directly change the Location field to use a (or another)
          location if you have a preferred one.</p>
        <br>
        <div class="columns">
          <div class="column">
            <get-user-location-button></get-user-location-button>
          </div>
        </div>
        <hr>
      </section>
    </div>
  </section>
</template>

<script>
  import GetUserLocationButton from './GetUserLocationButton'

  export default {
    name: "MainContainer",
    components: {
      "get-user-location-button": GetUserLocationButton,
    },
  }
</script>
