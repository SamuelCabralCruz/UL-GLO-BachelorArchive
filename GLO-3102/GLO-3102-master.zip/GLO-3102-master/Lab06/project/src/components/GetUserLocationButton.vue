<template>
  <div class="field">
    <div class="control has-icons-left">
      <button v-on:click="getUserLocation" id="btn-get-user-location"
              class="button is-primary is-fullwidth">
        Get Your Local Forecasts
      </button>
      <span class="icon is-small is-left"><i class="fa fa-plus"></i></span>
    </div>
    <br>
    <user-forecasts v-bind:userLocation="userLocation" v-bind:style="{ display:displayForecasts }"></user-forecasts>
  </div>
</template>

<script>
  import UserForecasts from './UserForecasts'

  export default {
    name: "GetUserLocationButton",
    components: {
      "user-forecasts": UserForecasts,
    },
    data() {
      return {
        userLocation: null,
        displayForecasts: "block",
      };
    },
    methods: {
      getUserLocation: function () {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition((position) => {
            this.setUserLocation(position.coords.latitude, position.coords.longitude);
          });
        } else {
          alert('Browser does not support GeoLocation');
        }
      },
      setUserLocation(lat, long) {
        this.userLocation = {
          "lat": lat,
          "long": long,
        };
        console.log("User Location: " + this.userLocation.lat + ", " + this.userLocation.long);
      },
    }
  }
</script>
