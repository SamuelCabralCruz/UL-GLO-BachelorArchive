npm install
npm run lint
npm start
