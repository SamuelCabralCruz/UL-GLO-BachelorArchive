# IFT-2002
## Homework 1
### Interesting Links
- [https://www.geeksforgeeks.org/regular-expressions-regular-grammar-and-regular-languages/](https://www.geeksforgeeks.org/regular-expressions-regular-grammar-and-regular-languages/)

- [https://stackoverflow.com/questions/21214676/union-of-two-irregular-context-free-language-results-a-regular-language](https://stackoverflow.com/questions/21214676/union-of-two-irregular-context-free-language-results-a-regular-language)

- [https://cs.stackexchange.com/questions/49448/union-and-intersection-of-a-regular-and-a-non-regular-language](https://cs.stackexchange.com/questions/49448/union-and-intersection-of-a-regular-and-a-non-regular-language)

- [https://tex.stackexchange.com/questions/20784/which-package-can-be-used-to-draw-automata#20786](https://tex.stackexchange.com/questions/20784/which-package-can-be-used-to-draw-automata#20786)
