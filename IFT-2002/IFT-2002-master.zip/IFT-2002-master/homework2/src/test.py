# x$y^r avec y = x+1
import random

def to_word(n):
    mot = str(bin(n)) + '$' + str(bin(n+1))[::-1]
    return mot[2:-2]

def rand_word(n):
    deb = str(bin(n))[2:]
    fin = str(bin(random.randrange(10+1)))[2:]
    return deb + '$' + fin

working = map(to_word, range(10))
not_working = []

for n in range(10):
    for _ in range(10):
        not_working += [rand_word(n)]


with open('inputs.txt', 'w') as f:
    for x in working:
        print(x, file=f)
    print('', file=f)

    for x in not_working:
        print(x, file=f)