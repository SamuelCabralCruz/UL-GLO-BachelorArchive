package ca.ulaval.glo4003.coverage.domain.premium.formula.quote;

import ca.ulaval.glo4003.coverage.domain.premium.formula.BasePremiumCalculator;

public interface QuoteBasicBlockBasePremiumCalculator
    extends BasePremiumCalculator<QuotePremiumInput> {}
