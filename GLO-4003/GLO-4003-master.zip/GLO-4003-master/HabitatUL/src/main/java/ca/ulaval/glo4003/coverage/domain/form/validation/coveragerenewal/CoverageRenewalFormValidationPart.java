package ca.ulaval.glo4003.coverage.domain.form.validation.coveragerenewal;

import ca.ulaval.glo4003.coverage.domain.form.CoverageRenewalForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidationPart;

public interface CoverageRenewalFormValidationPart
    extends FormValidationPart<CoverageRenewalForm> {}
