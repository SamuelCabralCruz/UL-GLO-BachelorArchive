package ca.ulaval.glo4003.coverage.domain.form.validation.bicycleendorsement;

import ca.ulaval.glo4003.coverage.domain.form.BicycleEndorsementForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidationPart;

public interface BicycleEndorsementFormValidationPart
    extends FormValidationPart<BicycleEndorsementForm> {}
