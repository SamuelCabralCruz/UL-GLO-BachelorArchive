package ca.ulaval.glo4003.coverage.domain.form.validation.coveragerenewal;

import ca.ulaval.glo4003.coverage.domain.form.CoverageRenewalForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidation;

public class CoverageRenewalFormValidation extends FormValidation<CoverageRenewalForm> {}
