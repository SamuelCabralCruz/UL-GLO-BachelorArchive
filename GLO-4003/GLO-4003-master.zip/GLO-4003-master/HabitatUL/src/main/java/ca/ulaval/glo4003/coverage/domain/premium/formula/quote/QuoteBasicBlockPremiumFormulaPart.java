package ca.ulaval.glo4003.coverage.domain.premium.formula.quote;

import ca.ulaval.glo4003.coverage.domain.premium.formula.PremiumFormulaPart;

public interface QuoteBasicBlockPremiumFormulaPart extends PremiumFormulaPart<QuotePremiumInput> {}
