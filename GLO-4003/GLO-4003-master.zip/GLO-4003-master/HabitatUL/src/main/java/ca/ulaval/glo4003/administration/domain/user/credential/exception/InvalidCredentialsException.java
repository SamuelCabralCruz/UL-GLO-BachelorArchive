package ca.ulaval.glo4003.administration.domain.user.credential.exception;

import ca.ulaval.glo4003.administration.domain.user.exception.UserException;

public class InvalidCredentialsException extends UserException {}
