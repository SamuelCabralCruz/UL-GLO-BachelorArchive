package ca.ulaval.glo4003.coverage.domain.form.validation.coveragemodification;

import ca.ulaval.glo4003.coverage.domain.form.CoverageModificationForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidationPart;

public interface CoverageModificationFormValidationPart
    extends FormValidationPart<CoverageModificationForm> {}
