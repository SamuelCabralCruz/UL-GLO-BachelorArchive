package ca.ulaval.glo4003.coverage.domain.form.validation.quote;

import ca.ulaval.glo4003.coverage.domain.form.QuoteForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidation;

public class QuoteFormValidation extends FormValidation<QuoteForm> {}
