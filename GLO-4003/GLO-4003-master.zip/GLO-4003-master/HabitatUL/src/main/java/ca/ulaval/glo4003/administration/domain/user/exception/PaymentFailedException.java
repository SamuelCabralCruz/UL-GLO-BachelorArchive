package ca.ulaval.glo4003.administration.domain.user.exception;

public class PaymentFailedException extends UserException {}
