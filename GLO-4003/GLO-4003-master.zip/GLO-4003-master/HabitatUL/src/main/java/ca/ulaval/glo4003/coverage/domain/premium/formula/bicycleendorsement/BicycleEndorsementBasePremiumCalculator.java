package ca.ulaval.glo4003.coverage.domain.premium.formula.bicycleendorsement;

import ca.ulaval.glo4003.coverage.domain.premium.formula.BasePremiumCalculator;

public interface BicycleEndorsementBasePremiumCalculator
    extends BasePremiumCalculator<BicycleEndorsementPremiumInput> {}
