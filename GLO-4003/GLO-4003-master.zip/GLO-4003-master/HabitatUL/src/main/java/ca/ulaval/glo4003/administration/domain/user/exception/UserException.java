package ca.ulaval.glo4003.administration.domain.user.exception;

import ca.ulaval.glo4003.shared.domain.handling.BaseException;

public class UserException extends BaseException {}
