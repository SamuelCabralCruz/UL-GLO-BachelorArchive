package ca.ulaval.glo4003.administration.domain.user.exception;

public class KeyNotFoundException extends UserException {}
