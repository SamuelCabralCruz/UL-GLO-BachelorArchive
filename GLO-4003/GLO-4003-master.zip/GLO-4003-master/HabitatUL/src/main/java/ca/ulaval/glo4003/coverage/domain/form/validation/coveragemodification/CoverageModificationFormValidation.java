package ca.ulaval.glo4003.coverage.domain.form.validation.coveragemodification;

import ca.ulaval.glo4003.coverage.domain.form.CoverageModificationForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidation;

public class CoverageModificationFormValidation extends FormValidation<CoverageModificationForm> {}
