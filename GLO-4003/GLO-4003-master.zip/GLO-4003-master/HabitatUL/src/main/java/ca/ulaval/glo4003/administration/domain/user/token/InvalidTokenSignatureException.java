package ca.ulaval.glo4003.administration.domain.user.token;

import ca.ulaval.glo4003.administration.domain.user.exception.UserException;

public class InvalidTokenSignatureException extends UserException {}
