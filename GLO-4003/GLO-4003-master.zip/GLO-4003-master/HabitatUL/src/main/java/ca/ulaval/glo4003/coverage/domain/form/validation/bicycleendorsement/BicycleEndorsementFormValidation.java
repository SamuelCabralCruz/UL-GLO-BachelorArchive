package ca.ulaval.glo4003.coverage.domain.form.validation.bicycleendorsement;

import ca.ulaval.glo4003.coverage.domain.form.BicycleEndorsementForm;
import ca.ulaval.glo4003.coverage.domain.form.validation.FormValidation;

public class BicycleEndorsementFormValidation extends FormValidation<BicycleEndorsementForm> {}
