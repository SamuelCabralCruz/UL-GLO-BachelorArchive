package ca.ulaval.glo4003.context.exception;

public class ServiceLocatorException extends RuntimeException {
  ServiceLocatorException(String message) {
    super(message);
  }
}
